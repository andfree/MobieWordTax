import win32con, win32gui

if __name__ == '__main__':
    hwnd = win32gui.FindWindow(None, '국세청 세무자료 뷰어')
    hwnd = win32gui.FindWindowEx(hwnd, 0, 'Edit', '')
    buffer = win32gui.PyMakeBuffer(32768)
    length = win32gui.SendMessage(hwnd, win32con.WM_GETTEXT, 32768, buffer)
    bytes_ = buffer.tobytes()
    print(bytes_[:length * 2].decode('utf-16'))
