import aiohttp
import asyncio
import configparser
import os
import sys
import urllib
from collections import OrderedDict


if getattr(sys, 'frozen', False):
    BASE_PATH = os.path.dirname(sys.executable)
else:
    BASE_PATH = os.path.dirname(__file__)

UPLOAD_PATH = 'api/v1/data-uploads/'

config = None


def input_config(key, default):
    value = input('{} (leave blank to use \'{}\'): '.format(key, default))
    return value if value else default, value != default


def init_config(filename='config.txt', section=configparser.DEFAULTSECT):
    filename = os.path.join(BASE_PATH, filename)

    defaults = OrderedDict((('host', 'https://mobiletax.kr/'),
                            ('token', ''),
                            ('target', '')))

    config = configparser.ConfigParser(defaults=defaults)
    config.read(filename)

    need_to_write = False
    for key in defaults.keys():
        value = config.get(section, key)
        value, changed = input_config(key, value)
        if changed:
            config.set(section, key, value)
            need_to_write = True

    if need_to_write:
        with open(filename, 'w') as f:
            config.write(f)

    return dict(config[section])


@asyncio.coroutine
def request(session, path, method='get', headers={}, data=None, expected_status_code=200):
    method = method.lower()
    headers.update({'Authorization': 'Token {}'.format(config['token'])})

    try:
        url = config['host'] + path
        response = yield from getattr(session, method)(url, headers=headers, data=data, allow_redirects=False)
        if response.status != expected_status_code:
            raise Exception('Expected status code {}, got {}'.format(expected_status_code, response.status))
    finally:
        if response:
            response.close()


@asyncio.coroutine
def get(session, path, headers={}, expected_status_code=200):
    yield from request(session, path, 'get', headers, None, expected_status_code)


@asyncio.coroutine
def post(session, path, headers={}, data=None, expected_status_code=200):
    yield from request(session, path, 'post', headers, data, expected_status_code)


@asyncio.coroutine
def upload(filepath, filename):
    with aiohttp.ClientSession() as session:
        with open(filepath, 'rb') as f:
            with aiohttp.MultipartWriter('form-data') as writer:
                part = writer.append(f, {'Content-type': 'application/vnd.ms-excel'})
                part.set_content_disposition('form-data', name='file', filename=filename)
                data = b''.join(writer.serialize())

                yield from post(session, UPLOAD_PATH, headers=writer.headers, data=data, expected_status_code=201)

if __name__ == '__main__':
    config = init_config()

    business_numbers = set()
    while True:
        business_number = input('사업자 등록번호: ')
        if not business_number:
            break

        business_numbers.add(business_number)

    tasks = []
    for root, dirs, files in os.walk(config['target']):
        if root.endswith('01. 전자세금계산서') or root.endswith('02. 신용카드'):
            for file in files:
                _, extension = os.path.splitext(file)
                if extension != '.xls':
                    continue

                if business_numbers:
                    _, business_name, _, _ = urllib.parse.unquote(file[3:-4]).split('_')
                    if business_name[-11:-1] not in business_numbers:
                        continue

                task = asyncio.ensure_future(upload(os.path.join(root, file), file))
                tasks.append(task)

    if tasks:
        loop = asyncio.get_event_loop()
        loop.run_until_complete(asyncio.wait(tasks))
