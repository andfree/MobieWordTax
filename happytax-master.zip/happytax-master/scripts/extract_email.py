# extract email list from user database
# usage : execute below script in happytax dir
#   python manage.py runscript extract_email --script-args TASKNAME --settings=happytax.production > email-`date +%Y%m%d`-TAG.txt

import datetime
import pytz
from django.db.models import Count
from accounting.models import User, Trader

# 참고 : trader activation
# require_information : 비활성
# trying : 활성화 시도중
# in_review : 매니저 검토중
# activated : 활성화됨
# require_payment : 결제 안됨
# requested_to_delete : 삭제요청됨
# test : 테스트 계정

# set date
# tz=pytz.timezone('Asia/Seoul')
# start_date = datetime.datetime(2018, 9, 17, tzinfo=tz)
# last_date = datetime.datetime(2019, 1, 9, tzinfo=tz)

def print_email(users):
    for user in users:
        if 'test' in user.email or '@mobiletax.kr' in user.email or 'test' in user.name or '테스트' in user.name:
            continue
        print('{}\t{}'.format(user.email, user.name))

def run(*args):
    try:
        task = args[0]

        # 전체 회원 이메일
        if task == 'allusers':
            users = User.objects.all()

        # 회원 가입만 한 고객
        if task == 'notrader':
            users = User.objects.filter(trader__isnull=True)

        # 상호등록된 고객
        if task == 'have_trader':
            users = User.objects.filter(trader__isnull=False).exclude(trader__activation__in=['test'])

        # 특정 사업자 상태
        if task in ['require_information', 'trying', 'in_review', 'activated', 'require_payment', 'requested_to_delete', 'test']:
            users = User.objects.filter(trader__isnull=False).filter(trader__activation=task)

        # 담당 매니저 없음
        if task == 'no_manager':
            users = User.objects.annotate(manager_count=Count('trader__manager_set')).filter(manager_count=0)

        # 담당 매니저 있음
        if task == 'have_manager':
            users = User.objects.annotate(manager_count=Count('trader__manager_set')).exclude(manager_count=0)

        print_email(users)

    except Exception as ex:
        print('* Exception')
        print(ex)

# 참고
# 회원 가입만 함 = 등록된 사업자 없음
# users = User.objects.filter(trader__isnull=True)
# 사업자 상태에 따른 선택 / 배제
# users = User.objects.filter(trader__isnull=False).filter(trader__activation='test')
# users = User.objects.filter(trader__isnull=False).filter(trader__activation__in=['test', 'requested_to_delete'])
# users = User.objects.filter(trader__isnull=False).exclude(trader__activation__in=['test', 'requested_to_delete'])
# 담당 매니저 수
# users = User.objects.annotate(manager_count=Count('trader__manager_set')).filter(manager_count__gte=3)
# 담당매니저 없음
# users = User.objects.annotate(manager_count=Count('trader__manager_set')).filter(manager_count=0)

# 참고 : 기간에 따른 추가 필터링
# users = users.filter(date_joined__gte=start_date).filter(date_joined__lte=last_date)
