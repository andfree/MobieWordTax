# send notice
#
# Usage
# - message file : notice_msg.txt
#   Insert empty line between title and content
#     title : line 1 / content : line 3 ~
# - testing
#   python manage.py runscript send_notice --script-args test --settings=happytax.production
# - REAL SENDING
#   python manage.py runscript send_notice --script-args send all --settings=happytax.production
#   python manage.py runscript send_notice --script-args send activates --settings=happytax.production
#   python manage.py runscript send_notice --script-args send corp --settings=happytax.production

import datetime
import os
from accounting.models import Message, Trader, User

msg_file = os.path.dirname(__file__) + '/notice_msg.txt'

mtxid = 2320
#               dev test / ysp
test_traders = [3540, 3543]

# ---------------------------------------------------------------------------

def run(*args):
    is_testing = args[0] != 'send'
    # send_to : all / activated
    sent_to = args[1] if len(args) > 1 else 'activated'

    if is_testing:
        print('# START send_notice [Testing]')
    else:
        print('# START send_notice [REAL SENDING]')

    (title, content) = readMsg()
    print('\n* title\n{}\n* content\n{}'.format(title, content))

    # mtxid should be set 2320 (`mobiletax` account's id) in production www
    sender = User.objects.get(id=mtxid)
    if sender.name != '모바일택스':
        print('e sender name is not mobiletax. current sender name is', sender.name)
        exit()

    if is_testing:
        traders = Trader.objects.filter(pk__in=test_traders)
    elif sent_to == 'all':
        traders = Trader.objects.all()
    elif sent_to == 'activates':
        traders = Trader.objects.filter(activation='activated')
    elif sent_to == 'corp':
        traders = Trader.objects.filter(is_corporation=True)

    print('* sending starts for {} users'.format(len(traders)),
        datetime.datetime.now())

    for trader in traders:
        Message.objects.create(
            trader=trader,
            sender=sender,
            type='notice',
            title=title,
            content=content
        )
        print('. sending', trader.id)

    print('* DONE', len(traders), datetime.datetime.now())


def readMsg():
    f = open(msg_file, 'r')
    lines = f.readlines()
    title = lines[0]
    content = ''.join(lines[2:])
    f.close()

    return (title, content)
