import os
import os.path
import requests


data_path = os.path.expanduser(r"~\Desktop\세무사TaxMate결과File")
# api_endpoint = 'http://10.0.2.2:8000/api/v1/esero/create/'
api_endpoint = 'http://ec2-54-65-229-111.ap-northeast-1.compute.amazonaws.com/api/v1/esero/create/'


def post(dirpath, filename):
    res = requests.post(api_endpoint,
                        files={'file': open(dirpath + os.sep + filename, 'rb')})
    print(res.text)


def scrap_tax_invoice():
    for dirpath, dirnames, filenames in os.walk(data_path):
        if '계산서' in dirpath and filenames:
            for filename in filenames:
                post(dirpath, filename)


if __name__ == '__main__':
    scrap_tax_invoice()
    # test_filename = '01.매입_(주)상석통운(1358106895)_2015년_1월.xls'
    # res = requests.post('http://localhost:8000/api/v1/esero/create/',
    #                     files={'file': (test_filename, open('testdata/' + test_filename, 'rb'))})
    # print(res.text)

