from datetime import date
from fabric.context_managers import cd, settings
from fabric.operations import run, sudo
from fabric.contrib.files import exists
from fabric.decorators import task, roles
from fabric.state import env
from fabric.tasks import execute
from fabtools import require, service
import fabtools
from fabtools.python import virtualenv
import securevalues


env.roledefs.update({
    'web': [
        # 'ec2-54-65-229-111.ap-northeast-1.compute.amazonaws.com',
        'ec2-52-197-238-210.ap-northeast-1.compute.amazonaws.com',
    ],
    'celery': [
        'ec2-52-197-238-210.ap-northeast-1.compute.amazonaws.com'
    ],
    'db': ['ec2-52-68-213-179.ap-northeast-1.compute.amazonaws.com'],
    'marketing': ['ec2-52-68-217-76.ap-northeast-1.compute.amazonaws.com'],
})
env.user = 'ubuntu'
env.home = '/home/' + env.user
env.server_name = 'mobiletax.kr'
env.project_name = 'happytax'
# fix for setup_db by fediev
env.database_name = 'mobiletax'
env.project_repo = 'git@github.com:mobiletax/happytax.git'
env.project_path = env.home + '/' + env.project_name
env.manager_spa_path = env.home + '/' + env.project_name + '/manager/dist'
env.static_path = env.home + '/static'
env.deploy_key_path = env.home + '/.ssh/' + 'id_deploy'
env.virtualenv = env.home + '/venv'
env.backup_bucket = 'happytax-backup'
env.backup_dir = '/mnt/data'
env.celery_tasks = 'accounting.tasks'
env.collect_error_log = True

@task
def beta():
    env.roledefs.update({
        'web': [
            'ec2-13-115-189-227.ap-northeast-1.compute.amazonaws.com'
        ],
        'celery': [
            'ec2-13-115-189-227.ap-northeast-1.compute.amazonaws.com'
        ],
        'db': ['ec2-13-115-189-227.ap-northeast-1.compute.amazonaws.com'],
        'marketing': [],
    })
    env.db_host = '127.0.0.1'
    env.server_name = 'beta.mobiletax.kr'
    env.collect_error_log = False


@task
def production():
    env.roledefs.update({
        'web': [
            # 'ec2-54-65-229-111.ap-northeast-1.compute.amazonaws.com',
            'ec2-52-197-238-210.ap-northeast-1.compute.amazonaws.com',
        ],
        'celery': [
            'ec2-52-197-238-210.ap-northeast-1.compute.amazonaws.com'
        ],
        'db': ['ec2-52-68-213-179.ap-northeast-1.compute.amazonaws.com'],
        'marketing': ['ec2-52-68-217-76.ap-northeast-1.compute.amazonaws.com'],
    })
    env.db_host = '172.31.1.192'


@task
@roles('web', 'db', 'celery', 'marketing')
def auth():
    env.key_filename = 'happytax.pem'
    require.files.directory(env.home + '/.ssh', owner=env.user)
    require.files.file(env.home + '/.ssh/authorized_keys', source='authorized_keys', owner=env.user)


def checkout(url, directory):
    if exists(directory):
        with cd(directory):
            run("ssh-agent bash -c 'ssh-add %s; git pull'" % env.deploy_key_path)

    else:
        with cd(env.home):
            run("ssh-agent bash -c 'ssh-add %s; git clone %s'" % (env.deploy_key_path, url))


@task
@roles('web', 'marketing')
def switch(branch):
    with cd(env.project_path):
        run("ssh-agent bash -c 'ssh-add %s; git fetch; git checkout %s'" % (env.deploy_key_path, branch))


@task
@roles('web', 'marketing')
def setup_web():
    if not run('node -v').startswith('v8'):
        run('curl -sL https://deb.nodesource.com/setup_8.x | sudo -E bash -')
        run('sudo apt-get install -y nodejs')

    require.deb.packages(
        ['git', 'python3-dev', 'libxml2-dev', 'libxslt1-dev', 'libpq-dev', 'libmagickwand-dev',
         'postfix', 'openjdk-7-jdk', 'python-pip', 'python-lxml', 'python-cffi', 'libcairo2', 'libpango1.0-0',
         'libgdk-pixbuf2.0-0', 'shared-mime-info', 'libffi-dev', 'fonts-nanum'])
    require.nginx.server()
    require.nginx.site(env.server_name, template_source='nginx-site',
                       port=80,
                       server_alias='',
                       static_path=env.static_path, manager_spa_path=env.manager_spa_path)
    # require.nginx.disabled('default')

    with settings(warn_only=True):
        if run('type bower').return_code:
            sudo('npm install -g bower')

    update_source()

    require.directory(env.home + '/logs')
    require.python.packages(['uwsgi', 'virtualenv', 'ipython', 'celery'], use_sudo=True)
    require.file('/etc/init/uwsgi.conf', source='uwsgi.conf', use_sudo=True)
    # require.file('/etc/init/celery.conf', source='celery.conf', use_sudo=True)
    require.directory('/etc/uwsgi', use_sudo=True)
    require.files.template_file('/etc/uwsgi/%s.ini' % env.project_name,
                                template_source='uwsgi.ini',
                                context=env, use_sudo=True)
    require.service.started('uwsgi')
    require.directory(env.home + '/bin')
    require.files.template_file(env.home + '/bin/djangorc',
                                template_source='bin/djangorc',
                                context=env)
    require.files.template_file(env.home + '/bin/loadenv',
                                template_source='bin/loadenv',
                                context=env)
    run('chmod +x ' + env.home + '/bin/loadenv')

    # require.service.started('celery')


@task
@roles('db')
def setup_db():
    require.deb.packages(['postgresql', 'libpq-dev'])
    if not fabtools.postgres.user_exists(env.db_user):
        fabtools.postgres.create_user(env.db_user, env.db_password, createdb=True)

    # fix for beta by fediev

    # if not fabtools.postgres.database_exists(env.project_name):
    #     fabtools.postgres.create_database(env.project_name, env.project_name)

    if not fabtools.postgres.database_exists(env.database_name):
          fabtools.postgres.create_database(env.database_name, env.project_name)

    #setup_backup()


@task
@roles('db')
def setup_backup():
    require.python.package('awscli', use_sudo=True)
    require.directory(env.home + '/.aws')
    require.files.template_file(env.home + '/.aws/config',
                                template_source='aws/config', context=env)
    require.files.template_file(env.home + '/.aws/credentials',
                                template_source='aws/credentials', context=env)
    run('chmod 0600 ' + env.home + '/.aws/*')

    require.directory(env.backup_dir, use_sudo=True)
    sudo('chown ubuntu.ubuntu %s' % env.backup_dir)

    require.directory(env.home + '/bin')
    require.files.template_file(env.home + '/bin/backup-postgresql.sh',
                                template_source='bin/backup-postgresql.sh',
                                context=env)
    run('chmod +x ' + env.home + '/bin/backup-postgresql.sh')
    fabtools.cron.add_task('backup-postgresql',
                           '0 0 * * *',
                           'ubuntu',
                           '%s/bin/backup-postgresql.sh' % env.home)



@task
@roles('web')
def deploy():
    execute(update_source)
    execute(reload_uwsgi)
    execute(celery, 'restart')

    with cd(env.project_path + '/manager'):
        run('npm install')
        run('NODE_ENV=production npm run build')


@task
def reload_uwsgi():
    sudo('reload uwsgi')


@task
@roles('web', 'celery', 'marketing')
def deploy_key():
    '''
    One who registered github deploy key can setup deploy key.
    '''
    require.file(env.deploy_key_path, source='id_deploy')


@task
def update_source():
    deploy_key()
    run('chmod 0600 ' + env.deploy_key_path)
    checkout(env.project_repo, env.project_path)
    require.files.template_file(env.project_path + '/%s/production.py' % env.project_name,
                                template_source='production.py.template', context=env)

    require.python.virtualenv(env.virtualenv, venv_python='/usr/bin/python3.4')
    with virtualenv(env.virtualenv):
        require.python.requirements(env.project_path + '/requirements.txt')

        with cd(env.project_path + '/accounting/static'):
            run('bower install')

        with cd(env.project_path):
            run('bower install')
            run('./manage.py collectstatic --settings=%s.production --noinput' % env.project_name)
            run('./manage.py migrate --settings=%s.production --noinput' % env.project_name)


@task
@roles('celery')
def celery(command):
    """Celery server - setup, start, stop, restart

    $ fab celery:command
    """
    if command in ['start', 'stop', 'restart']:
        getattr(service, command)('celery')

    if command == 'setup':
        fabtools.deb.update_index()
        require.deb.packages(['git', 'python3-dev', 'bzip2', 'make',
                              'libmysqlclient-dev', 'rabbitmq-server'])
        require.directory(env.home + '/logs')
        require.python.packages(['virtualenv', 'ipython', 'celery'],
                                use_sudo=True)

        update_source()

        require.files.template_file('/etc/init/celery.conf',
                                    template_source='celery.conf',
                                    context=env, use_sudo=True)

        require.service.started('rabbitmq-server')
        require.service.started('celery')


@task
@roles('marketing')
def marketing():
    fabtools.cron.add_task('send-email-campaign-1',
                           '0 2 * * *',
                           'ubuntu',
                           '{}/bin/python {}/manage.py send_mail --settings={}.production 1 1 30'
                           .format(env.virtualenv, env.project_path, env.project_name))
    fabtools.cron.add_task('send-email-campaign-2',
                           '0 2 * * *',
                           'ubuntu',
                           '{}/bin/python {}/manage.py send_mail --settings={}.production 2 1 30'
                           .format(env.virtualenv, env.project_path, env.project_name))
    fabtools.cron.add_task('send-email-campaign-3',
                           '0 2 * * *',
                           'ubuntu',
                           '{}/bin/python {}/manage.py send_mail --settings={}.production 3 1 30'
                           .format(env.virtualenv, env.project_path, env.project_name))
    fabtools.cron.add_task('send-email-campaign-11',
                           '0 2 * * *',
                           'ubuntu',
                           '{}/bin/python {}/manage.py send_mail --settings={}.production 11 0 30'
                           .format(env.virtualenv, env.project_path, env.project_name))
    fabtools.cron.add_task('send-email-campaign-12',
                           '0 2 * * *',
                           'ubuntu',
                           '{}/bin/python {}/manage.py send_mail --settings={}.production 12 0 30'
                           .format(env.virtualenv, env.project_path, env.project_name))
    fabtools.cron.add_task('send-email-campaign-13',
                           '0 2 * * *',
                           'ubuntu',
                           '{}/bin/python {}/manage.py send_mail --settings={}.production 13 0 30'
                           .format(env.virtualenv, env.project_path, env.project_name))


@task
def newrelic():
    sudo('echo deb http://apt.newrelic.com/debian/ newrelic non-free >> /etc/apt/sources.list.d/newrelic.list')
    sudo('wget -O- https://download.newrelic.com/548C16BF.gpg | apt-key add -')
    sudo('apt-get update')
    sudo('apt-get install newrelic-sysmond')
    sudo('nrsysmond-config --set license_key=997e37d938de38c0e90a0742c85e56cea585090e')
    sudo('/etc/init.d/newrelic-sysmond start')