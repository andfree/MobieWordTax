import React from 'react';
import { ApolloClient, ApolloProvider, InMemoryCache } from '@apollo/client';
import { WebSocketLink } from '@apollo/client/link/ws';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import CssBaseline from '@material-ui/core/CssBaseline';
import { ThemeProvider } from '@material-ui/core';
import { TokenProvider } from './components/TokenProvider';
import { Dashboard, Manager, Login } from './pages';
import PrivateRoute from './components/PrivateRoute';
import { config } from './config';
import themes from './theme';

const cache = new InMemoryCache();

const link = new WebSocketLink({
  uri: config.graphqlUri,
  options: {
    reconnect: true,
  },
});

const client = new ApolloClient({
  cache,
  link,
});

function App(): JSX.Element {
  return (
    <ApolloProvider client={client}>
      <TokenProvider>
        <BrowserRouter basename="/app">
          <ThemeProvider theme={themes.light}>
            <CssBaseline>
              <Switch>
                <Route path="/login" component={Login} />
                <PrivateRoute path="/manager" component={Manager} />
                <Route component={Dashboard} />
              </Switch>
            </CssBaseline>
          </ThemeProvider>
        </BrowserRouter>
      </TokenProvider>
    </ApolloProvider>
  );
}

export default App;
