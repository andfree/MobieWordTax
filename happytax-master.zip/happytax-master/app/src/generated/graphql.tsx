import gql from 'graphql-tag';
export type Maybe<T> = T | null;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: string;
  String: string;
  Boolean: boolean;
  Int: number;
  Float: number;
  /**
   * The `DateTime` scalar type represents a DateTime
   * value as specified by
   * [iso8601](https://en.wikipedia.org/wiki/ISO_8601).
   */
  DateTime: any;
  /** The `Decimal` scalar type represents a python Decimal. */
  Decimal: any;
  /**
   * The `Date` scalar type represents a Date
   * value as specified by
   * [iso8601](https://en.wikipedia.org/wiki/ISO_8601).
   */
  Date: any;
};

export type Query = {
  __typename?: 'Query';
  user?: Maybe<User>;
  traders?: Maybe<Array<Maybe<Trader>>>;
  messages?: Maybe<MessageConnection>;
};


export type QueryMessagesArgs = {
  trader: Scalars['ID'];
  before?: Maybe<Scalars['String']>;
  after?: Maybe<Scalars['String']>;
  first?: Maybe<Scalars['Int']>;
  last?: Maybe<Scalars['Int']>;
};

export type User = {
  __typename?: 'User';
  id: Scalars['ID'];
  password: Scalars['String'];
  lastLogin?: Maybe<Scalars['DateTime']>;
  /** 해당 사용자에게 모든 권한을 허가합니다. */
  isSuperuser: Scalars['Boolean'];
  /** 150자 이하 문자, 숫자 그리고 @/./+/-/_만 가능합니다. */
  username: Scalars['String'];
  firstName: Scalars['String'];
  lastName: Scalars['String'];
  email: Scalars['String'];
  /** 사용자가 관리사이트에 로그인이 가능한지를 나타냅니다. */
  isStaff: Scalars['Boolean'];
  /** 이 사용자가 활성화되어 있는지를 나타냅니다. 계정을 삭제하는 대신 이것을 선택 해제하세요. */
  isActive: Scalars['Boolean'];
  dateJoined: Scalars['DateTime'];
  name: Scalars['String'];
  registrationNo: Scalars['String'];
  phone: Scalars['String'];
  currentTrader?: Maybe<Trader>;
  gcmkey?: Maybe<Scalars['String']>;
  apnskey?: Maybe<Scalars['String']>;
  isValidated: Scalars['Boolean'];
  beta: Scalars['Boolean'];
  team?: Maybe<Scalars['String']>;
  isTeamLeader: Scalars['Boolean'];
  forNewClient: Scalars['Boolean'];
  condition: Scalars['String'];
  workStartingTime: Scalars['Int'];
  workFinishingTime: Scalars['Int'];
  outOfOfficeMessage?: Maybe<Scalars['String']>;
  dayOffMessage?: Maybe<Scalars['String']>;
  clientSet: TraderConnection;
  slackid?: Maybe<Scalars['String']>;
  directNumber?: Maybe<Scalars['String']>;
  faxNumber?: Maybe<Scalars['String']>;
  traderSet: TraderConnection;
  accountingClientSet: TraderConnection;
  messageSet: MessageNodeConnection;
  readMessages: MessageNodeConnection;
};


export type UserClientSetArgs = {
  offset?: Maybe<Scalars['Int']>;
  before?: Maybe<Scalars['String']>;
  after?: Maybe<Scalars['String']>;
  first?: Maybe<Scalars['Int']>;
  last?: Maybe<Scalars['Int']>;
};


export type UserTraderSetArgs = {
  offset?: Maybe<Scalars['Int']>;
  before?: Maybe<Scalars['String']>;
  after?: Maybe<Scalars['String']>;
  first?: Maybe<Scalars['Int']>;
  last?: Maybe<Scalars['Int']>;
};


export type UserAccountingClientSetArgs = {
  offset?: Maybe<Scalars['Int']>;
  before?: Maybe<Scalars['String']>;
  after?: Maybe<Scalars['String']>;
  first?: Maybe<Scalars['Int']>;
  last?: Maybe<Scalars['Int']>;
};


export type UserMessageSetArgs = {
  offset?: Maybe<Scalars['Int']>;
  before?: Maybe<Scalars['String']>;
  after?: Maybe<Scalars['String']>;
  first?: Maybe<Scalars['Int']>;
  last?: Maybe<Scalars['Int']>;
};


export type UserReadMessagesArgs = {
  offset?: Maybe<Scalars['Int']>;
  before?: Maybe<Scalars['String']>;
  after?: Maybe<Scalars['String']>;
  first?: Maybe<Scalars['Int']>;
  last?: Maybe<Scalars['Int']>;
};


export type Trader = Node & {
  __typename?: 'Trader';
  /** The ID of the object. */
  id: Scalars['ID'];
  user?: Maybe<User>;
  registrationNo: Scalars['String'];
  businessName: Scalars['String'];
  businessType: Scalars['String'];
  businessCondition?: Maybe<TraderBusinessCondition>;
  isCorporation: Scalars['Boolean'];
  isRestaurant: Scalars['Boolean'];
  taxation: TraderTaxation;
  otherVatSales: Scalars['Int'];
  otherVatPurchase: Scalars['Int'];
  otherIncomeSales: Scalars['Int'];
  otherIncomePurchase: Scalars['Int'];
  otherIncome: Scalars['Int'];
  activation: TraderActivation;
  monthlyPrice: Scalars['Decimal'];
  lastReceived?: Maybe<Scalars['DateTime']>;
  created: Scalars['DateTime'];
  updated: Scalars['DateTime'];
  reportSalary: Scalars['Boolean'];
  cmsActivated?: Maybe<Scalars['DateTime']>;
  paymentStarted?: Maybe<Scalars['DateTime']>;
  accountingManager?: Maybe<User>;
  accountingTool: TraderAccountingTool;
  info: Scalars['String'];
  unreadCounts: Scalars['String'];
  currentUser?: Maybe<User>;
  managerSet: Array<User>;
  messageSet: MessageNodeConnection;
  unreadCount: Scalars['Int'];
};


export type TraderMessageSetArgs = {
  offset?: Maybe<Scalars['Int']>;
  before?: Maybe<Scalars['String']>;
  after?: Maybe<Scalars['String']>;
  first?: Maybe<Scalars['Int']>;
  last?: Maybe<Scalars['Int']>;
};

/** An object with an ID */
export type Node = {
  /** The ID of the object. */
  id: Scalars['ID'];
};

/** An enumeration. */
export enum TraderBusinessCondition {
  A = 'A_',
  /** 폐업 */
  Pyeeob = 'PYEEOB'
}

/** An enumeration. */
export enum TraderTaxation {
  /** 일반과세자 */
  Normal = 'NORMAL',
  /** 간이과세자 */
  Simplified = 'SIMPLIFIED',
  /** 면세사업자 */
  TaxFree = 'TAX_FREE'
}

/** An enumeration. */
export enum TraderActivation {
  /** 비활성 */
  RequireInformation = 'REQUIRE_INFORMATION',
  /** 활성화 시도중 */
  Trying = 'TRYING',
  /** 매니저 검토중 */
  InReview = 'IN_REVIEW',
  /** 활성화됨 */
  Activated = 'ACTIVATED',
  /** 결제 안됨 */
  RequirePayment = 'REQUIRE_PAYMENT',
  /** 삭제요청됨 */
  RequestedToDelete = 'REQUESTED_TO_DELETE',
  /** 테스트 계정 */
  Test = 'TEST'
}


/** An enumeration. */
export enum TraderAccountingTool {
  /** 더존 */
  Duzon = 'DUZON',
  /** 모바일택스 */
  Mobiletax = 'MOBILETAX'
}

export type MessageNodeConnection = {
  __typename?: 'MessageNodeConnection';
  /** Pagination data for this connection. */
  pageInfo: PageInfo;
  /** Contains the nodes in this connection. */
  edges: Array<Maybe<MessageNodeEdge>>;
};

/** The Relay compliant `PageInfo` type, containing data necessary to paginate this connection. */
export type PageInfo = {
  __typename?: 'PageInfo';
  /** When paginating forwards, are there more items? */
  hasNextPage: Scalars['Boolean'];
  /** When paginating backwards, are there more items? */
  hasPreviousPage: Scalars['Boolean'];
  /** When paginating backwards, the cursor to continue. */
  startCursor?: Maybe<Scalars['String']>;
  /** When paginating forwards, the cursor to continue. */
  endCursor?: Maybe<Scalars['String']>;
};

/** A Relay edge containing a `MessageNode` and its cursor. */
export type MessageNodeEdge = {
  __typename?: 'MessageNodeEdge';
  /** The item at the end of the edge */
  node?: Maybe<MessageNode>;
  /** A cursor for use in pagination */
  cursor: Scalars['String'];
};

export type MessageNode = Node & {
  __typename?: 'MessageNode';
  /** The ID of the object. */
  id: Scalars['ID'];
  trader: Trader;
  sender: User;
  group?: Maybe<Scalars['String']>;
  type: MessageType;
  mimetype: Scalars['String'];
  title?: Maybe<Scalars['String']>;
  content: Scalars['String'];
  contentId?: Maybe<Scalars['Int']>;
  created: Scalars['DateTime'];
  read?: Maybe<Scalars['DateTime']>;
  done?: Maybe<Scalars['DateTime']>;
  due?: Maybe<Scalars['Date']>;
  readers: Array<User>;
  info: Scalars['String'];
};

/** An enumeration. */
export enum MessageType {
  /** 종합소득세 신고서 */
  IncomeTaxReport = 'INCOME_TAX_REPORT',
  /** 부가가치세 신고서 */
  VatReport = 'VAT_REPORT',
  /** 종합소득세 납부서 */
  IncomeTaxStatement = 'INCOME_TAX_STATEMENT',
  /** 부가가치세 납부서 */
  VatStatement = 'VAT_STATEMENT',
  /** 원천세 납부서 */
  WithholdingTaxStatement = 'WITHHOLDING_TAX_STATEMENT',
  /** 자료요청 */
  InformationRequest = 'INFORMATION_REQUEST',
  /** 공지사항 */
  Notice = 'NOTICE',
  /** 텍스트 */
  Text = 'TEXT',
  /** 증빙자료 */
  Voucher = 'VOUCHER',
  /** 첨부파일 */
  Attachment = 'ATTACHMENT',
  /** 지방소득세 납부서 */
  LocalIncomeTaxStatement = 'LOCAL_INCOME_TAX_STATEMENT',
  /** 소득세 납부서 */
  NationalIncomeTaxStatement = 'NATIONAL_INCOME_TAX_STATEMENT',
  /** 원천징수이행상황신고서 */
  WithholdingTaxStatusReport = 'WITHHOLDING_TAX_STATUS_REPORT'
}


export type TraderConnection = {
  __typename?: 'TraderConnection';
  /** Pagination data for this connection. */
  pageInfo: PageInfo;
  /** Contains the nodes in this connection. */
  edges: Array<Maybe<TraderEdge>>;
};

/** A Relay edge containing a `Trader` and its cursor. */
export type TraderEdge = {
  __typename?: 'TraderEdge';
  /** The item at the end of the edge */
  node?: Maybe<Trader>;
  /** A cursor for use in pagination */
  cursor: Scalars['String'];
};

export type MessageConnection = {
  __typename?: 'MessageConnection';
  /** Pagination data for this connection. */
  pageInfo: PageInfo;
  /** Contains the nodes in this connection. */
  edges: Array<Maybe<MessageEdge>>;
};

/** A Relay edge containing a `Message` and its cursor. */
export type MessageEdge = {
  __typename?: 'MessageEdge';
  /** The item at the end of the edge */
  node?: Maybe<MessageNode>;
  /** A cursor for use in pagination */
  cursor: Scalars['String'];
};

export type Mutation = {
  __typename?: 'Mutation';
  login?: Maybe<Login>;
  sendMessage?: Maybe<SendMessage>;
};


export type MutationLoginArgs = {
  token: Scalars['String'];
};


export type MutationSendMessageArgs = {
  content: Scalars['String'];
  trader: Scalars['ID'];
};

export type Login = {
  __typename?: 'Login';
  ok: Scalars['Boolean'];
};

export type SendMessage = {
  __typename?: 'SendMessage';
  ok: Scalars['Boolean'];
};

export type Subscription = {
  __typename?: 'Subscription';
  onMessageAdded?: Maybe<OnMessageAdded>;
};


export type SubscriptionOnMessageAddedArgs = {
  trader: Scalars['ID'];
};

export type OnMessageAdded = {
  __typename?: 'OnMessageAdded';
  message?: Maybe<MessageNode>;
};
