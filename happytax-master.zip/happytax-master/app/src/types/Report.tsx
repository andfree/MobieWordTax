export interface Trader {
  id: number;
  business_name: string;
  accounting_manager?: {
    name: string;
  };
  vat_start_date: string;
  vat_end_date: string;
  income_start_date: string;
  income_end_date: string;
}

interface 사업소득명세서 {
  id: number;
  상호: string;
  사업자등록번호: string;
  총수입금액: string;
  필요경비: string;
  소득금액: string;
}

interface 근로연금기타소득명세서 {
  id: number;
  수득구분코드: string;
  소득지급자_상호: string;
  총수입금액_총급여액: string;
}

interface 기납부세액명세서 {
  기납부세액합계_소득?: string;
}

interface 총수입금액조정명세서 {
  사업자등록번호: string;
  계정과목: string;
  조정수입금액: string;
}

interface 세액의계산 {
  종합소득금액?: string;
  소득공제?: string;
  종합소득세_세액감면?: string;
  종합소득세_세액공제?: string;
  종합소득세_납부할총세액?: string;
}

interface 일반과세자신고서 {
  매출과세세금계산서발급금액: string;
  매출과세매입자발행세금계산서금액: string;
  매출과세카드현금발행금액: string;
  매출과세기타금액: string;
  차감납부할세액: string;
  과세표준금액: string;
  산출세액: string;
  매입세금계산서수취일반금액: string;
  매입세금계산서수취고정자산금액: string;
  매입기타공제매입금액: string;
  공제받지못할매입합계금액: string;
  차감합계금액: string;
  차감합계세액: string;
  환급세액: string;
  경감공제합계세액: string;
  예정신고미환급세액: string;
  예정고지세액: string;
  가산세액계: string;
  소규모개인사업자부가가치세감면세액: string;
}

interface 간이과세자신고서 {
  산출세액: string;
  매입세금계산서공제세액: string;
  공제세액: string;
  매입자납부특례기납부세액: string;
  예정고지세액: string;
  가산세액세액합계: string;
  차감납부할세액: string;
}

interface 법인세과세표준및세액신고서 {
  수입금액: string;
  과세표준_계: string;
  산출세액_계: string;
  총부담세액_계: string;
  기납부세액_계: string;
  차감납부세액: string;
}

interface 표준손익계산서 {
  계정과목코드: string;
  금액: string;
}

interface 공제감면세액및추가납부세액합계표갑 {
  구분코드: string;
  감면세액: string;
}

interface 농어촌특별세과세표준및세액조정계산서 {
  세액: string;
}

export interface Report {
  id: number;
  name: string;
  has_co_invester: boolean;
  traders: Trader[];
  trader_count: number;
  due_date?: string;
  period_begin?: string;
  period_end?: string;
  parsed: {
    사업소득명세서?: 사업소득명세서[];
    근로연금기타소득명세서?: 근로연금기타소득명세서[];
    기납부세액명세서?: 기납부세액명세서;
    총수입금액조정명세서?: 총수입금액조정명세서[];
    세액의계산?: 세액의계산;
    일반과세자신고서?: 일반과세자신고서;
    간이과세자신고서?: 간이과세자신고서;
    법인세과세표준및세액신고서?: 법인세과세표준및세액신고서;
    표준손익계산서?: 표준손익계산서[];
    공제감면세액및추가납부세액합계표갑?: 공제감면세액및추가납부세액합계표갑[];
    농어촌특별세과세표준및세액조정계산서?: 농어촌특별세과세표준및세액조정계산서;
  };
  confirmed: boolean;
}
