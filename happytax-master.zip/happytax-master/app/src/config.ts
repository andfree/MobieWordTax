export const config = Object.freeze({
  backendUri: 'https://mobiletax.kr',
  graphqlUri: 'wss://mobiletax.kr/graphql/',
});
