import { Dashboard } from './Dashboard';
import { Manager } from './Manager';
import Login from './Login';

export { Dashboard, Manager, Login };
