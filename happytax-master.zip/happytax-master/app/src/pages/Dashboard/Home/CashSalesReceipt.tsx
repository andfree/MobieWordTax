import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Box,
  Container,
  List,
  ListItem,
  ListItemText,
  ListSubheader,
  Paper,
} from '@material-ui/core';
import { Trader } from '../../../types/Report';
import { useListStyles } from '../../../styles/list';
import { config } from '../../../config';

interface CashSalesReceipt {
  id: number;
  used_date: string;
  company_nm: string;
  supply_value: number;
  vat: number;
}

interface CashSalesReceiptProps {
  trader: Trader;
  type: string;
}

function CashSalesReceipt(props: CashSalesReceiptProps): JSX.Element {
  const { trader, type } = props;
  const [receipts, setReceipts] = useState<CashSalesReceipt[]>([]);
  const [receiptsByDate, setReceiptsByDate] = useState<{
    [date: string]: CashSalesReceipt[];
  }>({});
  const classes = useListStyles();

  const start_date =
    type === 'vat' ? trader.vat_start_date : trader.income_start_date;
  const end_date =
    type === 'vat' ? trader.vat_end_date : trader.income_end_date;

  useEffect(() => {
    const receiptsByDate: { [date: string]: CashSalesReceipt[] } = {};
    for (const receipt of receipts) {
      const key = new Date(receipt.used_date).toLocaleDateString();
      const list = receiptsByDate[key] || [];
      list.push(receipt);
      receiptsByDate[key] = list;
    }
    setReceiptsByDate(receiptsByDate);
  }, [receipts]);

  useEffect(() => {
    axios
      .get(`${config.backendUri}/api/v2/cash-sales-receipts/`, {
        params: {
          hometax__trader: trader.id,
          issue_date__gte: start_date,
          issue_date__lte: end_date,
        },
      })
      .then(({ data }) => {
        setReceipts(data.results);
      });
  }, [trader.id, start_date, end_date]);

  return (
    <Container>
      <Box my={2}>
        <List>
          <Paper>
            {Object.keys(receiptsByDate).map((date) => (
              <li key={date}>
                <ul className={classes.noPadding}>
                  <ListSubheader className={classes.subheader}>
                    <div className={classes.row}>
                      <ListItemText
                        primary={new Date(date).toLocaleDateString()}
                      />
                      <ListItemText
                        className={classes.price}
                        primary={
                          receiptsByDate[date]
                            .reduce(
                              (acc, receipt) => acc + receipt.supply_value,
                              0
                            )
                            .toLocaleString() + '원'
                        }
                        secondary={
                          receiptsByDate[date]
                            .reduce((acc, receipt) => acc + receipt.vat, 0)
                            .toLocaleString() + '원'
                        }
                      />
                    </div>
                  </ListSubheader>
                  {receiptsByDate[date].map(
                    ({ id, company_nm, supply_value, vat }) => (
                      <ListItem key={id}>
                        <ListItemText
                          primary={company_nm}
                          className={classes.caption}
                        />
                        <ListItemText
                          primary={supply_value.toLocaleString() + '원'}
                          secondary={vat.toLocaleString() + '원'}
                          className={classes.price}
                        />
                      </ListItem>
                    )
                  )}
                </ul>
              </li>
            ))}
          </Paper>
        </List>
      </Box>
    </Container>
  );
}

export default CashSalesReceipt;
