from datetime import datetime

from django.conf.urls import include, url
from django.contrib import admin
from django.contrib.staticfiles.views import serve
from django.views.decorators.csrf import csrf_exempt
from djangox.route import discover_controllers
from graphene_django.views import GraphQLView
from rest_framework import generics, routers, serializers
from rest_framework.authentication import SessionAuthentication
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.utils import datetime_to_epoch
from rest_framework_simplejwt.views import TokenViewBase, TokenRefreshView

import accounting.controllers
import accounting.manager
import accounting.api
import accounting.api2
from accounting.controllers.welcome import vat_with_mobiletax

router = routers.DefaultRouter()
router.register('users', accounting.api.UsersViewSet, basename='users')
router.register('invoices', accounting.api.InvoicesViewSet, basename='invoices')
router.register('traders', accounting.api.TradersViewSet, basename='traders')
router.register('attachments', accounting.api.AttachmentViewSet, basename='attachments')
router.register('employees', accounting.api.EmployeeViewSet, basename='employee')
router.register('salaries', accounting.api.SalariesViewSet, basename='salary')
router.register('journalentries', accounting.api.JournalEntryViewSet)
router.register('customfields', accounting.api.CustomFieldViewSet)
router.register('accounttitles', accounting.api.AccountTitleViewSet)

router2 = routers.DefaultRouter()
router2.register('users', accounting.api2.UserViewSet)
router2.register('traders', accounting.api2.TraderViewSet)
router2.register('messages', accounting.api2.MessageViewSet)
router2.register('boilerplates', accounting.api2.BoilerplateViewSet)
router2.register('reports', accounting.api2.ReportViewSet, basename='reports')
router2.register('connected-ids', accounting.api2.ConnectedIdViewSet)
router2.register('hometaxes', accounting.api2.HometaxViewSet)
router2.register('accounts', accounting.api2.AccountViewSet)
router2.register('card-sales', accounting.api2.CardSalesViewSet)
router2.register('card-approvals', accounting.api2.CardApprovalViewSet)
router2.register('card-sales-approvals', accounting.api2.CardSalesApprovalViewSet)
router2.register('checks', accounting.api2.CheckViewSet)
router2.register('withholding-taxes', accounting.api2.WithholdingTaxViewSet)
router2.register('cash-sales-receipts', accounting.api2.CashSalesReceiptViewSet)
router2.register('cash-purchase-receipts', accounting.api2.CashPurchaseReceiptViewSet)


class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token.payload['exp'] = datetime_to_epoch(datetime.max)
        return token


class TokenizeSerializer(MyTokenObtainPairSerializer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        del self.fields[self.username_field]
        del self.fields['password']

    def validate(self, attrs):
        refresh = self.get_token(self.context['request'].user)

        return {
            'refresh': str(refresh),
            'access': str(refresh.access_token)
        }


class CsrfExemptSessionAuthentication(SessionAuthentication):
    def enforce_csrf(self, request):
        pass


class TokenObtainPairView(TokenViewBase):
    authentication_classes = [CsrfExemptSessionAuthentication]

    def get_serializer_class(self):
        if self.request.user.is_authenticated:
            return TokenizeSerializer

        return MyTokenObtainPairSerializer


urlpatterns = [
    # Examples:
    # url(r'^$', 'happytax.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', admin.site.urls),
    url(r'manager/', discover_controllers(accounting.manager)),
    url(r'^api/token/$', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    url(r'^api/token/refresh/$', TokenRefreshView.as_view(), name='token_refresh'),
    url(r'^api/v1/', include(router.urls)),
    url(r'^api/v2/', include(router2.urls)),
    url('^welcome/vat-with-mobiletax', vat_with_mobiletax),
    url(r'', discover_controllers(accounting.controllers)),
    url(r'^static/(?P<path>.+)', serve, kwargs={'insecure': True}),
    url(r'^graphql/$', csrf_exempt(GraphQLView.as_view(graphiql=True)))
]

handler403 = 'accounting.controllers.errors.permission_denied'
handler404 = 'accounting.controllers.errors.not_found'
handler500 = 'accounting.controllers.errors.server_error'
