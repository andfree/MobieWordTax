"""
Django settings for happytax project.

For more information on this file, see
https://docs.djangoproject.com/en/1.7/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/1.7/ref/settings/
"""

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
import os
from django.contrib.humanize.templatetags import humanize
from django.utils.formats import localize
from django.utils.translation import ugettext

from accounting import format
from accounting.util import get_utm_string, get_utm

BASE_DIR = os.path.dirname(os.path.dirname(__file__))

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.7/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'fmc(o6re8^_m=w1r627p8@*(6adq=ockzg11%@xvzf0jt2j13&'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = ['*']


# Application definition

INSTALLED_APPS = (
    'channels',
    'bs4tl',
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django_extensions',
    'djangox.apps.tools',
    'rest_framework',
    'rest_framework.authtoken',
    'accounting',
    'marketing',
    'django_celery_results',
    'django_filters',
    'corsheaders',
    'rest_framework_simplejwt.token_blacklist',
    'graphene_django',
    'constance',
    # Should go after apps which need to remove files
    'django_cleanup',
)

MIDDLEWARE = (
    'corsheaders.middleware.CorsMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'accounting.util.DeviceMiddleware',
    'accounting.util.VersionMiddleware',
)

ROOT_URLCONF = 'happytax.urls'

WSGI_APPLICATION = 'happytax.wsgi.application'


# Database
# https://docs.djangoproject.com/en/1.7/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': 'happytax',
        'USER': 'happytax',
        'PASSWORD': 'lawandtax',
        'HOST': 'localhost'
    }
}

# Internationalization
# https://docs.djangoproject.com/en/1.7/topics/i18n/

LANGUAGE_CODE = 'ko-KR'

TIME_ZONE = 'Asia/Seoul'

USE_I18N = True

USE_L10N = True

USE_TZ = True


# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.7/howto/static-files/

STATIC_URL = '/static/'

# Auth

AUTH_USER_MODEL = 'accounting.User'

SESSION_COOKIE_AGE = 60 * 60 * 24 * 180  # 180 days

SESSION_SAVE_EVERY_REQUEST = True

SESSION_SERIALIZER = 'django.contrib.sessions.serializers.PickleSerializer'


TEMPLATES = [
    {
        'BACKEND': 'djangox.mako.MakoTemplateEngine',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'django.template.context_processors.csrf',
            ],
            'apps': [
                'accounting',
            ],
        },
    },
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

import django.conf

MAKO_DEFAULT_CONTEXT = {
    'humanize': humanize,
    'localize': localize,
    '_': ugettext,
    'format_to_minute': format.format_to_minutes,
    'won': format.won,
    'format': format,
    'business_registration_no': format.business_registration_no,
    'resident_registration_number': format.resident_registration_number,
    'get_utm': get_utm,
    'get_utm_string': get_utm_string,
    'settings': django.conf.settings
}

from django.contrib.messages import constants as message_constants
MESSAGE_TAGS = {message_constants.ERROR: 'danger'}

DEFAULT_FILE_STORAGE = 'accounting.s3boto.S3BotoStorage'
AWS_ACCESS_KEY_ID = 'AKIAIWRB4IJZPFZZJG3Q'
AWS_SECRET_ACCESS_KEY = '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'
AWS_STORAGE_BUCKET_NAME = 'happytax-vouchers'
AWS_S3_FILE_OVERWRITE = False
AWS_DEFAULT_ACL = 'private'
# AWS_QUERYSTRING_AUTH = False # querystring auth prevent using browser cache.

ITEMS_PER_PAGE = 50
CARDS_PER_PAGE = 10
MESSAGE_SIZE = 15

FAX_NUMBER = '02-529-1018'
LINKHUB_LINK_ID = 'LAWNTAX'
LINKHUB_SECRET_KEY = '/L9JlvCyG11bGJ/szDImcX3AFHPiCdUPiFMVsxDJq4E='
LINKHUB_USER = 'lawntax'
LINKHUB_CORPORATE_NUMBER = '2648114975'
LINKHUB_IS_TEST = True

GCM_API_KEY = 'AIzaSyDbOrgLgtKixMYBT1gSBNVqepecxfKvyf4'
GOOGLE_ANALYTICS_VIEW_ID = '101931245'
GOOGLE_ANALYTICS_TRACKING_ID = 'UA-49895600-2'
MIXPANEL_TOKEN = 'ade41486e669ae74f0c53f42c557700d'

FCM_API_KEY = 'AAAAZj3ZaH8:APA91bGZSO5CFdJ3fZnG0LAT4F6CfwFAHq_cQLcNhDbTfMlhA-eXzaDhN7KXovqBwGrrXnUh4F67CIWNv20JSU85gOIs5ltmLS19dye3AWQbGUlLrK9ar4cLVe2WI5WVWe5UzZLcZhcL'
FCM_MESSAGE_SEND_URL = 'https://fcm.googleapis.com/fcm/send'

EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_HOST_USER = 'contact@mobiletax.kr'
EMAIL_HOST_PASSWORD = 'ahxor0418'
EMAIL_USE_TLS = True
DEFAULT_FROM_EMAIL = '모바일택스 <contact@mobiletax.kr>'

EMAIL_VALIDATION_HOST = 'http://localhost:8000'

# SLACK_BOT_TOKEN = 'xoxb-16800609104-W1RLLkZA5xAR3ptUTxqvWXd3'
# SLACK_BOT_TOKEN = 'xoxb-16800609104-8ZKU0o7ToZTP86MjD1wBSL9n'
# SLACK_BOT_TOKEN = 'xoxb-16800609104-GrOZrQW2a3XFMv4wKL0SKin9'
# regenerated by devteam 2019-03-18
SLACK_BOT_TOKEN = 'xoxb-16800609104-LhMFpGZSsmEX9uErj8cok4aC'
SLACK_BOT_CHANNEL = '#client'
SLACK_BOT_CRITICAL_REPORT_TO = '#dev-slack-report'


# Django rest framework

REST_FRAMEWORK = {
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticated',
    ),
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
        'rest_framework.authentication.SessionAuthentication',
        'rest_framework.authentication.BasicAuthentication',
    ),
    'DEFAULT_PAGINATION_CLASS': 'accounting.paginations.Pagination',
    'DEFAULT_FILTER_BACKENDS': ('django_filters.rest_framework.DjangoFilterBackend',)
}

COLLECT_ERROR_LOG = False

MANAGER_NOTIFICATION_DELAY = 10
UNREAD_MANAGER_NOTIFICATION_DELAY = 60 * 5


# Hometax
AGENT_ID = 'mobiletax'
AGENT_NAME = '한성회계법인'
AGENT_PRESIDENT_NAME = '전정현'

AGENT_NUMBER = '02-2038-8914'
AGENT_BUSINESS_NUMBER = '107-87-46934'
AGENT_CORPORATE_NUMBER = '254134-0017197'
AGENT_MANAGEMENT_NUMBER = 'C30045'

AGENT_ADDRESS = '서울특별시 서초구  동광로 6  (방배동)한덕빌딩 2층 3층 5층'
AGENT_DONG_CODE = '1165010100'

TAX_OFFICE_CODE = '114'

MANAGER_SPA_URL = 'http://localhost:8080/'

# MOBILETAX
MOBILETAX_NUMBER = '1833-8332'

# Alimtalk
ALIMTALK_CODE = {
    'WELCOME': 'API0001',
    'COUNSEL_APPLY_COMPLETE': 'API0002',
    'COUNSEL_TIME': 'API0003',
    'FULLSVC_INTRO': 'API0004',
    'FULLSVC_THANKS': 'API0005',
    'MYMANAGER': 'API0006',

    'V15_COUNSEL': 'APIV101',
}


# Configuring the ASGI application

ASGI_APPLICATION = 'happytax.routing.application'


# Cors

CORS_ALLOW_CREDENTIALS = True
CORS_ORIGIN_WHITELIST = ['https://app.mobiletax.kr', 'http://mobiletax.kr:3000']


DATA_UPLOAD_MAX_MEMORY_SIZE = 10 * 1024 * 1024


# Channel

CHANNEL_LAYERS = {
    'default': {
        'BACKEND': 'channels_redis.core.RedisChannelLayer',
        'CONFIG': {
            'hosts': [('localhost', 6379)],
        },
    },
}


# Graphql

GRAPHENE = {
    'SCHEMA': 'accounting.schema.graphql_schema',
}


# For backward compatibility

FILE_CHARSET = 'utf-8'


# Django constance

CONSTANCE_CONFIG = {
    'CODEF_ACCESS_TOKEN': ('', 'Codef access token'),
    'CODEF_SANDBOX_ACCESS_TOKEN': ('', 'Codef sandbox access token'),
}


# Codef

CODEF_SANDBOX = True

CODEF_ENDPOINT = 'https://sandbox.codef.io'

CODEF_PUBLIC_KEY = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApi94R77seiR8ClEDvLFuRGfR6S1iyT76390gUzUkhuwd0sR248PhuMMWLXZ/25o9s1mmCuF8r3Ixzl3KQ+Xcu0SXrnTuHHXcOVbRqY6IbkhgjrMcsE3MLikrR3pAuA1pTgIoqfe+G6+6Fq7R26JLOQkXEkGpdyq2nCn/k4vdbHMWppUL+TEpjNCKeWAcb6G93E47nt/ZLX83k8tAuWGWzh9Men6PTi03dh9yiCUoF702fp+tpNHgvLoYo9U6te1/Vpr3f9zKE+XWjHrXFta1ClOL1R5JdKdgdIIEFRtEYm9vNgKtP0Wz/Zg4oVU1notpdBchYia0M4G/BvsL8wdBywIDAQAB'

CODEF_CLIENT_ID = 'ef27cfaa-10c1-4470-adac-60ba476273f9'

CODEF_CLIENT_SECRET = '83160c33-9045-4915-86d8-809473cdf5c3'


# Logger

def skip_polling(record):
    if record.args['path'].startswith('/channels/messages'):
        return False

    return True


LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'filters': {
        'skip_polling': {
            '()': 'django.utils.log.CallbackFilter',
            'callback': skip_polling,
        },
    },
    'formatters': {
        'django.server': {
            '()': 'django.utils.log.ServerFormatter',
            'format': '[{server_time}] {message}',
            'style': '{',
        }
    },
    'handlers': {
        'django.server': {
            'level': 'INFO',
            'filters': ['skip_polling'],
            'class': 'logging.StreamHandler',
            'formatter': 'django.server',
        },
    },
    'loggers': {
        'django.channels.server': {
            'handlers': ['django.server'],
            'level': 'INFO',
            'propagate': False,
        },
    }
}


# Production

try:
    from .production import *
except ModuleNotFoundError:
    pass
