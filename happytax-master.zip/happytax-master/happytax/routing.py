import channels_graphql_ws
from channels.routing import ProtocolTypeRouter, URLRouter
from django.contrib.auth.models import AnonymousUser
from django.urls import path

from accounting.schema import graphql_schema


class GraphqlWsConsumer(channels_graphql_ws.GraphqlWsConsumer):
    schema = graphql_schema


class TokenAuthMiddleware:
    def __init__(self, inner):
        self.inner = inner

    def __call__(self, scope):
        scope['user'] = AnonymousUser()
        return self.inner(scope)


application = ProtocolTypeRouter({
    'websocket': TokenAuthMiddleware(
        URLRouter([
            path('graphql/', GraphqlWsConsumer)
        ])
    ),
})
