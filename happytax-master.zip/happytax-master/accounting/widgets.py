from django.forms import DateInput


class MonthInput(DateInput):
    pass