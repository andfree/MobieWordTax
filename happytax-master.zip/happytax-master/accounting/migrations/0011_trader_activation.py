# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0010_auto_20150305_0733'),
    ]

    operations = [
        migrations.AddField(
            model_name='trader',
            name='activation',
            field=models.CharField(max_length=100, choices=[('require_information', '추가정보 필요'), ('require_payment', '결제 안됨'), ('activated', '활성화됨')], default='require_information'),
            preserve_default=True,
        ),
    ]
