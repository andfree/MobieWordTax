# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.contrib.auth.models


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0045_auto_20151113_1757'),
    ]

    operations = [
        migrations.AlterModelManagers(
            name='user',
            managers=[
                ('objects', django.contrib.auth.models.UserManager()),
            ],
        ),
        migrations.AlterField(
            model_name='invoice',
            name='consumer_email',
            field=models.EmailField(blank=True, null=True, max_length=254, verbose_name='공급받는자 이메일'),
        ),
        migrations.AlterField(
            model_name='invoice',
            name='consumer_email_sub',
            field=models.EmailField(blank=True, null=True, max_length=254, verbose_name='공급받는자 이메일2'),
        ),
        migrations.AlterField(
            model_name='invoice',
            name='supplier_email',
            field=models.EmailField(blank=True, null=True, max_length=254, verbose_name='공급자 이메일'),
        ),
        migrations.AlterField(
            model_name='user',
            name='email',
            field=models.EmailField(verbose_name='email address', blank=True, max_length=254),
        ),
        migrations.AlterField(
            model_name='user',
            name='groups',
            field=models.ManyToManyField(verbose_name='groups', related_name='user_set', to='auth.Group', related_query_name='user', blank=True, help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.'),
        ),
        migrations.AlterField(
            model_name='user',
            name='last_login',
            field=models.DateTimeField(blank=True, null=True, verbose_name='last login'),
        ),
        migrations.AlterField(
            model_name='user',
            name='username',
            field=models.CharField(verbose_name='username', help_text='Required. 30 characters or fewer. Letters, digits and @/./+/-/_ only.', error_messages={'unique': 'A user with that username already exists.'}, max_length=200, unique=True),
        ),
    ]
