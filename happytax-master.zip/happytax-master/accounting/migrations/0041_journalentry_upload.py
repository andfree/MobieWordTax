# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0040_auto_20150709_1527'),
    ]

    operations = [
        migrations.AddField(
            model_name='journalentry',
            name='upload',
            field=models.ForeignKey(null=True, blank=True, to='accounting.DataUpload', on_delete=models.CASCADE),
            preserve_default=True,
        ),
    ]
