# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0004_user_client_set'),
    ]

    operations = [
        migrations.AddField(
            model_name='message',
            name='done',
            field=models.DateTimeField(blank=True, null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='message',
            name='read',
            field=models.DateTimeField(blank=True, null=True),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='message',
            name='content',
            field=models.TextField(verbose_name='본문'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='message',
            name='title',
            field=models.CharField(verbose_name='제목', max_length=200),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='message',
            name='type',
            field=models.CharField(choices=[('statement', '신고서'), ('payment-paper', '납부서'), ('information-request', '자료요청'), ('notice', '공지사항')], verbose_name='메세지 종류', max_length=100),
            preserve_default=True,
        ),
    ]
