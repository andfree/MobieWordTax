# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0019_auto_20150325_0934'),
    ]

    operations = [
        migrations.CreateModel(
            name='Post',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True, verbose_name='ID', auto_created=True)),
                ('title', models.CharField(max_length=1000)),
                ('content', models.TextField()),
                ('created', models.DateField(auto_now_add=True)),
                ('writer', models.ForeignKey(to=settings.AUTH_USER_MODEL, on_delete=models.CASCADE)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.AlterField(
            model_name='invoice',
            name='invoice_type',
            field=models.CharField(max_length=100, choices=[('sales', '매출'), ('purchases', '매입'), ('receipt', '일반전표')]),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='voucher',
            name='type',
            field=models.CharField(max_length=100, choices=[('unknown', '미확인'), ('receipt', '영수증'), ('invoice', '종이 세금계산서/계산서'), ('salary', '인건비'), ('cash-sales', '현금매출')]),
            preserve_default=True,
        ),
    ]
