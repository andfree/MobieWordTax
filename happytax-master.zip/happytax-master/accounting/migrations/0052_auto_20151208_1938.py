# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0051_auto_20151202_1644'),
    ]

    operations = [
        migrations.AlterField(
            model_name='message',
            name='title',
            field=models.CharField(blank=True, max_length=200, null=True, verbose_name='제목'),
        ),
        migrations.AlterField(
            model_name='message',
            name='type',
            field=models.CharField(max_length=100, choices=[('income-tax-statement', '종합소득세 납부서'), ('vat-statement', '부가가치세 납부서'), ('withholding-tax-statement', '원천세 납부서'), ('information-request', '자료요청'), ('notice', '공지사항'), ('text', '텍스트')], verbose_name='메세지 종류'),
        ),
        migrations.AlterField(
            model_name='trader',
            name='activation',
            field=models.CharField(max_length=100, default='require_information', choices=[('require_information', '비활성'), ('require_payment', '결제 안됨'), ('trying', '활성화 시도중'), ('in_review', '매니저 검토중'), ('activated', '활성화됨'), ('requested_to_delete', '삭제요청됨'), ('test', '테스트 계정')], verbose_name='활성화'),
        ),
    ]
