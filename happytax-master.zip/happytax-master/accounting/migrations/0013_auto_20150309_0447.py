# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import django_extensions.db.fields.json


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0012_tax'),
    ]

    operations = [
        migrations.CreateModel(
            name='Card',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True, auto_created=True, verbose_name='ID')),
                ('expiration_date', models.DateField()),
                ('name', models.CharField(max_length=100)),
                ('number', models.CharField(max_length=100)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.RemoveField(
            model_name='document',
            name='account_id',
        ),
        migrations.RemoveField(
            model_name='document',
            name='account_pw',
        ),
        migrations.RemoveField(
            model_name='document',
            name='agreement',
        ),
        migrations.RemoveField(
            model_name='document',
            name='card_expiration_date',
        ),
        migrations.RemoveField(
            model_name='document',
            name='card_info',
        ),
        migrations.RemoveField(
            model_name='document',
            name='card_name',
        ),
        migrations.AddField(
            model_name='trader',
            name='info',
            field=django_extensions.db.fields.json.JSONField(),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='document',
            name='type',
            field=models.CharField(max_length=100, choices=[('사업자등록증', '사업자등록증'), ('입대차계약서', '임대차계약서'), ('통장사본', '통장사본')]),
            preserve_default=True,
        ),
    ]
