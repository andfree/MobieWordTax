# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0031_message_group'),
        ('accounting', '0031_auto_20150508_1323'),
    ]

    operations = [
    ]
