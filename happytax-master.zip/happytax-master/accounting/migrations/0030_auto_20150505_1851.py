# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0029_auto_20150505_1848'),
    ]

    operations = [
        migrations.AlterField(
            model_name='message',
            name='type',
            field=models.CharField(verbose_name='메세지 종류', max_length=100, choices=[('income-tax', '소득세'), ('vat-normal', '부가가치세 일반과세자'), ('vat-simplified', '부가가치세 간이과세자'), ('income-tax-statement', '종합소득세 납부서'), ('vat-statement', '부가가치세 납부서'), ('withholding-tax-statement', '원천세 납부서'), ('information-request', '자료요청'), ('notice', '공지사항')]),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='tax',
            name='type',
            field=models.CharField(max_length=100, choices=[('income-tax', '소득세'), ('vat-normal', '부가가치세 일반과세자'), ('vat-simplified', '부가가치세 간이과세자'), ('income-tax-statement', '종합소득세 납부서'), ('vat-statement', '부가가치세 납부서'), ('withholding-tax-statement', '원천세 납부서')]),
            preserve_default=True,
        ),
    ]
