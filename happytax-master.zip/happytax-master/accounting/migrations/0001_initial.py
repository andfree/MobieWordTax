# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('auth', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='User',
            fields=[
                ('id', models.AutoField(serialize=False, verbose_name='ID', auto_created=True, primary_key=True)),
                ('password', models.CharField(max_length=128, verbose_name='password')),
                ('last_login', models.DateTimeField(verbose_name='last login', default=django.utils.timezone.now)),
                ('is_superuser', models.BooleanField(verbose_name='superuser status', help_text='Designates that this user has all permissions without explicitly assigning them.', default=False)),
                ('username', models.CharField(max_length=200, unique=True, help_text='Required. 30 characters or fewer. Letters, digits and @/./+/-/_ only.', verbose_name='username')),
                ('first_name', models.CharField(max_length=30, blank=True, verbose_name='first name')),
                ('last_name', models.CharField(max_length=30, blank=True, verbose_name='last name')),
                ('email', models.EmailField(max_length=75, blank=True, verbose_name='email address')),
                ('is_staff', models.BooleanField(verbose_name='staff status', help_text='Designates whether the user can log into this admin site.', default=False)),
                ('is_active', models.BooleanField(verbose_name='active', help_text='Designates whether this user should be treated as active. Unselect this instead of deleting accounts.', default=True)),
                ('date_joined', models.DateTimeField(verbose_name='date joined', default=django.utils.timezone.now)),
                ('phone', models.CharField(max_length=100, blank=True)),
                ('gender', models.CharField(max_length=50, blank=True)),
                ('birthday', models.DateField(null=True, blank=True)),
                ('groups', models.ManyToManyField(verbose_name='groups', help_text='The groups this user belongs to. A user will get all permissions granted to each of his/her group.', related_query_name='user', to='auth.Group', related_name='user_set', blank=True)),
                ('user_permissions', models.ManyToManyField(verbose_name='user permissions', help_text='Specific permissions for this user.', related_query_name='user', to='auth.Permission', related_name='user_set', blank=True)),
            ],
            options={
                'verbose_name_plural': 'users',
                'verbose_name': 'user',
                'abstract': False,
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Invoice',
            fields=[
                ('id', models.AutoField(serialize=False, verbose_name='ID', auto_created=True, primary_key=True)),
                ('invoice_type', models.CharField(max_length=100, choices=[('매입', '매입'), ('매출', '매출')])),
                ('issue_id', models.CharField(max_length=100)),
                ('written', models.DateField()),
                ('issued', models.DateField()),
                ('sent', models.DateField()),
                ('supplier_no', models.CharField(max_length=100)),
                ('supplier_sub_no', models.CharField(max_length=100)),
                ('supplier_name', models.CharField(max_length=200)),
                ('supplier_representative', models.CharField(max_length=200)),
                ('supplier_email', models.EmailField(max_length=75)),
                ('consumer_no', models.CharField(max_length=100)),
                ('consumer_sub_no', models.CharField(max_length=100, blank=True)),
                ('consumer_name', models.CharField(max_length=200)),
                ('consumer_representative', models.CharField(max_length=200)),
                ('consumer_email', models.EmailField(max_length=75, blank=True)),
                ('consumer_email_sub', models.EmailField(max_length=75, blank=True)),
                ('value_of_supply', models.DecimalField(decimal_places=0, max_digits=20)),
                ('vat', models.DecimalField(decimal_places=0, max_digits=20)),
                ('total', models.DecimalField(decimal_places=0, max_digits=20)),
                ('tax_invoice_type', models.CharField(max_length=100)),
                ('tax_type', models.CharField(max_length=100)),
                ('issue_type', models.CharField(max_length=100)),
                ('tax_invoice_purpose', models.CharField(max_length=100)),
                ('note', models.TextField(blank=True)),
                ('etc', models.TextField(blank=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='InvoiceItem',
            fields=[
                ('id', models.AutoField(serialize=False, verbose_name='ID', auto_created=True, primary_key=True)),
                ('date', models.DateField()),
                ('norm', models.CharField(max_length=100)),
                ('quantity', models.IntegerField()),
                ('unit_price', models.DecimalField(decimal_places=0, max_digits=20)),
                ('value_of_supply', models.DecimalField(decimal_places=0, max_digits=20)),
                ('vat', models.DecimalField(decimal_places=0, max_digits=20)),
                ('invoice', models.ForeignKey(to='accounting.Invoice', on_delete=models.CASCADE)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Trader',
            fields=[
                ('id', models.AutoField(serialize=False, verbose_name='ID', auto_created=True, primary_key=True)),
                ('registration_no', models.CharField(max_length=100, blank=True)),
                ('business_name', models.CharField(max_length=200, blank=True)),
                ('business_type', models.CharField(max_length=100, blank=True)),
                ('business_condition', models.CharField(max_length=100, blank=True)),
                ('created', models.DateTimeField(auto_now_add=True)),
                ('updated', models.DateTimeField(auto_now=True)),
                ('user', models.ForeignKey(null=True, to=settings.AUTH_USER_MODEL, blank=True, on_delete=models.CASCADE)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Voucher',
            fields=[
                ('id', models.AutoField(serialize=False, verbose_name='ID', auto_created=True, primary_key=True)),
                ('type', models.CharField(max_length=100, choices=[('사진', '사진'), ('엑셀', '엑셀')])),
                ('file', models.FileField(upload_to='')),
                ('created', models.DateTimeField(auto_now_add=True)),
                ('processed', models.DateTimeField(null=True, blank=True)),
                ('trader', models.ForeignKey(to='accounting.Trader', on_delete=models.CASCADE)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='invoice',
            name='trader',
            field=models.ForeignKey(to='accounting.Trader', on_delete=models.CASCADE),
            preserve_default=True,
        ),
    ]
