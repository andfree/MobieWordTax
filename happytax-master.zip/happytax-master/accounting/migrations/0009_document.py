# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0008_auto_20150226_0751'),
    ]

    operations = [
        migrations.CreateModel(
            name='Document',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('type', models.CharField(max_length=100, choices=[('사업자등록증', '사업자등록증'), ('입대차계약서', '임대차계약서'), ('통장사본', '통장사본')])),
                ('state', models.CharField(max_length=100, choices=[('파일없음', '파일없음'), ('승인', '승인'), ('재업로드', '재업로드'), ('업로드완료', '업로드완료')])),
                ('file', models.FileField(upload_to='')),
                ('created', models.DateTimeField(auto_now_add=True)),
                ('processed', models.DateTimeField(null=True, blank=True)),
                ('trader', models.ForeignKey(to='accounting.Trader', on_delete=models.CASCADE)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
    ]
