# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0026_auto_20150415_1001'),
    ]

    operations = [
        migrations.AddField(
            model_name='message',
            name='due',
            field=models.DateTimeField(blank=True, null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='message',
            name='mimetype',
            field=models.CharField(max_length=100, default='text/plain'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='tax',
            name='due',
            field=models.DateTimeField(blank=True, null=True),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='message',
            name='type',
            field=models.CharField(max_length=100, choices=[('income-tax', '소득세'), ('vat-normal', '부가가치세 일반과세자'), ('vat-simplified', '부가가치세 간이과세자'), ('income-tax-statement', '종합소득세 납부서'), ('vat-statement', '부가가치세 납부서'), ('information-request', '자료요청'), ('notice', '공지사항')], verbose_name='메세지 종류'),
            preserve_default=True,
        ),
    ]
