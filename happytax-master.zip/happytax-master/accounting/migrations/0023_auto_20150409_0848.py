# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import django_extensions.db.fields.json


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0022_auto_20150402_1639'),
    ]

    operations = [
        migrations.AddField(
            model_name='tax',
            name='file',
            field=models.FileField(blank=True, null=True, upload_to=''),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='tax',
            name='info',
            field=django_extensions.db.fields.json.JSONField(),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='invoice_type',
            field=models.CharField(choices=[('sales', '매출'), ('purchases', '매입'), ('receipt', '일반경비')], max_length=100),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='tax',
            name='type',
            field=models.CharField(choices=[('income-tax', '소득세'), ('vat-normal', '부가가치세 일반과세자'), ('vat-simplified', '부가가치세 간이과세자'), ('income-tax-statement', '종합소득세 납부서'), ('vat-statement', '부가가치세 납부서')], max_length=100),
            preserve_default=True,
        ),
    ]
