# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0014_auto_20150309_0920'),
    ]

    operations = [
        migrations.AddField(
            model_name='card',
            name='cvc',
            field=models.CharField(default='', max_length=100),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='card',
            name='trader',
            field=models.ForeignKey(default='', to='accounting.Trader', on_delete=models.CASCADE),
            preserve_default=False,
        ),
    ]
