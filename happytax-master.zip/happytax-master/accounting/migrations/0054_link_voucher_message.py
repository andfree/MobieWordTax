# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


def create_messages_for_vouchers(apps, schema_editor):
    Voucher = apps.get_model('accounting', 'Voucher')
    Message = apps.get_model('accounting', 'Message')
    ContentType = apps.get_model('contenttypes', 'ContentType')
    for voucher in Voucher.objects.all():
        message = Message.objects.create(
            trader=voucher.trader,
            sender=voucher.trader.user,
            type='voucher',
            title='증빙자료',
            content=voucher.file.name or voucher.get_type_display(),
            content_type=ContentType.objects.get_for_model(Voucher),
            content_id=voucher.id,
        )
        Message.objects.filter(id=message.id).update(created=voucher.created)


def delete_messages_for_voucher(apps, schema_editor):
    Voucher = apps.get_model('accounting', 'Voucher')
    Message = apps.get_model('accounting', 'Message')
    ContentType = apps.get_model('contenttypes', 'ContentType')
    Message.objects.filter(content_type=ContentType.objects.get_for_model(Voucher)).delete()


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0053_auto_20151209_1147'),
    ]

    operations = [
        migrations.RunPython(create_messages_for_vouchers, delete_messages_for_voucher)
    ]
