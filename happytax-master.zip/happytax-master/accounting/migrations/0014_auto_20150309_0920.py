# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from decimal import Decimal


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0013_auto_20150309_0447'),
    ]

    operations = [
        migrations.AlterField(
            model_name='invoice',
            name='consumer_email',
            field=models.EmailField(blank=True, null=True, max_length=75, verbose_name='공급받는자 이메일'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='consumer_email_sub',
            field=models.EmailField(blank=True, null=True, max_length=75, verbose_name='공급받는자 이메일2'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='consumer_name',
            field=models.CharField(blank=True, null=True, max_length=200, verbose_name='공급받는자 상호'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='consumer_no',
            field=models.CharField(blank=True, null=True, max_length=100, verbose_name='공급받는자 사업자번호'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='consumer_representative',
            field=models.CharField(blank=True, null=True, max_length=200, verbose_name='공급받는자 대표'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='consumer_sub_no',
            field=models.CharField(blank=True, null=True, max_length=100, verbose_name='공급받는자 종사업장번호'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='issue_id',
            field=models.CharField(blank=True, null=True, max_length=100),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='issue_type',
            field=models.CharField(max_length=100, verbose_name='발급 유형'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='sent',
            field=models.DateField(null=True, blank=True),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='supplier_email',
            field=models.EmailField(blank=True, null=True, max_length=75, verbose_name='공급자 이메일'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='supplier_name',
            field=models.CharField(blank=True, null=True, max_length=200, verbose_name='공급자 상호'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='supplier_no',
            field=models.CharField(blank=True, null=True, max_length=100, verbose_name='공급자 사업자번호'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='supplier_representative',
            field=models.CharField(blank=True, null=True, max_length=200, verbose_name='공급자 대표'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='supplier_sub_no',
            field=models.CharField(blank=True, null=True, max_length=100, verbose_name='공급자 종사업장번호'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='tax_invoice_purpose',
            field=models.CharField(max_length=100, verbose_name='영수/청구 구분'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='tax_invoice_type',
            field=models.CharField(max_length=100, verbose_name='세금계산서 분류'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='tax_type',
            field=models.CharField(max_length=100, verbose_name='세금계산서 종류'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='total',
            field=models.DecimalField(decimal_places=0, max_digits=20, blank=True, default=Decimal('0'), verbose_name='합계금액'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='value_of_supply',
            field=models.DecimalField(decimal_places=0, max_digits=20, blank=True, default=Decimal('0'), verbose_name='공급가액'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='vat',
            field=models.DecimalField(decimal_places=0, max_digits=20, blank=True, default=Decimal('0'), verbose_name='부가세'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='written',
            field=models.DateField(null=True, blank=True),
            preserve_default=True,
        ),
    ]
