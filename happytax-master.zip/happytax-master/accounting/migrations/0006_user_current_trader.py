# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0005_auto_20150212_0703'),
    ]

    operations = [
        migrations.AddField(
            model_name='user',
            name='current_trader',
            field=models.OneToOneField(null=True, related_name='current_user', to='accounting.Trader', on_delete=models.CASCADE),
            preserve_default=True,
        ),
    ]
