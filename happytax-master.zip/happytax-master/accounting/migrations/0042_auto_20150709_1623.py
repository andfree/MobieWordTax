# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0041_journalentry_upload'),
    ]

    operations = [
        migrations.RenameField(
            model_name='journalentry',
            old_name='journalized',
            new_name='issued',
        ),
    ]
