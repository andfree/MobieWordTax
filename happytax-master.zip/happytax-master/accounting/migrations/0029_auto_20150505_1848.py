# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0028_message_info'),
    ]

    operations = [
        migrations.AlterField(
            model_name='message',
            name='due',
            field=models.DateField(null=True, blank=True),
            preserve_default=True,
        ),
    ]
