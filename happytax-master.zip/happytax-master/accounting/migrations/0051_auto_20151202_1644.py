# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from decimal import Decimal


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0050_info_to_memo'),
    ]

    operations = [
        migrations.AddField(
            model_name='tax',
            name='assessment',
            field=models.DecimalField(max_digits=20, decimal_places=0, verbose_name='과세표준', blank=True, default=Decimal('0')),
        ),
        migrations.AddField(
            model_name='tax',
            name='cost',
            field=models.DecimalField(max_digits=20, decimal_places=0, verbose_name='경비', blank=True, default=Decimal('0')),
        ),
        migrations.AddField(
            model_name='tax',
            name='purchases',
            field=models.DecimalField(max_digits=20, decimal_places=0, verbose_name='매입', blank=True, default=Decimal('0')),
        ),
        migrations.AddField(
            model_name='tax',
            name='sales',
            field=models.DecimalField(max_digits=20, decimal_places=0, verbose_name='매출', blank=True, default=Decimal('0')),
        ),
    ]
