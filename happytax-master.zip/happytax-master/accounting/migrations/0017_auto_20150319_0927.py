# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0016_trader_taxation'),
    ]

    operations = [
        migrations.AlterField(
            model_name='trader',
            name='registration_no',
            field=models.CharField(max_length=100, blank=True, unique=True),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='trader',
            name='taxation',
            field=models.CharField(choices=[('normal', '일반과세자'), ('simplified', '간이과세자')], max_length=100, default='normal'),
            preserve_default=True,
        ),
    ]
