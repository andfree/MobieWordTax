# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0043_journalentry_closing'),
    ]

    operations = [
        migrations.AlterField(
            model_name='invoice',
            name='invoice_type',
            field=models.CharField(max_length=100, choices=[('sales', '매출'), ('purchases', '매입')]),
            preserve_default=True,
        ),
    ]
