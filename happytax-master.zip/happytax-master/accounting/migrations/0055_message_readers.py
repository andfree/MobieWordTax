# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0054_link_voucher_message'),
    ]

    operations = [
        migrations.AddField(
            model_name='message',
            name='readers',
            field=models.ManyToManyField(related_name='read_messages', to=settings.AUTH_USER_MODEL),
        ),
    ]
