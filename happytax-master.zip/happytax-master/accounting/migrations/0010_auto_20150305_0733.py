# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0009_document'),
    ]

    operations = [
        migrations.AddField(
            model_name='document',
            name='account_id',
            field=models.CharField(null=True, max_length=100),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='document',
            name='account_pw',
            field=models.CharField(null=True, max_length=100),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='document',
            name='agreement',
            field=models.BooleanField(default=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='document',
            name='card_expiration_date',
            field=models.DateField(null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='document',
            name='card_info',
            field=models.CharField(null=True, max_length=100),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='document',
            name='card_name',
            field=models.CharField(null=True, max_length=100),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='document',
            name='state',
            field=models.CharField(choices=[('확인중', '확인중'), ('승인', '승인'), ('재업로드', '재업로드'), ('업로드완료', '업로드완료')], max_length=100),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='document',
            name='type',
            field=models.CharField(choices=[('사업자등록증', '사업자등록증'), ('입대차계약서', '임대차계약서'), ('통장사본', '통장사본'), ('세무대리인 동의', '세무대리인 동의'), ('CMS 동의', 'CMS 동의'), ('국세청 정보', '국세청 정보'), ('여신금융협회 정보', '여신금융협회 정보'), ('신용카드 정보', '신용카드 정보')], max_length=100),
            preserve_default=True,
        ),
    ]
