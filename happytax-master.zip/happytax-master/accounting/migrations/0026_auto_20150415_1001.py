# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0025_auto_20150413_1017'),
    ]

    operations = [
        migrations.AlterField(
            model_name='user',
            name='current_trader',
            field=models.OneToOneField(null=True, blank=True, related_name='current_user', to='accounting.Trader', on_delete=models.SET_NULL),
            preserve_default=True,
        ),
    ]
