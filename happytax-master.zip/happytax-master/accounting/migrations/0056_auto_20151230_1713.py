# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0055_message_readers'),
    ]

    operations = [
        migrations.AddField(
            model_name='attachment',
            name='manager',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.CASCADE),
        ),
        migrations.AddField(
            model_name='attachment',
            name='mimetype',
            field=models.CharField(max_length=100, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='voucher',
            name='attachment',
            field=models.ForeignKey(to='accounting.Attachment', null=True, blank=True, on_delete=models.CASCADE),
        ),
    ]
