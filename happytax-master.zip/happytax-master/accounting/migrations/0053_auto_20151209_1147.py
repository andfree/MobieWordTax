# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contenttypes', '0002_remove_content_type_name'),
        ('accounting', '0052_auto_20151208_1938'),
    ]

    operations = [
        migrations.AddField(
            model_name='message',
            name='content_id',
            field=models.PositiveIntegerField(null=True, blank=True),
        ),
        migrations.AddField(
            model_name='message',
            name='content_type',
            field=models.ForeignKey(null=True, blank=True, to='contenttypes.ContentType', on_delete=models.SET_NULL),
        ),
        migrations.AlterField(
            model_name='message',
            name='type',
            field=models.CharField(max_length=100, choices=[('income-tax-statement', '종합소득세 납부서'), ('vat-statement', '부가가치세 납부서'), ('withholding-tax-statement', '원천세 납부서'), ('information-request', '자료요청'), ('notice', '공지사항'), ('text', '텍스트'), ('voucher', '증빙자료')], verbose_name='메세지 종류'),
        ),
    ]
