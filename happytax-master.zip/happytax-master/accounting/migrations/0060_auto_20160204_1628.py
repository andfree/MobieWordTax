# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0059_link_dataupload_to_trader'),
    ]

    operations = [
        migrations.AlterField(
            model_name='message',
            name='title',
            field=models.TextField(verbose_name='제목', blank=True, null=True),
        ),
    ]
