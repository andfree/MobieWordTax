# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0038_validation'),
    ]

    operations = [
        migrations.AddField(
            model_name='user',
            name='is_validated',
            field=models.BooleanField(default=False),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='validation',
            name='validated',
            field=models.DateTimeField(blank=True, null=True),
            preserve_default=True,
        ),
    ]
