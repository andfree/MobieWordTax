# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


def trader_info_to_memo(apps, schema_editor):
    Trader = apps.get_model('accounting', 'Trader')
    Memo = apps.get_model('accounting', 'Trader')
    for trader in Trader.objects.all():
        for k, v in trader.info.items():
            if k == 'hometax_account':
                memo = trader.memo_set.create(key='홈택스 계정', value = '%s / %s' % (v['id'], v['password']))
            elif k == 'credit_account':
                memo = trader.memo_set.create(key='여신금융협회 계정', value = '%s / %s' % (v['id'], v['password']))


def trader_info_to_memo_reverse(apps, schema_editor):
    pass

class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0049_auto_20151125_1927'),
    ]

    operations = [
        migrations.RunPython(trader_info_to_memo, trader_info_to_memo_reverse)
    ]
