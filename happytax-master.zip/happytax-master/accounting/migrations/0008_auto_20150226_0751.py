# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0007_auto_20150225_0939'),
    ]

    operations = [
        migrations.RenameField(
            model_name='message',
            old_name='sent',
            new_name='created',
        ),
    ]
