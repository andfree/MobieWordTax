# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0060_auto_20160204_1628'),
    ]

    operations = [
        migrations.AddField(
            model_name='trader',
            name='is_corporation',
            field=models.BooleanField(default=False, verbose_name='법인여부'),
        ),
        migrations.AlterField(
            model_name='message',
            name='type',
            field=models.CharField(max_length=100, verbose_name='메세지 종류', choices=[('income-tax-report', '종합소득세 신고서'), ('vat-report', '부가가치세 신고서'), ('income-tax-statement', '종합소득세 납부서'), ('vat-statement', '부가가치세 납부서'), ('withholding-tax-statement', '원천세 납부서'), ('information-request', '자료요청'), ('notice', '공지사항'), ('text', '텍스트'), ('voucher', '증빙자료'), ('attachment', '첨부파일')]),
        ),
    ]
