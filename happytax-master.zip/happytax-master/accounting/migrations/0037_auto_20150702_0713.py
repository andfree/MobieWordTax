# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0036_voucher_repeat_key'),
    ]

    operations = [
        migrations.CreateModel(
            name='DataUpload',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('file', models.FileField(blank=True, upload_to='', null=True)),
                ('created', models.DateTimeField(auto_now_add=True)),
                ('uploader', models.ForeignKey(to=settings.AUTH_USER_MODEL, on_delete=models.CASCADE)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='invoice',
            name='upload',
            field=models.ForeignKey(blank=True, null=True, to='accounting.DataUpload', on_delete=models.CASCADE),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='voucher_type',
            field=models.CharField(max_length=100, choices=[('전자세금계산서', '전자세금계산서'), ('전자계산서', '전자계산서'), ('종이세금계산서', '종이세금계산서'), ('종이계산서', '종이계산서'), ('카드단말기', '카드단말기'), ('카드사용내역', '카드사용내역'), ('현금영수증', '현금영수증'), ('현금영수증(지출증빙용)', '현금영수증(지출증빙용)'), ('일반전표', '일반전표'), ('카과', '카드과세'), ('카면', '카드면세'), ('현과', '현금과세'), ('현면', '현금면세'), ('과세', '종이세금계산서'), ('면세', '종이계산서'), ('건별', '현금매출'), ('기타', '기타')]),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='message',
            name='type',
            field=models.CharField(max_length=100, verbose_name='메세지 종류', choices=[('income-tax-statement', '종합소득세 납부서'), ('vat-statement', '부가가치세 납부서'), ('withholding-tax-statement', '원천세 납부서'), ('information-request', '자료요청'), ('notice', '공지사항')]),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='trader',
            name='activation',
            field=models.CharField(max_length=100, default='require_information', choices=[('require_information', '추가정보 필요'), ('require_payment', '결제 안됨'), ('activated', '활성화됨'), ('requested_to_delete', '삭제요청됨')]),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='trader',
            name='business_name',
            field=models.CharField(max_length=200, blank=True, verbose_name='상호'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='trader',
            name='registration_no',
            field=models.CharField(max_length=100, blank=True, unique=True, verbose_name='사업자번호'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='user',
            name='current_trader',
            field=models.OneToOneField(blank=True, on_delete=django.db.models.deletion.SET_NULL, related_name='current_user', null=True, to='accounting.Trader'),
            preserve_default=True,
        ),
    ]
