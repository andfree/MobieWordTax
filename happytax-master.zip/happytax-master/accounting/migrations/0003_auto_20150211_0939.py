# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings

from accounting.models import ensure_deleted_user


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0002_auto_20150210_0708'),
    ]

    operations = [
        migrations.CreateModel(
            name='Attachment',
            fields=[
                ('id', models.AutoField(primary_key=True, auto_created=True, serialize=False, verbose_name='ID')),
                ('file', models.FileField(upload_to='')),
                ('created', models.DateTimeField(auto_now_add=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Message',
            fields=[
                ('id', models.AutoField(primary_key=True, auto_created=True, serialize=False, verbose_name='ID')),
                ('type', models.CharField(max_length=100, choices=[('statement', '신고서'), ('payment-paper', '납부서'), ('information-request', '자료요청'), ('notice', '공지사항')])),
                ('title', models.CharField(max_length=200)),
                ('content', models.TextField()),
                ('sent', models.DateTimeField(auto_now_add=True)),
                ('sender', models.ForeignKey(to=settings.AUTH_USER_MODEL, on_delete=models.SET(ensure_deleted_user))),
                ('trader', models.ForeignKey(to='accounting.Trader', on_delete=models.CASCADE)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='attachment',
            name='message',
            field=models.ForeignKey(to='accounting.Message', on_delete=models.CASCADE),
            preserve_default=True,
        ),
    ]
