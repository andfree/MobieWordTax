# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


def allocate_manager_to_attachment_and_link_attachment_to_voucher(apps, schema_editor):
    Attachment = apps.get_model('accounting', 'Attachment')
    Voucher = apps.get_model('accounting', 'Voucher')
    Message = apps.get_model('accounting', 'Message')
    ContentType = apps.get_model('contenttypes', 'ContentType')

    for attachment in Attachment.objects.filter(message__sender__is_staff=True):
        attachment.manager = attachment.message.sender
        attachment.save()

    for voucher in Voucher.objects.filter(preprocessed__isnull=True, type='unknown'):
        message = Message.objects.get(content_type=ContentType.objects.get_for_model(Voucher), content_id=voucher.id)
        attachment = Attachment.objects.create(message=message, file=voucher.file, mimetype=voucher.mimetype)
        voucher.attachment = attachment
        voucher.save()


def rollback(apps, schema_editor):
    pass


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0056_auto_20151230_1713'),
    ]

    operations = [
        migrations.RunPython(allocate_manager_to_attachment_and_link_attachment_to_voucher, rollback)
    ]
