# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0018_auto_20150323_1045'),
    ]

    operations = [
        migrations.CreateModel(
            name='Receipt',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True, serialize=False)),
                ('account_title', models.CharField(max_length=100)),
                ('counterpart_name', models.CharField(max_length=1000)),
                ('amount', models.DecimalField(max_digits=20, decimal_places=0)),
                ('issued', models.DateField()),
                ('description', models.TextField()),
                ('trader', models.ForeignKey(to='accounting.Trader', on_delete=models.CASCADE)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.RemoveField(
            model_name='invoiceitem',
            name='invoice',
        ),
        migrations.DeleteModel(
            name='InvoiceItem',
        ),
        migrations.RenameField(
            model_name='invoice',
            old_name='etc',
            new_name='description',
        ),
        migrations.RemoveField(
            model_name='invoice',
            name='issue_type',
        ),
        migrations.RemoveField(
            model_name='invoice',
            name='note',
        ),
        migrations.RemoveField(
            model_name='invoice',
            name='tax_invoice_purpose',
        ),
        migrations.RemoveField(
            model_name='invoice',
            name='tax_invoice_type',
        ),
        migrations.RemoveField(
            model_name='invoice',
            name='tax_type',
        ),
        migrations.AddField(
            model_name='invoice',
            name='account_title',
            field=models.CharField(blank=True, null=True, max_length=100),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='invoice',
            name='product_name',
            field=models.CharField(blank=True, null=True, max_length=1000),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='invoice',
            name='voucher_type',
            field=models.CharField(choices=[('전자세금계산서', '전자세금계산서'), ('전자계산서', '전자계산서'), ('종이세금계산서', '종이세금계산서'), ('종이계산서', '종이계산서'), ('카드단말기', '카드단말기'), ('카드사용내역', '카드사용내역'), ('현금영수증', '현금영수증'), ('현금영수증(지출증빙용)', '현금영수증(지출증빙용)'), ('일반전표', '일반전표'), ('기타', '기타')], default='기타', max_length=100),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name='invoice',
            name='invoice_type',
            field=models.CharField(choices=[('sales', '매입'), ('purchases', '매출'), ('receipt', '일반전표')], max_length=100),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='voucher',
            name='file',
            field=models.FileField(blank=True, null=True, upload_to=''),
            preserve_default=True,
        ),
    ]
