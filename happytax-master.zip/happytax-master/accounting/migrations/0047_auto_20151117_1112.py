# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0046_auto_20151116_1910'),
    ]

    operations = [
        migrations.AlterField(
            model_name='trader',
            name='accounting_manager',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL, null=True, related_name='accounting_client_set', verbose_name='기장총괄', blank=True, on_delete=models.SET_NULL),
        ),
        migrations.AlterField(
            model_name='trader',
            name='activation',
            field=models.CharField(max_length=100, choices=[('require_information', '추가정보 필요'), ('require_payment', '결제 안됨'), ('activated', '활성화됨'), ('requested_to_delete', '삭제요청됨')], verbose_name='활성화', default='require_information'),
        ),
        migrations.AlterField(
            model_name='trader',
            name='cms_activated',
            field=models.DateTimeField(null=True, verbose_name='CMS 등록일', blank=True),
        ),
        migrations.AlterField(
            model_name='trader',
            name='payment_started',
            field=models.DateTimeField(null=True, verbose_name='결제시작일', blank=True),
        ),
        migrations.AlterField(
            model_name='trader',
            name='report_salary',
            field=models.BooleanField(verbose_name='인건비 신고 필요', default=False),
        ),
        migrations.AlterField(
            model_name='trader',
            name='taxation',
            field=models.CharField(max_length=100, choices=[('normal', '일반과세자'), ('simplified', '간이과세자'), ('tax-free', '면세사업자')], verbose_name='과세종류', default='normal'),
        ),
    ]
