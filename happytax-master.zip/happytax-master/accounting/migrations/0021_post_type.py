# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0020_auto_20150401_1819'),
    ]

    operations = [
        migrations.AddField(
            model_name='post',
            name='type',
            field=models.CharField(max_length=100, default='post', choices=[('post', '게시물'), ('notice', '공지사항')]),
            preserve_default=False,
        ),
    ]
