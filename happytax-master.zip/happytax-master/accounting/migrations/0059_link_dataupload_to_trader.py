# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


def link_dataupload_to_trader(apps, schema_editor):
    DataUpload = apps.get_model('accounting', 'DataUpload')

    for upload in DataUpload.objects.filter(invoice__trader__isnull=False).distinct():
        upload.trader = upload.invoice_set.first().trader
        upload.type = 'invoice'
        upload.save()


    for upload in DataUpload.objects.filter(journalentry__trader__isnull=False).distinct():
        upload.trader = upload.journalentry_set.first().trader
        upload.type = 'journalentry'
        upload.save()


def rollback(apps, schema_editor):
    pass


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0058_auto_20160203_1727'),
    ]

    operations = [
        migrations.RunPython(link_dataupload_to_trader, rollback)
    ]
