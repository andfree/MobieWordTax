# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import datetime
import django_extensions.db.fields.json
from django.utils.timezone import utc


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0017_auto_20150319_0927'),
    ]

    operations = [
        migrations.AddField(
            model_name='voucher',
            name='info',
            field=django_extensions.db.fields.json.JSONField(),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='voucher',
            name='mimetype',
            field=models.CharField(max_length=100, blank=True, null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='voucher',
            name='preprocessed',
            field=models.DateTimeField(blank=True, null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='voucher',
            name='updated',
            field=models.DateTimeField(default=datetime.datetime(2015, 3, 23, 10, 45, 53, 743477, tzinfo=utc), auto_now=True),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name='document',
            name='state',
            field=models.CharField(choices=[('approved', '승인'), ('rejected', '문서오류'), ('uploaded', '전송완료')], max_length=100),
            preserve_default=True,
        ),
    ]
