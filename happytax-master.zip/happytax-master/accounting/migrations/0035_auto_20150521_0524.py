# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0034_auto_20150519_0810'),
    ]

    operations = [
        migrations.AlterField(
            model_name='document',
            name='trader',
            field=models.ForeignKey(null=True, to='accounting.Trader', on_delete=models.CASCADE),
            preserve_default=True,
        ),
    ]
