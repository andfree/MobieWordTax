# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0011_trader_activation'),
    ]

    operations = [
        migrations.CreateModel(
            name='Tax',
            fields=[
                ('id', models.AutoField(primary_key=True, verbose_name='ID', serialize=False, auto_created=True)),
                ('type', models.CharField(choices=[('income-tax', '소득세'), ('vat-normal', '부가가치세 일반과세자'), ('vat-simplified', '부가가치세 간이과세자')], max_length=100)),
                ('period', models.CharField(max_length=100)),
                ('amount', models.IntegerField(default=0)),
                ('paid', models.DateTimeField(blank=True, null=True)),
                ('trader', models.ForeignKey(to='accounting.Trader', on_delete=models.CASCADE)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
    ]
