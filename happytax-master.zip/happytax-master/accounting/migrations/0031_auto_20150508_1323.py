# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0030_auto_20150505_1851'),
    ]

    operations = [
        migrations.AlterField(
            model_name='voucher',
            name='type',
            field=models.CharField(max_length=100, choices=[('unknown', '미확인'), ('receipt', '영수증'), ('simple-receipt', '간이 영수증'), ('purchase-tax-invoice', '종이세금계산서 매출'), ('sales-tax-invoice', '종이세금계산서 매입'), ('purchase-invoice', '종이계산서 매출'), ('sales-invoice', '종이계산서 매입'), ('salary', '인건비'), ('cash-sales', '현금매출'), ('others', '기타')]),
            preserve_default=True,
        ),
    ]
