# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import django_extensions.db.fields.json


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0027_auto_20150416_1033'),
    ]

    operations = [
        migrations.AddField(
            model_name='message',
            name='info',
            field=django_extensions.db.fields.json.JSONField(),
            preserve_default=True,
        ),
    ]
