# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from decimal import Decimal
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0044_auto_20150709_1715'),
    ]

    operations = [
        migrations.AddField(
            model_name='trader',
            name='accounting_manager',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL, related_name='accounting_client_set', blank=True, null=True, on_delete=models.SET_NULL),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='trader',
            name='cms_activated',
            field=models.DateTimeField(null=True, blank=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='trader',
            name='monthly_price',
            field=models.DecimalField(verbose_name='월 이용료', max_digits=20, default=Decimal('0'), decimal_places=0, blank=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='trader',
            name='payment_started',
            field=models.DateTimeField(null=True, blank=True),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='trader',
            name='taxation',
            field=models.CharField(max_length=100, choices=[('normal', '일반과세자'), ('simplified', '간이과세자'), ('tax-free', '면세사업자')], default='normal'),
            preserve_default=True,
        ),
    ]
