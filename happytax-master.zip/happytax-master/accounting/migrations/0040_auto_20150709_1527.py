# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from decimal import Decimal


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0039_auto_20150706_0453'),
    ]

    operations = [
        migrations.CreateModel(
            name='JournalEntry',
            fields=[
                ('id', models.AutoField(auto_created=True, verbose_name='ID', primary_key=True, serialize=False)),
                ('type', models.CharField(max_length=10)),
                ('tid', models.CharField(max_length=100, blank=True, null=True)),
                ('uid', models.CharField(max_length=100, blank=True, null=True)),
                ('journalized', models.DateField()),
                ('account_title', models.CharField(max_length=200, blank=True, null=True)),
                ('account_title_key', models.CharField(max_length=200, blank=True, null=True)),
                ('counterpart', models.CharField(max_length=200, blank=True, null=True)),
                ('counterpart_key', models.CharField(max_length=200, blank=True, null=True)),
                ('description', models.CharField(max_length=200, blank=True, null=True)),
                ('description_key', models.CharField(max_length=200, blank=True, null=True)),
                ('amount', models.DecimalField(max_digits=20, verbose_name='금액', blank=True, default=Decimal('0'), decimal_places=0)),
                ('created', models.DateTimeField(auto_now_add=True)),
                ('updated', models.DateTimeField(auto_now=True)),
                ('trader', models.ForeignKey(to='accounting.Trader', on_delete=models.CASCADE)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='invoice',
            name='journal',
            field=models.CharField(max_length=100, blank=True, null=True),
            preserve_default=True,
        ),
    ]
