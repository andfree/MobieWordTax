# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0003_auto_20150211_0939'),
    ]

    operations = [
        migrations.AddField(
            model_name='user',
            name='client_set',
            field=models.ManyToManyField(to='accounting.Trader', related_name='manager_set'),
            preserve_default=True,
        ),
    ]
