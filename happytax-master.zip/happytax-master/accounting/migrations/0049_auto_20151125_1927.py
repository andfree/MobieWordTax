# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


def apply_choices_change(apps, schema_editor):
    Document = apps.get_model('accounting', 'Document')
    Document.objects.filter(type='입대차계약서').update(type='임대차계약서')


def apply_choices_change_reverse(apps, schema_editor):
    Document = apps.get_model('accounting', 'Document')
    Document.objects.filter(type='임대차계약서').update(type='입대차계약서')


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0048_memo'),
    ]

    operations = [
        migrations.AlterField(
            model_name='document',
            name='type',
            field=models.CharField(choices=[('사업자등록증', '사업자등록증'), ('임대차계약서', '임대차계약서'), ('통장사본', '통장사본')], max_length=100),
        ),
        migrations.AlterField(
            model_name='trader',
            name='activation',
            field=models.CharField(choices=[('require_information', '추가정보 필요'), ('require_payment', '결제 안됨'), ('trying', '활성화 시도중'), ('in_review', '매니저 검토중'), ('activated', '활성화됨'), ('requested_to_delete', '삭제요청됨')], default='require_information', max_length=100, verbose_name='활성화'),
        ),
        migrations.RunPython(apply_choices_change, apply_choices_change_reverse)
    ]
