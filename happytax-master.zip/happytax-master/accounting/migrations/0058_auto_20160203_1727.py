# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('accounting', '0057_link_attachment'),
    ]

    operations = [
        migrations.AddField(
            model_name='dataupload',
            name='trader',
            field=models.ForeignKey(to='accounting.Trader', null=True, blank=True, on_delete=models.CASCADE),
        ),
        migrations.AddField(
            model_name='dataupload',
            name='type',
            field=models.CharField(max_length=100, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='message',
            name='type',
            field=models.CharField(max_length=100, choices=[('income-tax-statement', '종합소득세 납부서'), ('vat-statement', '부가가치세 납부서'), ('withholding-tax-statement', '원천세 납부서'), ('information-request', '자료요청'), ('notice', '공지사항'), ('text', '텍스트'), ('voucher', '증빙자료'), ('attachment', '첨부파일')], verbose_name='메세지 종류'),
        ),
    ]
