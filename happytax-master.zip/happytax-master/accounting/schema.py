from time import sleep

import channels_graphql_ws
import graphene
from django.contrib.auth import get_user_model
from graphene import Field, ObjectType, relay, Schema, List, ConnectionField
from graphene_django import DjangoObjectType
from graphql_relay import from_global_id
from rest_framework_simplejwt.exceptions import TokenBackendError
from rest_framework_simplejwt.state import token_backend

from accounting import models


class User(DjangoObjectType):
    class Meta:
        model = get_user_model()


class Trader(DjangoObjectType):
    class Meta:
        model = models.Trader
        interfaces = (relay.Node,)

    unread_count = graphene.Int(required=True)

    @staticmethod
    def resolve_unread_count(parent, info):
        user = info.context.user
        if not user.is_authenticated:
            return 0

        read = parent.read_set.filter(user=user).first()
        if not read:
            return 0

        return models.Message.objects.filter(trader=parent, id__gt=read.read_id).count()


class MessageNode(DjangoObjectType):
    class Meta:
        model = models.Message
        interfaces = (relay.Node,)


class MessageConnection(relay.Connection):
    class Meta:
        node = MessageNode


class Query(ObjectType):
    user = Field(User)
    traders = List(Trader)
    messages = ConnectionField(MessageConnection, trader=graphene.ID(required=True))

    @staticmethod
    def resolve_user(root, info):
        if not info.context.user.is_authenticated:
            return None

        return info.context.user

    @staticmethod
    def resolve_traders(root, info):
        if not info.context.user.is_authenticated:
            return []

        return info.context.user.client_set.all()

    @staticmethod
    def resolve_messages(root, info, trader, **kwargs):
        user = info.context.user
        if not user.is_authenticated:
            return []

        _, trader = from_global_id(trader)
        qs = models.Message.objects.select_related('sender').order_by('-id')

        if not user.is_staff:
            qs = qs.filter(trader__user=user)

        return qs.filter(trader=trader)


class Login(graphene.Mutation):
    class Arguments:
        token = graphene.String(required=True)

    ok = graphene.Boolean(required=True)

    @staticmethod
    def mutate(root, info, token):
        try:
            token = token_backend.decode(token, verify=True)
            info.context.user = models.User.objects.get(id=token['user_id'])
            return Login(ok=True)
        except (TokenBackendError, models.User.DoesNotExist):
            return Login(ok=False)


class SendMessage(graphene.Mutation):
    class Arguments:
        trader = graphene.ID(required=True)
        content = graphene.String(required=True)

    ok = graphene.Boolean(required=True)

    @staticmethod
    def mutate(root, info, trader, content):
        user = info.context.user
        if not user.is_authenticated:
            return SendMessage(ok=False)

        _, trader = from_global_id(trader)
        if not user.is_staff:
            trader = models.Trader.objects.filter(id=trader, user=user).first()
            if not trader:
                return SendMessage(ok=False)

        models.Message.objects.create(trader_id=trader, sender=user, type='text', title=content, content=content)
        return SendMessage(ok=True)


class Mutation(graphene.ObjectType):
    login = Login.Field()
    send_message = SendMessage.Field()


class OnMessageAdded(channels_graphql_ws.Subscription):
    message = Field(MessageNode)

    class Arguments:
        trader = graphene.ID(required=True)

    @staticmethod
    def subscribe(root, info, trader):
        _, trader = from_global_id(trader)
        return [f'trader:{trader}:message']

    @staticmethod
    def publish(payload, info, trader):
        return OnMessageAdded(message=payload['message'])


class Subscription(graphene.ObjectType):
    on_message_added = OnMessageAdded.Field()


graphql_schema = Schema(
    query=Query,
    mutation=Mutation,
    subscription=Subscription,
)
