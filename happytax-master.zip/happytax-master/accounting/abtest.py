import logging

from accounting.util import get_client_ip


def client_hash(request):
    s = 0
    for c in get_client_ip(request):
        if c.isnumeric():
            s += int(c)

    return s % 10
