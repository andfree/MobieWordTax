from hashlib import md5, sha1
import base64
import hmac

from decimal import Decimal
from django.utils import timezone


class FormatException(Exception):
    pass


def email_to_username(email):
    return email.replace('@', '_').replace('.', '_')


def format_to_minutes(datetime_obj):
    return timezone.localtime(datetime_obj).strftime('%Y-%m-%d %H:%M')


def month_to_minutes(datetime_obj):
    return timezone.localtime(datetime_obj).strftime('%m-%d %H:%M')


def date_to_month(datetime_obj):
    if not datetime_obj:
        return ''

    return timezone.localtime(datetime_obj).strftime('%Y-%m')


def date(date_or_datetime):
    if not date_or_datetime:
        return ''

    return timezone.localtime(date_or_datetime).strftime('%Y년 %m월 %d일')


def simple_date(date_or_datetime):
    if not date_or_datetime:
        return ''

    return timezone.localtime(date_or_datetime).strftime('%Y-%m-%d')


def won(number, unit=0, display_unit=True):
    try:
        number = int(number)
    except:
        number = 0

    unit_value = pow(10, unit)

    result = '{:,d}'.format(int(number / unit_value))

    if unit == 0:
        number_word = ''
    elif unit == 4:
        number_word = '만'
    elif unit == 8:
        number_word = '억'
    else:
        number_word = unit_value

    if number == 0:
        result = '- '
    elif result == '0':
        result = '< 1'

    if display_unit:
        result += number_word + '원'

    return result


def percent(number):
    return '{:2%}'.format(number)

def base64_md5(_input):
    _input = _input.encode('utf-8')
    return base64.b64encode(md5(_input).digest()).decode()


def base64_hmac_sha1(key, target):
    key = key.encode('utf-8')
    target = target.encode('utf-8')
    return base64.b64encode(hmac.new(base64.b64decode(key), target, sha1).digest()).decode().rstrip('\n')


def business_registration_no(number):
    number = str(number).replace('-', '')
    return '%s-%s-%s' % (number[:3], number[3:5], number[5:])

def phone_no(number):
    number = str(number).replace('-', '')
    return '%s-%s-%s' % (number[:3], number[3:7], number[7:])

def resident_registration_number(number):
    return '%s-%s' % (number[:6], number[6:])


def truncate_chars(value, max_length):
    if len(value) > max_length:
        truncd_val = value[:max_length]
        if not len(value) == max_length + 1 and value[max_length + 1] != " ":
            truncd_val = truncd_val[:truncd_val.rfind(" ")]
        return truncd_val + "..."
    return value
