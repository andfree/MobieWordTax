import re
from io import BytesIO

from accounting.ntsreport import ntscode
from accounting.ntsreport.vat.descriptors import record_descriptors
from accounting.ntsreport.format import NTSReport
from accounting.tax import 부가가치세
from happytax import settings


def generate_nts_report(tax, **kwargs):
    report = NTSReport(record_descriptors) #.generate_nts_report(tax, **kwargs)

    trader = tax.trader
    vat = 부가가치세(tax)

    agent_number = settings.AGENT_NUMBER.split('-')
    업종코드 = int(trader.memo('업종코드'))

    report.write_record('1) 신고서 Head 레코드', [
        11,  # 부가가치세
        서식코드(trader),
        trader.registration_no,
        41,  # 부가가치세
        '01',  # TODO 예정신고/확정신고 구분 필요
        kwargs.get('correction', '01'),  # 정기신고
        tax.period.replace('-', '0').replace('H', ''),
        신고서종류코드(tax.period),  # 부가가치세 확정일반 신고서
        settings.AGENT_ID,  # 홈택스 시스템에 등록된 세무대리인의 ID
        trader.memo('주민(법인등록번호)').replace('-', ''),
        settings.AGENT_NAME,
        agent_number[0],
        agent_number[1],
        agent_number[2],
        trader.business_name,
        trader.memo('대표자명'),
        re.sub(' +', ' ', trader.memo('사업장소재지')),
        trader.memo('사업장전화번호'),
        re.sub(' +', ' ', trader.memo('본점(자택)주소')),
        trader.memo('사업자전화번호'),
        trader.memo('업태'),
        trader.memo('종목'),
        업종코드,
        vat.과세기간시작일자,
        vat.과세기간종료일자,
        vat.작성일자,
        kwargs.get('revision'),
        trader.memo('사업자휴대전화'),
        '9000',
        settings.AGENT_BUSINESS_NUMBER.replace('-', ''),
        trader.user.email,
    ])
    if trader.taxation == 'normal':
        report.write_record('2) 일반과세자 신고서 레코드', [
            17,
            서식코드(trader),
            vat.매출과세세금계산서발급금액,
            vat.매출과세세금계산서발급세액,
            vat.매출과세매입자발행세금계산서금액,
            vat.매출과세매입자발행세금계산서세액,
            vat.매출과세카드현금발행금액,
            vat.매출과세카드현금발행세액,
            vat.매출과세기타금액,
            vat.매출과세기타세액,
            vat.매출영세율세금계산서발급금액,
            vat.매출영세율기타금액,
            vat.매출예정누락합계금액,
            vat.매출예정누락합계세액,
            vat.예정누락매출세금계산서금액,
            vat.예정누락매출세금계산서세액,
            vat.예정누락매출과세기타금액,
            vat.예정누락매출과세기타세액,
            vat.예정누락매출영세율세금계산서금액,
            vat.예정누락매출영세율기타금액,
            vat.예정누락매출명세합계금액,
            vat.예정누락매출명세합계세액,
            vat.매출대손세액가감세액,
            vat.과세표준금액,
            vat.산출세액,
            vat.매입세금계산서수취일반금액,
            vat.매입세금계산서수취일반세액,
            vat.매입세금계산서수취고정자산금액,
            vat.매입세금계산서수취고정자산세액,
            vat.매입예정누락합계금액,
            vat.매입예정누락합계세액,
            vat.예정누락매입신고세금계산서금액,
            vat.예정누락매입신고세금계산서세액,
            vat.예정누락매입기타공제금액,
            vat.예정누락매입기타공제세액,
            vat.예정누락매입명세합계금액,
            vat.예정누락매입명세합계세액,
            vat.매입자발행세금계산서매입금액,
            vat.매입자발행세금계산서매입세액,
            vat.매입기타공제매입금액,
            vat.매입기타공제매입세액,
            vat.그밖의공제매입명세합계금액,
            vat.그밖의공제매입명세합계세액,
            vat.매입세액합계금액,
            vat.매입세액합계세액,
            vat.공제받지못할매입합계금액,
            vat.공제받지못할매입합계세액,
            vat.공제받지못할매입금액,
            vat.공제받지못할매입세액,
            vat.공제받지못할공통매입면세사업금액,
            vat.공제받지못할공통매입면세사업세액,
            vat.공제받지못할대손처분금액,
            vat.공제받지못할대손처분세액,
            vat.공제받지못할매입명세합계금액,
            vat.공제받지못할매입명세합계세액,
            vat.차감합계금액,
            vat.차감합계세액,
            getattr(vat, '납부(환급)세액'),
            vat.그밖의경감공제세액,
            vat.그밖의경감공제명세합계세액,
            vat.경감공제합계세액,
            vat.예정신고미환급세액,
            vat.예정고지세액,
            vat.사업양수자의대리납부기납부세액,
            vat.매입자납부특례기납부세액,
            vat.가산세액계,
            vat.차감납부할세액,
            0,  # vat.과세표준명세수입금액제외금액,
            vat.과세표준금액,  # vat.과세표준명세합계수입금액,
            0,  # vat.면세사업수입금액제외금액,
            0,  # vat.면세사업합계수입금액,
            0,  # vat.계산서교부금액,
            vat.계산서수취금액,
            '10',
            trader.memo('은행코드'),
            trader.memo('계좌번호'),
            0,  # vat.총괄납부승인번호,
            trader.memo('은행지점명'),
            trader.memo('폐업일자'),
            trader.memo('폐업사유'),
            'N',
            vat.차감납부할세액,
            None,  # 일반과세자 구분
            None,  # 조기환급취소구분,
            None,  # 수출기업 수입 납부유예,
        ])
        # TODO: 개발업체는 입력 사용자가 환급구분을 선택할 수 있거나 자동 계산해야 합니다. 현재는 조기환급(영세율및시설투자환급)에 해당되지 않는 경우인 환급구분 10만 지원합니다
    else:
        raise NotImplementedError('간이과세자는 아직 구현 안했음')

    # 업종이 여러 개일 때 고려 안되어 있음
    # 수입금액종류구분코드 01 업종별수입금액
    report.write_record('4) 부가가치세수입금액(과세표준명세, 면세수입금액)', [
        '15',
        서식코드(trader),
        '01',
        trader.memo('업태'),
        trader.memo('종목'),
        업종코드,
        vat.과세표준금액,
    ])
    if vat.신용카드매출전표등발행공제등세액:
        report.write_record('4) 부가가치세수입금액(과세표준명세, 면세수입금액)', [
            '15',
            서식코드(trader),
            '04',
            trader.memo('업태'),
            trader.memo('종목'),
            업종코드,
            vat.신용카드매출전표등발행공제등세액,
        ])

    # 수입금액종류코드 02, 07, 08, 14 미구현
    if vat.매입기타공제매입세액:
        report.write_record('5) 부가가치세 공제감면 신고서 레코드', [
            '14',
            서식코드(trader),
            '211',
            '1',
            vat.매입기타공제일반매입금액,
            vat.매입기타공제일반매입세액,
        ])
    if vat.의제매입세액:
        report.write_record('5) 부가가치세 공제감면 신고서 레코드', [
            '14',
            서식코드(trader),
            '230',
            '1',
            vat.의제매입금액,
            vat.의제매입세액
        ])
    if vat.신용카드매출전표등발행공제등세액:
        report.write_record('5) 부가가치세 공제감면 신고서 레코드', [
            '14',
            서식코드(trader),
            '410',
            '1',
            vat.신용카드매출전표등발행공제등금액,
            vat.신용카드매출전표등발행공제등세액,
        ])
    if vat.과세표준금액 and \
            (552100 <= 업종코드 <= 553999 or 551000 <= 업종코드 <= 551999 or 930100 <= 업종코드 <= 930902 or 930908 <= 업종코드 <= 930912 or 업종코드 in (930917, 930919)):
        # TODO: 사업장정보 가져오기
        report.write_record('1) 사업장현황명세서', [
            '14',
            'I104400',
            '02',
            vat.tax.range()[1].month
        ])
    # 과세 금액만 구현
    if vat.신용카드매출전표등발행공제등금액:
        report.write_record('2) 신용카드매출전표 등 발행금액 집계표', [
            '17',
            'I103400',
            vat.신용카드매출전표등발행공제등금액,  # 전체발행금액_합계
            vat.신용카드등발행공제금액,  # 신용카드등발행금액_합계
            vat.현금영수증발행공제금액,  # 현금영수증발행금액_합계
            vat.신용카드매출전표등발행공제등금액,  # 발행금액합계_과세매출분
            vat.신용카드등발행공제금액,  # 신용카드등발행금액_과세매출분
            vat.현금영수증발행공제금액,  # 현금영수증발행금액_과세매출분
        ])

    # TODO: 가산세 구현 필요
    # 부동산임대업종
    if 701101 <= 업종코드 <= 701700 or 업종코드 == 921404:
        # TODO: 부동산임대업종 지원
        # 업종이 여러 개 있을 경우에는 과세표준금액 전체가 부동산임대업을 통한 금액이 아닐 수 있다.
        # 사업자단위과세적용사업장이 아닌 경우에는 명세서가 1개이다.
        if vat.과세표준금액:
            report.write_record('부동산임대공급가액명세서', [
                '17',
                'I103600',
                1,
                re.sub(' +', ' ', trader.memo('사업장소재지')),
                trader.registration_no,
                '0000'
            ])
            report.write_record('부동산임대공급가액명세서 세부내용', [
                18,
                'I103600',
                1,
                1,
                'B1,1-3',
                '0000085.50',
                trader.business_name,
                '0000000000',
                '0000'
            ])
    dl_records = []
    data_count = 0
    if vat.매입기타공제현금거래건수:
        data_count += 1

        # 카드 번호 알 수 없음
        dl_records.append(report.format_record('기타신용·직불카드 및 기명식선불카드 매출전표 수령금액 명세(Data Record)', [
            'DL',
            tax.year,
            vat.반기구분,
            vat.반기내월순번,
            trader.registration_no,
            2,  # 카드구분
            None,  # 카드회원번호
            None,  # 공급자(가맹점)사업자등록번호
            vat.매입기타공제현금거래건수,
            ' ' if vat.매입기타공제현금매입금액 >= 0 else '-',
            vat.매입기타공제현금매입금액 if vat.매입기타공제현금매입금액 >= 0 else -vat.매입기타공제현금매입금액,
            ' ' if vat.매입기타공제현금매입세액 >= 0 else '-',
            vat.매입기타공제현금매입세액 if vat.매입기타공제현금매입세액 >= 0 else -vat.매입기타공제현금매입세액
        ]))
    if vat.매입기타공제카드거래건수:
        data_count += 1

        # 카드 번호 알 수 없음
        dl_records.append(report.format_record('기타신용·직불카드 및 기명식선불카드 매출전표 수령금액 명세(Data Record)', [
            'DL',
            tax.year,
            vat.반기구분,
            vat.반기내월순번,
            trader.registration_no,
            4,  # 카드구분
            None,  # 카드회원번호
            None,  # 공급자(가맹점)사업자등록번호
            vat.매입기타공제카드거래건수,
            ' ' if vat.매입기타공제카드매입금액 >= 0 else '-',
            vat.매입기타공제카드매입금액 if vat.매입기타공제카드매입금액 >= 0 else -vat.매입기타공제카드매입금액,
            ' ' if vat.매입기타공제카드매입세액 >= 0 else '-',
            vat.매입기타공제카드매입세액 if vat.매입기타공제카드매입세액 >= 0 else -vat.매입기타공제카드매입세액
        ]))
    if len(dl_records):
        report.write_record('제출자 인적사항(Header Record)', [
            'HL',
            tax.year,
            vat.반기구분,
            vat.반기내월순번,
            trader.registration_no,
            trader.business_name,
            trader.memo('대표자명'),
            trader.memo('주민(법인등록번호)').replace('-', ''),
            vat.작성일자
        ])

        for dl_record in dl_records:
            report.buffer.write(dl_record)

        report.write_record('신용카드등 매입내용 합계(Tail Record)', [
            'TL',
            tax.year,
            vat.반기구분,
            vat.반기내월순번,
            trader.registration_no,
            data_count,
            vat.매입기타공제거래건수,
            ' ' if vat.매입기타공제매입금액 >= 0 else '-',
            vat.매입기타공제매입금액 if vat.매입기타공제매입금액 >= 0 else -vat.매입기타공제매입금액,
            ' ' if vat.매입기타공제매입세액 >= 0 else '-',
            vat.매입기타공제매입세액 if vat.매입기타공제매입세액 >= 0 else -vat.매입기타공제매입세액
        ])
    report.write_record('표지(Head Record)', [
        '7',
        trader.registration_no,
        trader.business_name,
        trader.memo('대표자명'),
        re.sub(' +', ' ', trader.memo('사업장소재지')),
        trader.memo('업태'),
        trader.memo('종목'),
        vat.과세기간시작일자[2:] + vat.과세기간종료일자[2:],
        vat.과세기간종료일자[2:]
    ])
    consumer_count = 0
    for consumer_info in vat.매출전자세금계산서이외발급거래자정보:
        consumer_count += 1
        report.write_record('(전자세금계산서 이외분)매출자료(Data Record)', [
            1,
            trader.registration_no,
            consumer_count,
            consumer_info['consumer_no'].replace('-', ''),
            consumer_info['consumer_name'],
            consumer_info['count'],
            consumer_info['value_of_supply'],
            consumer_info['vat'],
            0,
            7501,
            ntscode.tax_offices[trader.memo('사업장관할서')]
        ])
    if vat.매출전자세금계산서이외발급거래처수:
        report.write_record('(전자세금계산서 이외분)매출합계(Total Record)', [
            3,
            trader.registration_no,
            vat.매출전자세금계산서이외발급거래처수,
            vat.매출전자세금계산서이외발급거래건수,
            vat.매출전자세금계산서이외발급금액,
            vat.매출전자세금계산서이외발급세액,
            vat.매출전자세금계산서이외발급거래처수,
            vat.매출전자세금계산서이외발급거래건수,
            vat.매출전자세금계산서이외발급금액,
            vat.매출전자세금계산서이외발급세액,
            0,
            0,
            0,
            0
        ])
    if vat.매출전자세금계산서발급거래처수:
        report.write_record('전자세금계산서분 매출합계(Total Record)', [
            5,
            trader.registration_no,
            vat.매출전자세금계산서발급거래처수,
            vat.매출전자세금계산서발급거래건수,
            vat.매출전자세금계산서발급금액,
            vat.매출전자세금계산서발급세액,
            vat.매출전자세금계산서발급거래처수,
            vat.매출전자세금계산서발급거래건수,
            vat.매출전자세금계산서발급금액,
            vat.매출전자세금계산서발급세액,
            0,
            0,
            0,
            0
        ])
    supplier_count = 0
    for supplier_info in vat.매입전자세금계산서이외수취거래자정보:
        supplier_count += 1
        report.write_record('(전자세금계산서 이외분)매입자료(Data Record)', [
            2,
            trader.registration_no,
            supplier_count,
            supplier_info['supplier_no'].replace('-', ''),
            supplier_info['supplier_name'],
            supplier_info['count'],
            supplier_info['value_of_supply'],
            supplier_info['vat'],
            '0',  # TODO: 보고자가 주류제조업자 또는 주류도매업자인 경우에만 수록하고 기타 업종인 경우에는 "0"을 수록함
            '0',
            8501,
            ntscode.tax_offices[trader.memo('사업장관할서')]
        ])
    if vat.매입전자세금계산서이외수취거래처수:
        report.write_record('(전자세금계산서 이외분)매입합계(Total Record)', [
            4,
            trader.registration_no,
            vat.매입전자세금계산서이외수취거래처수,
            vat.매입전자세금계산서이외수취거래건수,
            vat.매입전자세금계산서이외수취일반금액,
            vat.매입전자세금계산서이외수취일반세액,
            vat.매입전자세금계산서이외수취거래처수,
            vat.매입전자세금계산서이외수취거래건수,
            vat.매입전자세금계산서이외수취일반금액,
            vat.매입전자세금계산서이외수취일반세액,
            0,
            0,
            0,
            0
        ])
    if vat.매입전자세금계산서수취거래처수:
        report.write_record('전자세금계산서분 매입합계(Total Record)', [
            6,
            trader.registration_no,
            vat.매입전자세금계산서수취거래처수,
            vat.매입전자세금계산서수취거래건수,
            vat.매입전자세금계산서수취일반금액,
            vat.매입전자세금계산서수취일반세액,
            vat.매입전자세금계산서수취거래처수,
            vat.매입전자세금계산서수취거래건수,
            vat.매입전자세금계산서수취일반금액,
            vat.매입전자세금계산서수취일반세액,
            0,
            0,
            0,
            0
        ])
    e_records = []
    if vat.계산서수취거래처수:
        e_records.append(
            report.format_record('전자계산서 매출집계레코드(매출)', [
                'E',
                17,
                vat.반기구분,
                '2',  # TODO: 예정이면 1, 확정이면 2
                ntscode.tax_offices[trader.memo('사업장관할서')],
                1,
                trader.registration_no,
                tax.year,
                vat.과세기간시작일자,
                vat.과세기간종료일자,
                vat.과세기간종료일자,
                vat.계산서수취거래처수,
                vat.계산서수취거래건수,
                '0' if vat.계산서수취금액 >= 0 else '1',
                vat.계산서수취금액 if vat.계산서수취금액 >= 0 else -vat.계산서수취금액
            ])
        )
    if e_records:
        b_records = [
            report.format_record('제출의무자인적사항레코드', [
                'B',
                ntscode.tax_offices[trader.memo('사업장관할서')],
                1,
                trader.registration_no,
                trader.business_name,
                trader.memo('대표자명'),
                trader.memo('법정동코드'),
                re.sub(' +', ' ', trader.memo('사업장소재지'))
            ])
        ]
        report.write_record('제출자(대리인)레코드', [
            'A',
            settings.TAX_OFFICE_CODE,
            vat.작성일자,
            1,
            settings.AGENT_MANAGEMENT_NUMBER,
            settings.AGENT_BUSINESS_NUMBER.replace('-', ''),
            settings.AGENT_NAME,
            settings.AGENT_CORPORATE_NUMBER.replace('-', ''),
            settings.AGENT_PRESIDENT_NAME,
            settings.AGENT_DONG_CODE,
            settings.AGENT_ADDRESS,
            settings.AGENT_NUMBER,
            len(b_records),
            101
        ])
        for b_record in b_records:
            report.buffer.write(b_record)

        for e_record in e_records:
            report.buffer.write(e_record)

    return report.buffer.getvalue()


def 서식코드(trader):
    # TODO 간이과세자도 할 것
    return 'I103200'


def 신고서종류코드(period):
    # TODO
    return 'C07'