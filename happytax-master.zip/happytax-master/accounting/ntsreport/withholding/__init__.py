import json
import os
import django

from os.path import dirname
from happytax import settings

from accounting.ntsreport.format import NTSReport
from accounting.ntsreport.ntscode import 원천징수이행상황신고서코드
from accounting.tax import 원천세

os.environ['DJANGO_SETTINGS_MODULE'] = 'happytax.settings'
django.setup()


def get_descriptor():
    with open(dirname(__file__) + '/descriptors.json', encoding='utf-8') as f:
        return json.load(f)


def generate_nts_report(tax, **kwargs):
    report = NTSReport(get_descriptor())

    class DictToObject:
        def __init__(self, **entries):
            self.__dict__.update(entries)

    # 마감 시에는 info['reported']에 있는 마감된 데이터로 만든다
    if tax.ready_to_report and tax.info.get('reported'):
        withholding = DictToObject(**json.loads(tax.info['reported']))
    else:
        withholding = 원천세(tax)

    agent_business_number = settings.AGENT_BUSINESS_NUMBER.replace('-', '')
    agent_number = settings.AGENT_NUMBER.replace('-', '')
    trader = tax.trader
    business_address = trader.memo('사업장소재지')
    귀속연월 = kwargs.get('귀속연월').replace('-', '')
    지급연월 = kwargs.get('지급연월').replace('-', '')
    제출연월 = kwargs.get('제출연월').replace('-', '')
    민원종류코드 = getattr(withholding, '민원종류코드', None)
    if 민원종류코드 is None:
        민원종류코드 = 'FF101' if withholding.신고구분상세코드 == '수정신고' else 'FF001'

    report.write_record('원천징수이행상황신고서-Header', [
        21,                                             # 원천징수이행상황신고서_Header
        'C103900',                                      # 서식코드
        trader.registration_no,                         # 납세자ID - 주민번호/사업자번호
        14,                                             # 세목코드
        '01',                                           # 신고구분코드
        원천세.CODES['신고구분상세코드'][withholding.신고구분상세코드],    # 신고구분상세코드‘01’정기신고,’02’수정신고,‘03’기한후신고
        'F01',                                          # 신고서종류코드
        귀속연월,                                         # 귀속연월YYYYMM
        지급연월,                                         # 지급연월YYYYMM
        제출연월,                                         # 제출연월YYYYMM
        kwargs.get('hometaxID', 'mobiletax'),           # TODO 홈택스에 등록된 사용자(개인 또는 세무대리인)의 ID
        민원종류코드,                                       # 민원종류코드‘FF001’원천징수이행상황신고서(원천징수세액환급신청서),기한 후신고,‘FF101’수정
        agent_business_number,                          # 세무대리인사업자번호
        settings.AGENT_NAME,                            # 세무대리인성명
        settings.AGENT_MANAGEMENT_NUMBER,               # 세무대리인관리번호
        agent_number,                                   # 세무대리인전화번호
        trader.business_name,                           # TODO 법인명(상호) 모바일택스에 등록한 경우와, 실제 상호명이 다른 경우 처리 고려
        business_address,                               # 사업장소재지
        trader.memo('사업장전화번호'),                      # 사업장전화번호
        kwargs.get('전자메일주소', 'whmacpa@gmail.com'),   # TODO 전자메일주소 - 세무대리인의 전자메일인지, 의무자의 전자메일인지 확인
        trader.memo('대표자명'),                          # 성명(대표자명)
        kwargs.get('원천신고구분', '01'),                  # 원천신고구분‘01’매월,‘02’반기
        withholding.연말정산여부,
        kwargs.get('소득처분여부', 'N'),                   # 소득처분여부Y/N
        withholding.환급신청여부,
        kwargs.get('일괄납부여부', 'N'),                   # 일괄납부여부Y/N
        kwargs.get('사업자단위과세여부', 'N'),               # 사업자단위과세여부Y/N
        kwargs.get('신고서부표여부', 'N'),                  # 신고서부표여부Y/N
        kwargs.get('차월이월환급세액승계명세여부', 'N'),        # 차월이월환급세액승계명세여부Y/N
        withholding.환급신청여부,                          # 기납부세액명세서제출여부Y/N
        trader.memo('은행코드', '') if withholding.환급신청여부 == 'Y' else '',                      # 예입처(은행코드)
        trader.memo('계좌번호', '') if withholding.환급신청여부 == 'Y' else '',                      # 계좌번호
        kwargs.get('작성일자'),                           # 작성일자YYYYMMDD
        '9000',                                         # 세무프로그램코드 없는 경우 9000
    ], b'\r\n')

    report.write_record('원천징수이행상황신고서_환급세액 조정', [
        22,                         # 원천징수이행상황신고서_환급세액 조정
        'C103900',                  # 서식코드
        withholding.전월미환급세액,
        withholding.기환급신청세액,
        withholding.차감잔액,
        withholding.일반환급세액,
        withholding.신탁재산세액,
        withholding.그밖의환급세액금융회사,
        withholding.그밖의환급세액합병,
        withholding.조정대상환급세액,
        withholding.당월조정환급세액계,
        withholding.차월이월환급세액,
        withholding.환급신청액,
        withholding.승계대상합계차월이월환급세액,
    ], b'\r\n')

    for code in 원천징수이행상황신고서코드.values():
        report.write_record('원천징수이행상황신고서_원천징수 명세 및 납부세액', [
            23,  # 원천징수이행상황신고서_원천징수 명세 및 납부세액
            'C103900',  # 서식코드
            code,       # 원천징수소득코드
            withholding.records[code].get('인원', 0) if code in withholding.records else 0,
            withholding.records[code].get('총지급액', 0) if code in withholding.records else 0,
            withholding.records[code].get('징수세액소득세', 0) if code in withholding.records else 0,
            withholding.records[code].get('징수세액농특세', 0) if code in withholding.records else 0,
            withholding.records[code].get('가산세', 0) if code in withholding.records else 0,
            withholding.records[code].get('당월조정환급세액', 0) if code in withholding.records else 0,
            withholding.records[code].get('납부세액소득세', 0) if code in withholding.records else 0,
            withholding.records[code].get('납부세액농특세', 0) if code in withholding.records else 0,
        ], b'\r\n')

    if withholding.환급신청여부 == 'Y':
        for row in withholding.환급신청부표:
            report.write_record('원천징수세액환급신청서_부표', [
                27,
                'C103902',
                1,
                row['소득종류'],
                row['귀속연월'],
                row['지급연월'],
                row['코드'],
                row['인원'],
                row['소득지급액'],
                row['결정세액'],
                row['기납부계'],
                row['기납부주'],
                row['기납부종'],
                row['차감세액'],
                row['분납금액'],
                row['조정환급'],
                row['환급신청액'],
            ], b'\r\n')

        for 납부현황 in withholding.원천징수신고납부현황:
            report.write_record('기납부세액명세서_원천징수신고납부현황', [
                27,
                'C103903',
                '14',       # TODO 중도일 때는 다른 세목코드도 고려
                납부현황['귀속연월'],
                납부현황['지급연월'],
                'A01',      # TODO 연말정산이 아닌경우 다른 세목코드 고려
                납부현황['인원'],
                납부현황['총지급액'],
                납부현황['징수세액소득세'],
                납부현황['징수세액농특세'],
                납부현황['징수세액가산세'],
            ], b'\r\n')

        for 지급명세 in withholding.지급명세서:
            report.write_record('기납부세액명세서_지급명세서 기납부세액 현황', [
                28,
                'C103903',
                '14',       # TODO 중도일 때는 다른 세목코드도 고려
                지급명세['주민번호'],
                지급명세['성명'],
                지급명세['종(전)근무지'],
                지급명세['종(전)근무지_사업자등록번호'],
                지급명세['주소득세'],
                지급명세['주농특세'],
                지급명세['종소득세'],
                지급명세['종농특세'],
                지급명세['소득세계'],
                지급명세['농특세계'],
            ], b'\r\n')

        report.write_record('기납부세액명세서_기납부세액 차이조정현황', [
            29,
            'C103903',
            withholding.신고납부현황_합계_인원,
            withholding.신고납부현황_합계_총지급액,
            withholding.신고납부현황_합계_징수세액소득세,
            withholding.신고납부현황_합계_징수세액농특세,
            withholding.신고납부현황_합계_징수세액가산세,
            withholding.기납부세액현황_합계_주소득세,
            withholding.기납부세액현황_합계_주농특세,
            withholding.기납부세액현황_합계_종소득세,
            withholding.기납부세액현황_합계_종농특세,
            withholding.기납부세액현황_합계_소득세계,
            withholding.기납부세액현황_합계_농특세계,
            withholding.차이조정현황_소득세합계,
            withholding.차이조정현황_주소득세합계,
            withholding.차이조정현황_소득세차이금액,
            withholding.차이조정현황_농특세합계,
            withholding.차이조정현황_주농특세합계,
            withholding.차이조정현황_농특세차이금액,
            withholding.차이조정현황_사유코드_중도퇴사자,
            withholding.차이조정현황_사유코드_전입자,
            withholding.차이조정현황_사유코드_전출자,
            withholding.차이조정현황_사유코드_합병분할,
            withholding.차이조정현황_사유코드_기타,
            withholding.차이조정현황_사유내용,
        ], b'\r\n')

    return report.buffer.getvalue()
