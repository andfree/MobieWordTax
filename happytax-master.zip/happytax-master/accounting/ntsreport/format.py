import re
from io import BytesIO


class NTSReport:

    def __init__(self, descriptors):
        self.descriptors = descriptors
        self.buffer = BytesIO()

    def write_record(self, record_key, data, delimiter=b'\n'):
        self.buffer.write(self.format_record(record_key, data, delimiter))

    def format_record(self, record_key, data, delimiter=b'\n'):
        descriptor = self.descriptors[record_key]
        buffer = BytesIO()

        data_it = iter(data)
        for field in descriptor:
            try:
                value = next(data_it)
            except StopIteration:
                value = None

            buffer.write(self.format_field(field, value))

        buffer.write(delimiter)
        return buffer.getvalue()

    def format_field(self, field, value):
        if not value:
            note = field.get('비고', '')
            try:
                default = re.search(r'(?<=default ).*', note).group()
                default = re.sub(r'‘(.*)’', r'\1', default)
            except AttributeError:
                default = None

            value = default or ''

        if not value and 'not null' in note.lower():
            raise TypeError('{} does not allow null or empty value.'.format(field['한글명']))

        return self.cast(value, field['TYPE'], field['길이'])

    def cast(self, value, type_, length):
        if type_ == 'CHAR':
            value = str(value).encode('euc-kr')[:length]
            if len(value) == length:
                try:
                    value.decode('euc-kr')
                except UnicodeDecodeError:
                    value = value[:-1]

            return value.ljust(length)
        elif type_ == 'NUMBER':
            if value:
                value = int(value)
            else:
                value = 0

            return '{:0{length}}'.format(value, length=length).encode('euc-kr')

        raise NotImplementedError(type_)


def parse(record_descriptors, bytes_data):

    index = {}
    result = []
    for k in record_descriptors:

        record = record_descriptors[k]

        if '점검내용' not in record[0] and '점검' in record[0]:
            raise TypeError('점검 field exists instead of 점검내용 in ' + k)

        if record[0]['한글명'] == '자료구분' and record[1]['한글명'] == '서식코드':
            for g in str(record[0].get('점검내용', '')).split(','):
                for fc in record[1].get('점검내용', '').split(','):
                    index[g + fc] = k, record
        elif record[0]['한글명'] == '레코드구분':
            index[record[0].get('점검내용') or record[0].get('비고')] = k, record
        elif record[0]['한글명'] == '자료구분':
            index[record[0].get('점검내용')] = k, record

    for line in bytes_data:
        if not line:
            break

        for l in [9, 2, 1]:
            if line[:l].decode('euc-kr') in index:
                key, record = index.get(line[:l].decode('euc-kr'))
                break

        if record:
            record_data = {
                'key': key,
                'fields': []
            }

            for field in record:
                record_data['fields'].append([field['한글명'], line[field['누적'] - field['길이']:field['누적']].decode('euc-kr')])

            result.append(record_data)
        else:
            print('no record line', line)

    return result
