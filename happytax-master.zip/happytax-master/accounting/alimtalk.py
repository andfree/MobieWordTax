import requests
import logging
from accounting.alimtalk_template import AlimtalkTemplate


class Alimtalk:
    CLIENT_ID = 'mobiletax'
    API_KEY = 'OTI3NC0xNTM2MDQ2MjkzMjU4LTRjMmJjZGU3LTBjMTktNGQxMS1hYmNkLWU3MGMxOTVkMTE4YQ=='
    API_URL = 'http://api.apistore.co.kr/kko/1/msg/' + CLIENT_ID
    API_HEADERS = {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'x-waple-authorization': API_KEY,
    }


    # send alimtalk
    # ex) Alimtalk.send('18338332', '01000000000', 'APIV101', {'user_name':'이름'})
    @classmethod
    def send(cls, sender, receiver, template_code, replace_msg):
        cls.validate(sender, receiver, template_code)

        params = AlimtalkTemplate.generate_params(sender, receiver, template_code, replace_msg)
        response = requests.post(cls.API_URL, headers=cls.API_HEADERS, data=params)
        if response.status_code != 200:
            logging.warning('[error][Alimtalk.send] %s', response.text)
            raise Exception(response.text)

        return response.json()


    @classmethod
    def validate(cls, sender, receiver, template_code):
        sender = sender.replace('-', '')
        receiver = receiver.replace('-', '')

        if not sender or not sender.isnumeric():
            raise Exception('invalid sender number')
        if not receiver or not receiver.isnumeric():
            raise Exception('invalid receiver number')
        if AlimtalkTemplate.TEMPLATES.get(template_code, 'invalid') == "invalid":
            raise Exception('invalid template code')
