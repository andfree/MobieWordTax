<script type="text/x-template" id="input-in-place">
    <span class="input-group input-group-sm" :class="{'has-danger': error}" data-toggle="popover" :data-content="error" v-if="editing">
        <input class="form-control" type="text" :value="value" :placeholder="placeholder" @keydown.enter.prevent="submit" @keyup.esc="rollback" ref="input" v-model="editingValue" v-if="type === 'text'">
        <input class="form-control" type="number" :value="value" :placeholder="placeholder" @keydown.enter.prevent="submit" @keyup.esc="rollback" ref="input" v-model="editingValue" v-else-if="type === 'number'">
        <select class="form-control" v-model="editingValue" @keydown.enter.prevent="submit" @keyup.esc="rollback" ref="input" v-else-if="type === 'select'">
            <slot></slot>
        </select>
        <div class="btn btn-secondary input-group-addon text-success" @click="submit"><i class="fa fa-check"></i></div>
        <div class="btn btn-secondary input-group-addon text-danger" @click="rollback"><i class="fa fa-undo"></i></div>
    </span>
    <span style="text-decoration: underline" v-else>
        <a href @click.prevent="startEditing()" style="color: gray" v-if="!editingValue">{{ placeholder || '입력' }}</a>
        <a href @click.prevent="startEditing()" v-else-if="type === 'number'">{{ commafy(editingValue) }}</a>
        <a href @click.prevent="startEditing()" v-else>{{ editingValue }}</a>
    </span>
</script>

<script type="text/javascript">
    Vue.component('input-in-place', {
        template: '#input-in-place',
        props: ['type', 'value', 'placeholder'],
        data: function () {
            return {
                editingValue: '',
                editing: false,
                color: 'black',
                error: null
            }
        },
        mounted: function () {
            this.editingValue = this.value;
            $(this.$el).popover({
                container: 'body',
                placement: 'top',
                trigger: 'manual'
            })
        },
        watch: {
            'editing': function () {
                if (this.editing) {
                    return
                }

                $(this.$el).popover('hide')
            },
            'value': function () {
                this.editingValue = this.value;
                this.error = null;
                this.editing = false;
                $.tabNext()
            },
            'error': function () {
                this.$nextTick(function () {
                    $(this.$el).popover('show')
                })
            }
        },
        methods: {
            submit: function () {
                if (this.value === this.editingValue) {
                    this.editing = false
                    $.tabNext()
                    return
                }

                this.$emit('submit', this)
            },
            rollback: function () {
                this.editingValue = this.value
                this.error = null
                this.editing = false
            },
            startEditing: function () {
                this.editing = true
                this.$nextTick(function () {
                    this.$refs.input.focus()
                })
            },
            setError: function (error) {
                this.editing = true
                this.error = error
                this.$nextTick(function () {
                    this.$refs.input.focus()
                })
            }
        }
    });
</script>

<script type="text/x-template" id="form-control">
    <input class="form-control" :class="extraClass" v-model="object[field]" type="number" v-if="schema.type == 'decimal'">
    <input class="form-control" :class="extraClass" v-model="object[field]" type="date" v-else-if="schema.type == 'date'">
    <select class="form-control" :class="extraClass" v-model="object[field]" v-else-if="schema.type == 'choice'">
        <option :value="null" v-if="!schema.required"> -- </option>
        <option :value="choice.value" v-for="choice in schema.choices">{{ choice.display_name || choice.value }}</option>
    </select>

    <input class="form-control" :class="extraClass" v-model="object[field]" type="checkbox" v-else-if="schema.type == 'boolean'">

    <input class="form-control" :class="extraClass" v-model="object[field]" type="text" v-else>
</script>
<script type="text/javascript">
    Vue.component('form-control', {
        template: '#form-control',
        props: ['object', 'field', 'schema', 'extraClass']
    })
</script>

<script type="text/x-template" id="form-value">
    <span v-if="schema.type == 'decimal'" :title="object[field]">
        {{ commafy(object[field]) }}
    </span>
    <span v-else-if="schema.type == 'registration_no'" :title="object[field]">
        {{ dashify(object[field]) }}
    </span>
    <span v-else-if="schema.type == 'boolean'" :title="object[field]">
        <i class="fa fa-circle-o" v-if="object[field]"></i>
        <i class="fa fa-close" v-else-if="object[field] == false"></i>
    </span>
    <span v-else :title="object[field]">
        {{ object[field] }}
    </span>
</script>
<script type="text/javascript">
    Vue.component('form-value', {
        template: '#form-value',
        props: ['object', 'field', 'schema', 'extraClass']
    })
</script>

<script type="text/x-template" id="editable-row">
    <tr @click="select">
        <td v-if="checkable"><input type="checkbox" :value="object.id" v-model="checked"></td>
        <td :class="{'has-danger': errors[fieldName], 'text-right': fieldSchema(fieldName).type === 'decimal', 'fixed-col': fixedCols[index]}"
                :style="{'min-width': fixedCols[index] ? fixedCols[index] + 'px' : 'auto', 'width': fixedCols[index] ? fixedCols[index] + 'px' : 'auto'}"
                @click="check" v-for="(fieldName, index) in fields">
            <div class="cell" :style="{width: fixedCols[index] ? fixedCols[index] + 'px' : 'auto'}">
                <form-control extraClass="form-control-sm" :object="editing" :field="fieldName" :schema="fieldSchema(fieldName)" v-if="editing"></form-control>
                <form-value extraClass="" :object="object" :field="fieldName" :schema="fieldSchema(fieldName)" v-else></form-value>
            </div>
        </td>
        <slot></slot>
        <td>
            <template v-if="editing">
                <button class="btn btn-sm btn-success" @click="submit">저장</button>
                <button class="btn btn-sm btn-secondary" @click="cancel">취소</button>
            </template>
            <template v-else>
                <button class="btn btn-sm btn-outline-primary" @click="edit">수정</button>
                <button class="btn btn-sm btn-outline-danger" @click="destroy" v-if="deletable">삭제</button>
            </template>
        </td>
    </tr>
</script>
<script type="text/javascript">
    Vue.component('editable-row', {
        template: '#editable-row',
        props: {
            'object': Object,
            'schema': Object,
            'fields': Array,
            checkable: Boolean,
            deletable: Boolean,
            fixedCols: {
                type: Array,
                default: function() {
                    return []
                }
            }
        },
        data: function() {
            return {
                editing: null,
                errors: {},
                checked: false,
                selected: false
            }
        },
        mounted: function() {
            if (!this.object.id) this.edit()
        },
        watch: {
            checked: function() {
                this.$emit('checked', this.checked)
            }
        },
        methods: {
            fieldSchema: function(fieldName) {
                return this.schema[fieldName] || {}
            },
            select: function() {
                this.selected = !this.selected
            },
            edit: function() {
                console.log(this.object.constructor)
                if (this.object.constructor) {
                    this.editing = new this.object.constructor(this.object.getPlainData())
                } else {
                    this.editing = object.create({})
                }
                Vue.set(this.object, '$editing', true)
                this.$emit('edit', this)
            },
            check: function() {
                if (!this.editing && this.checkable) {
                    this.checked = !this.checked
                }
            },
            submit: function() {
                this.errors = {}
                this.$emit('submit', this)
            },
            cancel: function() {
                this.$emit('cancel', this)
            },
            destroy: function() {
                this.$emit('delete', this)
            },
            commit: function() {
                this.editing = null
                Vue.set(this.object, '$editing', false)
            },
            fail: function(errors) {
                this.errors = errors
            },
        }
    })
</script>

<script type="text/x-template" id="dict-form">
    <div>
        <div class="float-right">
            <button class="btn btn-sm btn-secondary" @click.prevent="addField">항목 추가</button>
        </div>
        <slot name="title"></slot>

        <table slot="body" class="table table-sm table-striped">
            <thead>
                <tr>
                    <th>항목명</th>
                    <th>내용</th>
                    <th>동작</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="field, index in editing">
                    <th>
                        <select class="form-control form-control-sm" v-model="field.key">
                            <option value="" :selected="true" v-if="!field.key">-- 항목 선택 --</option>
                            <option :value="fieldName" :selected="fieldName === field.key" v-for="fieldSpec, fieldName in schema">
                                {{ fieldName }}
                            </option>
                        </select>
                    </th>
                    <td>
                        <select class="form-control form-control-sm" v-model="field.value" v-if="schema[field.key] && schema[field.key].choices">
                            <option value="" :selected="true" v-if="!field.value">-- 항목 선택 --</option>
                            <option :value="choice.value" :selected="field.value == choice.value" v-for="choice in schema[field.key].choices">
                                {{ choice.display_name || choice.value }}
                            </option>
                        </select>
                        <input  class="form-control form-control-sm" type="text" v-model="field.value" v-else/>
                    </td>
                    <td><button class="btn btn-sm btn-outline-danger" @click="deleteField(index)">삭제</button></td>
                </tr>
            </tbody>
        </table>
    </div>
</script>

<script type="text/javascript">
    Vue.component('dict-form', {
        template: '#dict-form',
        props: ['dict', 'schema'],
        data: function() {
            return {
                editing: [],
            }
        },
        updated: function() {
            var edited = {}
            for (var i = 0; i < this.editing.length; i++) {
                edited[this.editing[i].key] = this.editing[i].value
            }
            this.$emit('change', edited)
        },
        mounted: function() {
            this.reset()
        },
        methods: {
            addField: function() {
                this.editing.push({key: '', value: ''})
            },
            deleteField: function(index) {
                this.editing.splice(index, 1)
            },
            reset: function() {
                this.editing = Object.keys(this.dict || {}).map(function(k) {
                    return {key: k, value: this.dict[k]}
                }.bind(this))
            }
        }
    })
</script>