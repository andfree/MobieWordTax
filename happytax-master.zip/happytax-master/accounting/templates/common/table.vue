<script type="text/x-template" id="data-table">
    <div v-if="schema">
        <div>
            <button class="btn btn-sm btn-outline-primary pull-xs-right" v-on:click.prevent="append"><i class="fa fa-plus"></i> 추가</button>
        </div>
        <div class="hscroll">
            <table class="table table-striped">
                <tbody>
                    <tr>
                        <th class="fixed-col" style="min-width: 100px">
                            <div class="cell" style="width: 100px;"> <span> 카테고리 </span> </div>
                        </th>
                        <th class="fixed-col" style="min-width: 140px">
                            <div class="cell" style="width: 140px;">
                                <span>항목명</span>
                            </div>
                        </th>
                        <th>유형</th>
                        <th>과세여부</th>
                        <th>월정</th>
                        <th>급여</th>
                        <th>상여</th>
                        <th>추가급여</th>
                        <th>추가상여</th>
                        <th>변경</th>
                    </tr>
                </tbody>
                <tbody>
                    <editable-row :object="object" :key="object"
                            :schema="schema"
                            :fields="fields"
                            :checkable="false"
                            :deletable="true"
                            :fixedCols="[100, 140]"
                            @submit="$emit('submit', object)"
                            @cancel="$emit('cancel', object)"
                            @delete="$emit('delete', object)"
                            v-for="object in paginator.objects">
                    </editable-row>
                </tbody>
            </table>
        </div>
    </div>
</script>
<script type="text/javascript">
    Vue.component('data-table', {
        template: '#data-table',
        props: {
            'paginator': Paginator,
            'schema': Object,
            'fields': Array,
            checkable: Boolean,
            deletable: Boolean,
            fixedCols: {
                type: Array,
                default: function() {
                    return []
                }
            }
        },
        data: function() {
            return {
                salaryInfoSchema: {}
            }
        }
    })
</script>