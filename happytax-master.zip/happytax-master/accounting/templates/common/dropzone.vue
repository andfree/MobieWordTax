<script type="text/x-template" id="dropzone">
    <div class="dropzone" ref="dropzone">
        <slot />
        <div class="dz-message" />
        <div style="position: fixed; width: 300px; left: 30px; bottom: 30px; z-index: 10;">
            <div class="alert alert-success" role="alert" v-if="progress">
                <div class="progress">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" :aria-valuenow="progress" aria-valuemin="0" aria-valuemax="100" :style="'width: ' + progress + '%'"></div>
                </div>
            </div>
        </div>
    </div>
</script>

<script type="text/javascript">
    Vue.component('dropzone', {
        template: '#dropzone',
        props: ['url', 'trader'],
        data: function () {
            return {
                globals: globals,
                dropzone: null,
                progress: 0
            }
        },
        mounted: function () {
            this.dropzone = new Dropzone(this.$refs.dropzone, {
                url: this.url,
                headers: {
                    'X-CSRFToken': '${csrf_token}'
                },
                clickable: true,
                previewTemplate: '<div style="display: none;"></div>'
            })

            this.dropzone.on('sending', function (file, xhr, formData) {
                formData.append('trader', this.trader)
            }.bind(this))

            this.dropzone.on('totaluploadprogress', function (progress) {
                this.progress = progress
                if (this.progress === 100) {
                    setInterval(function () {
                        if (this.progress === 100) this.progress = 0
                    }.bind(this), 500)
                }
            }.bind(this))
        },
        beforeDestroy: function () {
            this.dropzone.destroy()
        }
    });
</script>
