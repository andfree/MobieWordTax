<script type="text/javascript">
    var vueMethods = {
        formatDateToHour: function (date) {
            return moment(date).format('M.D H시');
        },
        commafy: function (number, digit) {
            if (!number) return ''
            if (!digit) digit = 3
            var regex = new RegExp('\\B(?=(\\d{' + digit + '})+(?!\\d))', 'g')

            var splitted = number.toString().split('.')
            splitted[0] = splitted[0].replace(regex, ",")

            return splitted.join('.')
        },
        dashify: function (number, digit) {
            if (!digit) digit = 7
            var regex = new RegExp('\\B(?=(\\d{' + digit + '})+(?!\\d))', 'g')

            return number.toString().replace(regex, '-')
        }
    }
    Vue.mixin({
        methods: vueMethods
    })

</script>