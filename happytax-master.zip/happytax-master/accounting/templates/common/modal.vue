<script type="text/x-template" id="modal">
    <div class="modal" style="display: block; background: rgba(0, 0, 0, .5)" @click="$emit('close')">
        <div class="modal-dialog" :class="sizeClass" role="document">
            <div class="modal-content" @click="onClickContent">
                <div class="modal-header">
                    <slot name="header">
                        <h5 class="modal-title">
                            <slot name="title">
                                제목
                            </slot>
                        </h5>

                        <button type="button" class="close" aria-label="Close" @click="$emit('close')">
                            <span aria-hidden="true">×</span>
                        </button>
                    </slot>
                </div>

                <div class="modal-body">
                    <slot name="body">
                        내용
                    </slot>
                </div>

                <div class="modal-footer">
                    <slot name="footer">
                        <slot name="extra-button"></slot>
                        <button type="button" class="btn btn-secondary" @click="$emit('close')">
                            취소
                        </button>
                        <button type="button" class="btn btn-primary" @click="$emit('submit')">
                            <slot name="submit-message">확인</slot>
                        </button>
                    </slot>
                </div>
            </div>
        </div>
    </div>
</script>

<script type="text/javascript">
    Vue.component('modal', {
        template: '#modal',
        props: ['size'],
        mounted: function () {
            $('body').addClass('modal-open')
            document.addEventListener('keydown', this.onKeyDown)
        },
        beforeDestroy: function () {
            document.removeEventListener('keydown', this.onKeyDown)
            $('body').removeClass('modal-open')
        },
        methods: {
            onKeyDown: function (event) {
                var keyCode = event.keyCode
                switch (keyCode) {
                    case 27:
                        this.$emit('close')
                        break
                }
            },
            onClickContent: function (event) {
                event.stopPropagation()
            }
        },
        computed: {
            sizeClass: {
                get: function () {
                    if (!this.size) {
                        return ''
                    }

                    return 'modal-' + this.size
                }
            }
        }
    });
</script>
