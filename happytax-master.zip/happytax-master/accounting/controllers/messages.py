from datetime import date

from django.contrib.auth.decorators import login_required
from django.urls import reverse
from django.http.response import HttpResponseRedirect, JsonResponse
from django.shortcuts import render
from django.template.context import RequestContext
from django.utils import timezone
from django.utils.html import escape
from djangox.mako import render_to_response

from accounting.models import CashSalesForm, Message, SalaryForm, Tax, Voucher, FaxForm
from accounting.util import history_back
from util import trader_required


@login_required
@trader_required
def index(request):
    request.active_tab = reverse(index)
    chat_messages = request.user.current_trader.message_set.order_by('created')
    unresolved = chat_messages.filter(type='information-request', done__isnull=True)
    statements = chat_messages.filter(type__endswith='statement')

    today = date.today()
    cash_sales_form = getattr(request, 'cash_sales_form', CashSalesForm())
    salary_form = getattr(request, 'salary_form', SalaryForm())

    vouchers = Voucher.objects.filter(trader__user=request.user)
    employees = vouchers.filter(type='salary').distinct('repeat_key')

    backto_path = history_back(request, '/dashboard')
    if 'unresolved' in request.GET:
        chat_messages = unresolved

    return render(request, 'messages/chat.html', locals())


@login_required
@trader_required
def done(request, resource_id):
    message = Message.objects.get(id=resource_id)
    message.done = timezone.now()
    message.save()

    return HttpResponseRedirect(request.META['HTTP_REFERER'])


@login_required
@trader_required
def create(request):
    content = request.POST.get('content', '').strip()
    content = escape(content).replace('\n', '<br>')

    if content == '':
        return JsonResponse({'error': 'no content'})

    trader = request.user.current_trader
    message = request.user.message_set.create(
        trader=trader,
        type='text',
        title=content,
        content=content
    )

    return JsonResponse({'id': message.id})
