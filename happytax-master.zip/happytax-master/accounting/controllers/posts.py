from django.urls import reverse
from django.shortcuts import render

from accounting.controllers import accounts
from accounting.models import Post
from accounting.util import handle_entity


def index(request):
    posts = Post.objects.filter(type='blog').order_by('-created')
    return render(request, 'blog/posts.html', locals())


def notices(request):
    request.active_tab = reverse(accounts.index)
    posts = Post.objects.filter(type='notice').order_by('-created')
    return render(request, 'blog/notices.html', locals())


def show(request, resource_id):
    response = handle_entity(request)
    if response:
        return response

    post = Post.objects.get(id=resource_id)
    return render(request, 'blog/post_show.html', locals())
