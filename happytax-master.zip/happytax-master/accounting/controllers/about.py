from djangox.mako import render_to_response


def index(request):
    return render_to_response('about.html', locals())
