from django.contrib.auth.decorators import login_required
from django.urls import reverse
from django.forms.forms import Form
from django.http import HttpResponseRedirect
from djangox.mako import render_to_response
from django.forms import fields
from django import forms
from django.template.context import RequestContext
from accounting.models import Post, Comment
from django.core.paginator import Paginator
from django.conf import settings


def index(request):
    request.active_tab = reverse(index)
    notices = Post.objects.filter(type='notice').order_by('-created')
    posts = Post.objects.filter(type='post').order_by('-created')
    page = Paginator(posts, settings.ITEMS_PER_PAGE).page(request.GET.get('page', 1))
    return render_to_response('help.html', locals())


class PostForm(Form):
    title = fields.CharField(label='제목', required=True)
    content = fields.CharField(label='내용', required=True, widget=forms.Textarea)


@login_required
def new(request):
    request.active_tab = reverse(index)
    form = PostForm()
    return render_to_response('board/new.html', locals(), RequestContext(request))


@login_required
def create(request):
    form = PostForm(request.POST)

    if form.is_valid():
        post = Post.objects.create(title=form.cleaned_data['title'],
                                   content=form.cleaned_data['content'],
                                   type='post',
                                   writer=request.user)
        post.save()

    return HttpResponseRedirect(reverse(index))


@login_required
def show(request, resource_id):
    request.active_tab = reverse(index)
    form = CommentForm()
    post = Post.objects.get(id=resource_id)
    return render_to_response('board/show.html', locals(), RequestContext(request))


@login_required
def delete(request, resource_id):
    if request.method == 'POST':
        Post.objects.get(id=resource_id).delete()

    return HttpResponseRedirect(reverse(index))


@login_required
def modify_form(request, resource_id):
    request.active_tab = reverse(index)
    post = Post.objects.get(id=resource_id)
    form = PostForm(initial={
        'title': post.title,
        'content': post.content
    })
    return render_to_response('board/modify.html', locals(), RequestContext(request))


@login_required
def modify(request, resource_id):
    form = PostForm(request.POST)

    if form.is_valid():
        post = Post.objects.get(id=resource_id)
        post.title = form.cleaned_data['title']
        post.content = form.cleaned_data['content']
        post.save()

    return HttpResponseRedirect(reverse(show, args=[resource_id]))


class CommentForm(Form):
    content = fields.CharField(label='댓글', required=True, widget=forms.Textarea(attrs={'rows': 30}))


@login_required
def create_comment(request, resource_id):
    form = CommentForm(request.POST)
    post = Post.objects.get(id=resource_id)

    if form.is_valid():
        comment = Comment.objects.create(writer=request.user,
                                         content=form.cleaned_data['content'],
                                         post=post)
        comment.save()

    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))


@login_required
def delete_comment(request, resource_id):
    if request.method == 'POST':
        Comment.objects.get(id=resource_id).delete()
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))


@login_required
def comment_modify_form(request, resource_id):
    request.active_tab = reverse(index)
    modifying_comment = Comment.objects.get(id=resource_id)
    post = Post.objects.get(id=modifying_comment.post_id)
    form = CommentForm(initial={
        'content': modifying_comment.content
    })
    return render_to_response('board/modify_comment.html', locals(), RequestContext(request))


@login_required
def modify_comment(request, resource_id):
    form = CommentForm(request.POST)
    comment = Comment.objects.get(id=resource_id)

    if form.is_valid():
        comment.content = form.cleaned_data['content']
        comment.save()

    return HttpResponseRedirect(reverse(show, args=[comment.post_id]))
