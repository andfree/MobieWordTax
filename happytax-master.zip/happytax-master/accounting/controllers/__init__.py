from django.shortcuts import render

from accounting.util import app_download_link, redirect_with_qs


def index(request):
    if request.user.is_authenticated:
        return redirect_with_qs('/dashboard', request)
    ios_applink = app_download_link(request, 'ios')
    android_applink = app_download_link(request, 'android')
    app_link = ios_applink if request.user_client == 'mobile-ios' else android_applink
    return render(request, 'landing-v15.html', locals())
