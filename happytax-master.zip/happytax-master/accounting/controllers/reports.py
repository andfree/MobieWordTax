from django.core import signing
from django.shortcuts import redirect


def show(request, resource_id):
    signature = signing.dumps(resource_id)
    link = f'https://mobiletax.kr/app/income-tax/{signature}'
    return redirect(link)
