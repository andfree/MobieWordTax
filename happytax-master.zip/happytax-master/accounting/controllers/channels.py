from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.http.response import JsonResponse

from accounting.api import MessageSerializer, AttachmentSerializer
from accounting.models import Attachment, Message
from util import trader_required


def show(request, resource_id):
    return None


@login_required
@trader_required
def messages(request):
    after = int(request.GET.get('after', 0))
    before = int(request.GET.get('before', 0))

    chat_messages = request.user.current_trader.message_set.order_by('-created').prefetch_related('readers', 'attachment_set')

    if 'unresolved' in request.GET:
        chat_messages = chat_messages.filter(type='information-request', done__isnull=True)

    if 'statement' in request.GET:
        chat_messages = chat_messages.filter(type__endswith='statement')

    if after:
        chat_messages = chat_messages.filter(id__gt=after)
    elif before:
        chat_messages = chat_messages.filter(id__lt=before)[:settings.MESSAGE_SIZE]
    else:
        chat_messages = chat_messages[:settings.MESSAGE_SIZE]

    Message.read_by(request.user, chat_messages)

    return JsonResponse(MessageSerializer(chat_messages, many=True).data, safe=False)


@login_required
@trader_required
def attachments(request):
    after = int(request.GET.get('after', 0))

    attachments = Attachment.objects.filter(message__sender=request.user).order_by('-created')
    if after:
        attachments = attachments.filter(id__gt=after)
    else:
        attachments = attachments[:settings.CARDS_PER_PAGE]

    return JsonResponse(AttachmentSerializer(attachments, many=True).data, safe=False)
