from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from util import trader_required


@login_required
@trader_required
def index(request):
    if request.user.beta:
        return redirect('/app/')

    request.active_tab = reverse(index)
    return render(request, 'dashboard-v15.html', locals())
