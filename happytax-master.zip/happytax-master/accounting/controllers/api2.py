import json
import requests
from django.shortcuts import redirect, render
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from accounting.models import User, Trader, Message, Attachment
from accounting.util import is_allowed_ip, get_client_ip
from django.conf import settings
from accounting.tasks import send_unread_message_notification_to_managers
from django.contrib.admin.views.decorators import staff_member_required

# GET /api2/message { regno, msg }
@csrf_exempt
def message(request):
    if not is_allowed_ip(request):
        return JsonResponse({
          'error': 'NOT_ALLOWED',
          'remote_ip': get_client_ip(request)
        })

    # FIXME: use POST
    regno = request.GET.get('regno', '').replace('-', '')
    msg = request.GET.get('msg', '')
    type = request.GET.get('type', 'text')

    traders=Trader.objects.filter(registration_no = regno)
    if len(traders) == 0:
        return JsonResponse({
          'error': 'invalid trader',
          'request': request.GET
        })

    if len(msg) == 0:
        return JsonResponse({
          'error': 'no msg',
          'request': request.GET
        })

    # user id 22 : 'mobiletax' in production server
    user = User.objects.get(id=22)
    trader = traders[0]
    message = user.message_set.create(
        trader=trader,
        type=type,
        content=msg
    )

    # TODO: is it right to send slack message always?
    send_unread_message_notification_to_managers.apply_async(args=[message.id],
        countdown=settings.MANAGER_NOTIFICATION_DELAY)

    return JsonResponse({'regno': regno, 'msg': msg})

@staff_member_required
@csrf_exempt
# GET /api2/trader?regno=123121234
def trader(request):
    regno = request.GET.get('regno', '').replace('-', '')

    traders = Trader.objects.filter(registration_no = regno)
    if len(traders) == 0:
        return JsonResponse({
          'error': 'no trader matched',
          'request': request.GET
        })

    trader = traders[0]
    traderid, business_name, is_corporation, activation = [
        getattr(trader, k) for k in (
            'id', 'business_name','is_corporation', 'activation')]
    name, email, phone = [
        getattr(trader.user, k) for k in ('name', 'email','phone')]

    return JsonResponse({
        'regno': regno,
        'traderid': traderid,
        'business_name': business_name,
        'is_corporation': is_corporation,
        'activation': activation,
        'name': name,
        'email': email,
        'phone': phone,
    })

# GET /api2/hpnum?regno=123121234
def hpnum(request):
    if not is_allowed_ip(request):
        return JsonResponse({
          'error': 'NOT_ALLOWED',
          'remote_ip': get_client_ip(request)
        })

    regno = request.GET.get('regno', '').replace('-', '')

    traders=Trader.objects.filter(registration_no = regno)
    if len(traders) == 0:
        return JsonResponse({
          'error': 'invalid trader',
          'request': request.GET
        })

    hpnum = traders[0].user.phone

    return JsonResponse({'regno': regno, 'hpnum': hpnum})

@staff_member_required
# GET /api2/gotochat?regno=123121234
def gotochat(request):
    regno = request.GET.get('regno', '').replace('-', '')

    traders=Trader.objects.filter(registration_no = regno)
    if len(traders) == 0:
        return JsonResponse({
          'error': 'invalid trader',
          'request': request.GET
        })

    return redirect('/manager/traders/{}/chat'.format(traders[0].id))

# POST /api2/send_bill { regno, vat, bankinfo, file }
@staff_member_required
@csrf_exempt
def send_bill(request):
    regno = request.POST.get('regno', '').replace('-', '').strip()
    traders = Trader.objects.filter(registration_no = regno)
    if len(traders) == 0:
        return JsonResponse({
          'error': 'invalid trader',
          'request': request.POST
        })
    trader = traders[0]
    hpnum = trader.user.phone

    tax = request.POST.get('tax', '').strip()
    type = request.POST.get('type', '').strip()
    bankinfo = request.POST.get('bankinfo', '').strip()

    # set chat message content and sms msg
    payment_content = '''{} 납부서를 전달드립니다.<br><br>
첨부된 납부서를 출력하여 납부하시거나 아래 가상계좌로 납부하실 수 있습니다.<br><br>
- 납부할 세액: {}원<br>
- 가상계좌<br>
{}'''.format(type, tax, bankinfo.replace('\n', '<br>'))

    payment_sms_msg = '''{} 납부서를 모바일택스 앱으로 전달하였습니다.

납부서를 출력하여 납부하시거나 아래 가상계좌로 납부하실 수 있습니다.

- 납부할 세액: {}원
- 가상계좌
{}'''.format(type, tax, bankinfo)

    refund_content = '''{} 납부서를 전달드립니다.<br><br>
아래와 같이 납부할 세액이 없습니다.<br><br>
- 납부할 세액: {}원'''.format(type, tax)

    refund_sms_msg = '''{} 납부서를 모바일택스 앱으로 전달하였습니다.

아래와 같이 납부할 세액이 없습니다.

- 납부할 세액: {}원'''.format(type, tax)

    content = payment_content if int(tax.replace(',', '')) > 0 else refund_content
    sms_msg = payment_sms_msg if int(tax.replace(',', '')) > 0 else refund_sms_msg

    # create message
    # user id 22 : 'mobiletax' in production server
    user = User.objects.get(id=22)
    message = user.message_set.create(
        trader=trader,
        type='notice',
        title='{} 납부서 안내'.format(type),
        content=content
    )

    # create attachment
    mimetype = request.FILES['file'].content_type
    Attachment.objects.create(
        message=message,
        manager=user,
        file=request.FILES['file'],
        mimetype=mimetype
    )

    return JsonResponse({
        'regno': regno,
        'company': trader.business_name,
        'hpnum': hpnum,
        'request': request.POST,
    })
