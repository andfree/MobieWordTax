from django.shortcuts import redirect, render

from accounting.util import redirect_with_qs


def index(request):
    # for deep link to /messages
    if request.META['QUERY_STRING'] == 'tochat':
        return redirect('/messages')
    if request.user.is_authenticated:
        return redirect_with_qs('/dashboard', request)

    return render(request, 'appmain-v15.html', locals())
