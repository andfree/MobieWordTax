from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http.response import HttpResponse

def try_trader(request):
    if not request.session.get('promo-vat'):
        request.session['promo-vat'] = 'start-trader'
    return render(request, 'welcome/try_promotion.html', locals())

def try_counsel(request):
    if not request.session.get('promo-vat'):
        request.session['promo-vat'] = 'start-counsel'
    return render(request, 'welcome/try_promotion.html', locals())

# /welcome/vat-with-mobiletax
def vat_with_mobiletax(request):
    return render(request, 'welcome/vat_with_mobiletax.html', locals())
