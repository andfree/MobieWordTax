from djangox.mako import render_to_response
from django.template.context import RequestContext
from django.urls import reverse
from accounting.util import history_back

def index(request):
    request.active_tab = reverse(index)
    backto_path = history_back(request, '/')
    return render_to_response('pricing.html', locals(), RequestContext(request))
