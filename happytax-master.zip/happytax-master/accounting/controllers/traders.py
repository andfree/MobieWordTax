import re
import traceback
from urllib.parse import parse_qs

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError, ObjectDoesNotExist
from django.forms import fields, TextInput
from django.forms.models import ModelForm
from django.forms.forms import Form
from django.shortcuts import redirect, render

from accounting.models import Trader, User
from django.forms.widgets import PasswordInput, HiddenInput
from django.template.context import RequestContext
from djangox.mako import render_to_response
from accounting.models import Document
from django.http.response import HttpResponse, HttpResponseRedirect
from django.urls import reverse

from marketing.models import Coupon
from accounting.tasks import send_slackbot_message


class AccountForm(Form):
    id = fields.CharField(label='아이디')
    password = fields.CharField(label='비밀번호', widget=PasswordInput)
    type = fields.CharField(widget=HiddenInput)


@login_required
def index(request):
    return redirect('/accounts')


@login_required
def show(request, resource_id):
    request.active_tab = reverse(index)
    trader = Trader.objects.get(id=resource_id)
    trader.check_ownership(request.user)

    return render(request, 'traders/show.html', locals())


@login_required
def upload_document(request, resource_id):
    try:
        trader = Trader.objects.get(id=resource_id)
        trader.check_ownership(request.user)

        document = Document.objects.create(
            trader=trader,
            type=request.POST['type'],
            file=request.FILES['file'],
            state='uploaded',
        )
    except:
        traceback.print_exc()
    return HttpResponse(document.file.name)


@login_required
def delete_document(request, resource_id):
    try:
        trader = Trader.objects.get(id=resource_id)
        trader.check_ownership(request.user)

        Document.objects.get(id=request.POST['document']).delete()
    except:
        traceback.print_exc()
    return HttpResponse('OK')


@login_required
def agree(request, resource_id):
    trader = Trader.objects.get(id=resource_id)
    trader.check_ownership(request.user)

    type = request.POST['type']
    trader.info[type] = True

    signature = request.POST.get('signature', None)
    if signature:
        trader.info['signature'] = request.POST['signature']

    trader.save()
    trader.update_activation()
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))


class TraderForm(ModelForm):
    business_name = fields.CharField(
        min_length=1,
        label="상호",
        required=True,
        widget=TextInput(
            attrs={
                'class': 'input-slt',
                'style': 'background-image: url(/static/mtx-v15/images/ic-building.svg);',
                'placeholder': '상호'
            }
        )
    )
    registration_no = fields.CharField(
        label='사업자등록번호',
        required=True,
        widget=TextInput(
            attrs={
                'class': 'input-slt',
                'style': 'background-image: url(/static/mtx-v15/images/ic-certification.svg);',
                'placeholder': '사업자등록번호',
                'maxlength' : '10',
            }
        )
    )

    class Meta:
        model = Trader
        fields = ['id', 'business_name', 'registration_no']

    def clean(self):
        data = super(TraderForm, self).clean()
        if 'registration_no' in data:
            registration_no = data['registration_no'].replace('-', '')
            if not registration_no.isnumeric() or len(registration_no) != 10:
                self.add_error('registration_no', '사업자등록번호는 숫자 10자리로 입력해주세요.')

        return data

class PhoneForm(ModelForm):
    phone = fields.CharField(
        label='핸드폰번호',
        required=True,
        widget=TextInput(
            attrs={
                'class': 'input-slt',
                'style': 'background-image: url(/static/mtx-v15/images/ic-mobile.svg);',
                'placeholder': '핸드폰번호',
                'maxlength' : '13',
            }
        )
    )

    class Meta:
        model = User
        fields = ['id', 'phone']

    def clean(self):
        phone = self.cleaned_data.get('phone')

        if not phone or not re.match(r'^0\d{1,2}-?\d{3,4}-?\d{4}$', phone):
            # HACK: why ValidationError doesn't work
            self.add_error('phone', '유효한 핸드폰번호를 01012345678 또는 010-1234-5678 형식으로 입력해 주십시오.')
            raise ValidationError('유효한 핸드폰번호를 01012345678 또는 010-1234-5678 형식으로 입력해 주십시오.')

@login_required
def new_old(request):
    is_new_user = request.GET.get('is_new_user', None)
    request.active_tab = reverse(index)
    form = TraderForm()
    return render_to_response('traders/new.html', locals(), RequestContext(request))

@login_required
def new(request):
    is_new_user = request.GET.get('ex', None)
    request.active_tab = reverse(index)
    form = TraderForm(prefix="trd")
    form_phone = PhoneForm(prefix="phn")
    return render(request, 'traders/new-v15.html', locals())

@login_required
def welcome(request):
    is_first_trader = request.user.trader_set.count() == 1

    # email-prome vat
    if request.session.get('promo-vat', '') == 'start-trader':
        request.session['promo-vat'] = 'sent-reg-trader-msg'
        send_slackbot_message(
            '[EMAIL-PROMO] {} 상호등록 http://mobiletax.kr/manager/traders/{}/chat'.format(
                request.user.current_trader.business_name,
                request.user.current_trader.id),
            channel='#new-client')

    return render(request, 'traders/welcome-v15.html', locals())

@login_required
def create(request):
    request.active_tab = reverse(index)
    form = TraderForm(request.POST, prefix="trd")
    form_phone = PhoneForm(request.POST, prefix="phn")
    is_phone_required = request.user.phone == ''

    if form.is_valid() and (not is_phone_required or form_phone.is_valid()):
        try:
            registration_no = form.cleaned_data['registration_no'].replace('-', '')
            trader = Trader.objects.create(user=request.user,
                                           business_name=form.cleaned_data['business_name'],
                                           is_corporation=registration_no[3] == '8',
                                           registration_no=registration_no)

        except:
            traceback.print_exc()
            # form.errors['__all__'] = '같은 사업자 번호가 이미 있습니다.'
            return render_to_response('traders/new.html', locals(), RequestContext(request))

        trader.save()

        ex = request.user_tracking_ex
        via = request.user_tracking_via
        is_first = request.user.current_trader is None
        qs = '?ex={}&via={}'.format(ex, via) if is_first else '?nonfst'

        request.user.current_trader = trader
        if is_phone_required:
            request.user.phone = form_phone.cleaned_data['phone']
        request.user.save()

        send_slackbot_message(
            ':seedling: http://mobiletax.kr/manager/traders/{}/chat {}({}): *신규상호등록*'.format(
                trader.id, trader.business_name, trader.user.phone),
            channel='#new-client')

        messages.add_message(request, messages.SUCCESS, '상호 등록을 축하드립니다.')

        return HttpResponseRedirect('/traders/welcome{}'.format(qs))

    return render_to_response('traders/new-v15.html', locals(), RequestContext(request))


@login_required
def destroy(request, resource_id):
    trader = Trader.objects.get(id=resource_id)
    trader.check_ownership(request.user)

    slack_imogi = ':x:'

    if trader.activation == 'activated':
        slack_imogi = ':question:'

    trader.activation = 'requested_to_delete'
    send_slackbot_message(
        '{} http://mobiletax.kr/manager/traders/{}/edit: {}({}) *삭제요청*'.format(
            slack_imogi, trader.id, trader.business_name, trader.user.phone),
        channel='#delete-noti')
    trader.save()
    return HttpResponseRedirect(reverse(index))


@login_required
def edit(request, resource_id):
    request.active_tab = reverse(index)

    trader = Trader.objects.get(id=resource_id)
    trader.check_ownership(request.user)

    form = TraderForm(instance=trader)
    return render_to_response('traders/edit.html', locals(), RequestContext(request))


@login_required
def update(request, resource_id):
    request.active_tab = reverse(index)
    trader = Trader.objects.get(id=resource_id)
    trader.check_ownership(request.user)

    form = TraderForm(request.POST, instance=trader)

    if form.is_valid():

        trader = form.save()

        return HttpResponseRedirect(reverse(show, args=[trader.id]))

    return render_to_response('traders/edit.html', locals(), RequestContext(request))


@login_required
def select(request, resource_id):
    trader = Trader.objects.get(id=resource_id)
    trader.check_ownership(request.user)

    request.user.current_trader = trader
    request.user.save()
    return HttpResponseRedirect(request.GET['next'])


@login_required
def apply_coupon(request, resource_id):
    trader = Trader.objects.get(id=resource_id)
    try:
        coupon = Coupon.objects.get(code=request.POST['coupon'])
        tc, created = trader.tradercoupon_set.get_or_create(trader=trader, coupon=coupon)

        if created:
            messages.add_message(request, messages.SUCCESS, '할인쿠폰을 적용했습니다.')
        else:
            messages.add_message(request, messages.WARNING, '이미 적용된 쿠폰입니다.')

        return redirect(show, resource_id)
    except ObjectDoesNotExist:
        messages.add_message(request, messages.ERROR, '입력하신 번호의 쿠폰을 찾을 수 없습니다.')
        return redirect(show, resource_id)
