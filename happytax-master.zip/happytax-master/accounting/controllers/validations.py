from django.contrib import messages
from django.core.exceptions import FieldDoesNotExist, ObjectDoesNotExist
from django.shortcuts import render
from django.template.context import RequestContext
from django.utils import timezone
from djangox.mako import render_to_response

from accounting.controllers.accounts import ResetForm
from accounting.models import Validation, User


def show(request, resource_id):
    try:
        validation = Validation.objects.get(code=resource_id)

        if validation.is_expired():
            raise Validation.ValidationFailed('인증기한이 만료되었습니다.')

        if validation.validated:
            raise Validation.ValidationFailed('이미 인증되었습니다.')

        if validation.type == 'validate-email':

            validation.user.is_validated = True
            validation.user.save()

            validation.validated = timezone.now()
            validation.save()

            return render_to_response('validations/%s.html' % (validation.type,), locals())

        elif validation.type == 'reset-password':
            return render_to_response('validations/reset_password.html', locals(), RequestContext(request))

    except Validation.ValidationFailed as e:
        message = str(e)
        return render_to_response('validations/alert.html', locals())
    except ObjectDoesNotExist:
        message = '인증코드가 잘못되었습니다. 다시 인증을 요청하시기 바랍니다.'
        return render_to_response('validations/alert.html', locals())


def find_password(request):
    reset_form = ResetForm()
    return render_to_response('validations/find_password.html', locals(), RequestContext(request))


def send_reset_password(request):
    reset_form = ResetForm(request.POST)
    if not reset_form.is_valid():
        return render_to_response('validations/find_password.html', locals(), RequestContext(request))

    users = User.objects.filter(email=reset_form.cleaned_data['email'])
    if not users:
        reset_form.add_error('email', '가입되지 않은 이메일입니다.')
        return render_to_response('validations/find_password.html', locals(), RequestContext(request))

    user = users[0]

    template_name = 'validations/alert.html'
    Validation.send_reset_password(user)
    level = 'success'
    message = '비밀번호 재설정 메일을 발송했습니다. 메일함을 확인해보시기 바랍니다.'
    return render(request, template_name, locals())


def reset_password(request):
    validation= Validation.objects.get(id=request.POST['validation'])

    if len(request.POST['password']) < 4:
        messages.add_message(request, messages.ERROR, '비밀번호는 4자 이상이어야 합니다.')
        return render_to_response('validations/reset_password.html', locals(), RequestContext(request))

    if request.POST['password'] != request.POST['password_confirm']:
        messages.add_message(request, messages.ERROR, '비밀번호가 일치하지 않습니다.')
        return render_to_response('validations/reset_password.html', locals(), RequestContext(request))

    validation.user.set_password(request.POST['password'])
    validation.user.save()

    validation.validated = timezone.now()
    validation.save()

    level = 'success'
    message = '비밀번호를 설정했습니다. 로그인해보시기 바랍니다.'
    return render_to_response('validations/alert.html', locals())
