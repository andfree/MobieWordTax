from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.core import serializers
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.urls import reverse
from django.shortcuts import render
from django.utils import timezone
from django.template.context import RequestContext
from django.http import HttpResponse

from accounting.controllers import invoices
from accounting.models import Voucher
from util import trader_required

@login_required
@trader_required
def index(request):
    request.active_tab = reverse(invoices.index)

    year = int(request.GET.get('year', timezone.now().year))

    vouchers = Voucher.objects.filter(trader__user=request.user, type='cash-sales')
    vouchers = vouchers.order_by('-created')

    search = request.GET.get('search', '')
    if search:
        vouchers = vouchers.filter(info__icontains=search)

    # hack : no pagenation
    page = Paginator(vouchers, settings.CARDS_PER_PAGE).page(1)

    return render(request, 'journal/entries.html', locals())

@login_required
def ajax(request, resource_id):
    vouchers = Voucher.objects.filter(trader__id=resource_id, type='cash-sales')
    vouchers = vouchers.order_by('-created')

    page_number = int(request.GET.get('currentPage', 1))
    paginator = Paginator(vouchers, 10)

    try:
        page = paginator.page(page_number)
    except PageNotAnInteger:
        page = paginator.page(1)
    except EmptyPage:
        page = paginator.page(paginator.num_pages)

    total_count_page = paginator.num_pages
    vouchers = page.object_list

    vouchers = serializers.serialize('json', vouchers)

    resjson = '{{ "total_count_page" : {}, "vouchers" : {} }}'.format(total_count_page, vouchers)

    return HttpResponse(resjson, content_type='application/json')
