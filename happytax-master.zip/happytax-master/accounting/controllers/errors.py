from django.shortcuts import render


def server_error(request):
    return render(request, 'error/server_error.html', locals(), status=500)


def not_found(request, exception):
    return render(request, 'error/not_found.html', locals(), status=404)


def permission_denied(request, exception):
    return render(request, 'error/permission_denied.html', locals(), status=403)
