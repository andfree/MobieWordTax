import hashlib
import os

from PIL import Image
from django.core.exceptions import PermissionDenied, MultipleObjectsReturned
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.urls import reverse
from django.shortcuts import redirect
from io import BytesIO

from accounting.models import Tax, Voucher, Attachment, Document, Thumbnail
from happytax import settings

model_hash_map = {}
for model in [Tax, Voucher, Attachment, Document]:
    model_hash_map[hashlib.sha1(model.__name__.encode('utf8')).hexdigest()] = model


def file_url(obj):
    return reverse(show, args=['%s-%s' % (hashlib.sha1(obj.__class__.__name__.encode('utf8')).hexdigest(), obj.id)])


settings.MAKO_DEFAULT_CONTEXT['file_url'] = file_url
settings.MAKO_DEFAULT_CONTEXT['default_storage'] = default_storage


# redirect to s3
# url /files/:id
def show(request, resource_id):
    model_hash, resource_id = resource_id.split('-')

    model = model_hash_map[model_hash]
    obj = model.objects.get(id=resource_id)
    if obj.trader and obj.trader.user != request.user and not request.user.is_staff:
        raise PermissionDenied

    # Thumbnail은 Attachment의 경우에만 존재한다.
    if model != Attachment:
        return redirect(default_storage.url(obj.file.name))

    trader_name = obj.trader.business_name.replace(" ", "_")
    filename = obj.get_thumbnail_filename(request.GET.get('size'))
    return redirect(default_storage.url(filename, trader_name))


def make_thumbnail(original, alias):
    alias, size = original.get_thumbnail_size(alias)

    try:
        thumbnail, created = Thumbnail.objects.select_related('image').get_or_create(image=original, alias=alias)

        if not created:
            return thumbnail

        if not thumbnail.image.mimetype.startswith('image') or \
                (thumbnail.image.width <= size[0] and thumbnail.image.height <= size[1]):
            thumbnail.file = original.file
            thumbnail.width = thumbnail.image.width
            thumbnail.height = thumbnail.image.height
            thumbnail.save()
            return thumbnail

        image = Image.open(original.file)
        image.thumbnail(size, Image.ANTIALIAS)
        with BytesIO() as temp:
            image.save(temp, image.format)
            temp.seek(0)

            name, extension = os.path.splitext(original.file.name)
            filename = '{}_{}{}'.format(name, alias, extension)

            thumbnail.width, thumbnail.height = image.size
            thumbnail.file.save(filename, ContentFile(temp.read()), save=True)
    except MultipleObjectsReturned:
        thumbnail = Thumbnail.objects.filter(image=original, alias=alias).first()
    except OSError:
        pass

    return thumbnail
