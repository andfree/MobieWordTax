import datetime
import mimetypes
import unicodedata

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.contenttypes.models import ContentType
from django.core.paginator import Paginator
from django.urls import reverse, resolve
from django.http.response import HttpResponse
from django.shortcuts import redirect
from django.template.context import RequestContext
from django.utils import timezone
from djangox.mako import render_to_response

from accounting.models import Voucher, Trader, CashSalesForm, SalaryForm, Attachment, Message
from accounting.tasks import make_thumbnail
from util import trader_required, resolve_referer


@login_required
@trader_required
def index(request):
    today = datetime.date.today()

    attachments = Attachment.objects.filter(message__sender=request.user).order_by('-created')
    pages = Paginator(attachments, settings.CARDS_PER_PAGE)

    page_number = int(request.GET.get('page', 1))
    page_number = 1 if page_number < 1 else page_number
    page_number = pages.num_pages if page_number > pages.num_pages else page_number

    page = pages.page(page_number)
    return render_to_response('vouchers/index.html', locals(), RequestContext(request))


@login_required
@trader_required
def create(request):
    mimetype = request.FILES['file'].content_type
    if not mimetype:
        guessed = mimetypes.guess_type(request.FILES['file'].name)
        mimetype = guessed[0]

    trader = request.user.current_trader
    if request.user.is_active and request.user.is_staff and request.POST.get('trader'):
        trader = Trader.objects.get(id=request.POST['trader'])

    request.FILES['file'].name = unicodedata.normalize('NFC', request.FILES['file'].name)
    attachment = Attachment.objects.create(file=request.FILES['file'], mimetype=mimetype)

    timestamp = request.POST.get('created')
    created = None
    if timestamp:
        created = datetime.datetime.fromtimestamp(int(timestamp) / 1000)

    if mimetype and mimetype.startswith('image') and not settings.DEBUG:
        make_thumbnail.delay(attachment.id, trader.id, request.user.id, created)
    else:
        message = Message.objects.create(
            trader=trader,
            sender=request.user,
            type='attachment',
            title='첨부파일',
            content=attachment.file.name,
            content_type=ContentType.objects.get_for_model(Attachment),
            content_id=attachment.id,
        )

        if created:
            message.created = created
            message.save(update_fields=['created'])
            attachment.created = created

        attachment.message = message
        attachment.save()

    return HttpResponse(attachment.file.name)


@login_required
@trader_required
def create_cash_sales(request):
    request.active_tab = reverse(index)

    back = resolve(request.GET.get('back', reverse(index)))

    cash_sales_form = CashSalesForm(request.POST)
    if cash_sales_form.is_valid():
        voucher = Voucher.objects.create(
            trader=request.user.current_trader,
            type='cash-sales',
            mimetype='text/plain',
            preprocessed=timezone.now(),
            info=cash_sales_form.cleaned_data
        )

        Message.create_from_voucher(voucher)

        messages.add_message(request, messages.SUCCESS, '현금매출 %s원이 기록되었습니다.' % voucher.info['amount'])
        return redirect(reverse(back.func, args=back.args, kwargs=back.kwargs))

    else:
        request.modal = 'cash-sales'
        request.cash_sales_form = cash_sales_form
        return back.func(request, *back.args, **back.kwargs)



@login_required
@trader_required
def create_salary(request):
    request.active_tab = reverse(index)

    back = resolve(request.GET.get('back', reverse(index)))

    salary_form = SalaryForm(request.POST)
    if salary_form.is_valid():
        voucher = Voucher.objects.create(
            trader=request.user.current_trader,
            type='salary',
            mimetype='text/plain',
            preprocessed=timezone.now(),
            info=salary_form.cleaned_data,
            repeat_key='salary_' + str(salary_form.cleaned_data['registration_no'])
        )

        Message.create_from_voucher(voucher)

        messages.add_message(request, messages.SUCCESS, '급여지급 %s원이 기록되었습니다.' % voucher.info['salary_before_tax'])
        return redirect(reverse(back.func, args=back.args, kwargs=back.kwargs))
    else:
        request.modal = 'salary'
        request.salary_form = salary_form
        return back.func(request, *back.args, **back.kwargs)

        return resolve_referer(request)[0](request)


@login_required
@trader_required
def delete(request, resource_id):
    if request.method == 'POST':
        Voucher.objects.get(id=resource_id).delete()

    return redirect(index)
