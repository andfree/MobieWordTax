from django.shortcuts import redirect

from accounting.util import app_download_link


def index(request):
    platform = request.GET.get('platform', 'android')
    return redirect(app_download_link(request, platform))
