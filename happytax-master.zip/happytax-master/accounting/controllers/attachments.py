from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404

from accounting import tasks
from accounting.models import Attachment, Thumbnail


@login_required
def file(request, resource_id):
    attachment = None
    thumbnail = None

    try:
        size = request.GET.get('size')
        if not size:
            return

        thumbnail = Thumbnail.objects.select_related('image').filter(image__id=resource_id, alias=size).first()
        attachment = thumbnail.image
    finally:
        if not attachment:
            attachment = get_object_or_404(Attachment, id=resource_id)

        if not request.user.is_staff and attachment.message:
            attachment.message.trader.check_ownership(request.user)

        response = HttpResponseRedirect(thumbnail.file.url if thumbnail else attachment.file.url)
        response['Cache-Control'] = 'max-age=31536000'
        return response


@login_required
def fax(request, resource_id):
    receiver_number = request.POST['number']

    tasks.send_fax.delay(receiver_number, request.user.current_trader.business_name, resource_id)
    messages.add_message(request, messages.SUCCESS, '문서를 팩스번호 {}로 전송했습니다.'.format(receiver_number))
    return HttpResponseRedirect(request.POST['next'])
