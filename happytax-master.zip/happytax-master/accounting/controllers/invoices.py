import datetime
import inspect
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.urls import reverse
from django.db.models.query_utils import Q
from django.template.context import RequestContext
from django.utils import timezone
from djangox.mako import render_to_response
from util import trader_required


@login_required
@trader_required
def index(request):
    request.active_tab = reverse(index)

    year = int(request.GET.get('year', timezone.now().year))
    years = request.user.current_trader.tax_years()

    invoices = request.user.current_trader.invoice_set.filter(issued__year=year).order_by('-issued')
    invoice_type = request.GET.get('invoice_type', 'all')
    if invoice_type != 'all':
        invoices = invoices.filter(invoice_type=invoice_type)

    search = request.GET.get('search', '')
    if search:
        invoices = invoices.filter(Q(supplier_name__contains=search)
                                   | Q(consumer_name__contains=search)
                                   | Q(product_name__contains=search)
                                   )

    page_number = request.GET.get('page', 1)
    page = Paginator(invoices, settings.ITEMS_PER_PAGE).page(page_number)

    return render_to_response('invoices/index.html', locals(), RequestContext(request))

