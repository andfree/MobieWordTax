from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from django.http.response import HttpResponseRedirect
from django.template.context import RequestContext
from django.utils import timezone
from djangox.mako import render_to_response
from accounting.controllers import invoices
from accounting.controllers.files import file_url
from accounting.fax import Fax, FaxAuthorizationError, FaxError
from accounting.models import FaxForm, Tax, Message
from util import trader_required
import datetime
import urllib


@login_required
@trader_required
def index(request):
    request.active_tab = reverse(invoices.index)

    tax_documents = request.user.current_trader.message_set.filter(type__in=Message.TAX_DOCUMENT_TYPES).order_by('-created')
    return render_to_response('tax/report.html', locals())


@login_required
def fax(request, resource_id):
    attachment = Tax.objects.get(id=resource_id)
    receiver_number = request.POST['number']

    try:
        Fax.send_fax(receiver_number, request.user.current_trader.business_name, attachment.file)
        result = messages.SUCCESS
        message = '문서를 팩스번호 {}로 전송했습니다.'.format(receiver_number)
    except FaxAuthorizationError as e:
        result = messages.ERROR
        message = '관리자에게 문의해주십시오. ({})'.format(e.args[1])
    except FaxError as e:
        result = messages.ERROR
        message = e.args[1]

    messages.add_message(request, result, message)
    return HttpResponseRedirect(request.POST['next'])
