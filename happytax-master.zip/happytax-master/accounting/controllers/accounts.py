from django.conf import settings
from django.contrib import auth, messages
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.urls import reverse
from django.db.models.query_utils import Q
from django.forms import fields, TextInput
from django.forms.forms import Form
from django.forms.widgets import PasswordInput
from django.http.response import HttpResponseRedirect
from django.shortcuts import redirect, render

from accounting.models import User, Post, Validation, OneSignal
from accounting.util import record_acquisition, handle_entity
from marketing.models import Coupon


class SignUpForm(Form):
    email = fields.EmailField(
        label='이메일',
        required=True,
        widget=TextInput(
            attrs={
                'class': 'input-slt',
                'style': 'background-image: url(/static/mtx-v15/images/ic-email.svg);',
                'placeholder': '이메일'
            }
        )
    )
    password = fields.CharField(
        label='비밀번호',
        required=True,
        widget=PasswordInput(
            attrs={
                'class': 'input-slt',
                'style': 'background-image: url(/static/mtx-v15/images/ic-lock.svg);',
                'placeholder': '비밀번호'
            }
        )
    )
    password_confirm = fields.CharField(
        label='비밀번호 확인',
        required=True,
        widget=PasswordInput(
            attrs={
                'class': 'input-slt',
                'style': 'background-image: url(/static/mtx-v15/images/ic-lock.svg);',
                'placeholder': '비밀번호 확인'
            }
        )
    )
    name = fields.CharField(
        label='이름(실명)',
        required=True,
        widget=TextInput(
            attrs={
                'class': 'input-slt',
                'style': 'background-image: url(/static/mtx-v15/images/ic-user.svg);',
                'placeholder': '이름(실명)'
            }
        )
    )
    privinfo = fields.BooleanField(
        label='<span class="privacy-policy-open">개인정보수집</span>에 동의합니다',
        required=True
    )

    def clean(self):
        if (User.objects.filter(username=self.cleaned_data.get('email')).exists() or
            User.objects.filter(email=self.cleaned_data.get('email')).exists()):
            raise ValidationError('같은 이메일 주소가 이미 존재합니다. (가입한 정보를 잊으신 경우, 모바일택스 고객센터 1833-8332로 연락주시면 확인 후 조치해드리겠습니다.)')

        if User.objects.filter(username=self.cleaned_data.get('registration_no')).exists():
            raise ValidationError('같은 주민번호가 이미 존재합니다.')

        password = self.cleaned_data.get('password')
        password_confirm = self.cleaned_data.get('password_confirm')
        if password != password_confirm:
            raise ValidationError('패스워드가 맞지 않습니다.')

        privinfo = self.cleaned_data.get('privinfo')
        if not privinfo:
            raise ValidationError('개인정보수집에 동의해 주십시오.')

        return self.cleaned_data


def signup(request):
    if request.user.is_authenticated:
        return redirect('/dashboard')

    response = handle_entity(request)
    if response:
        return response

    signup_form = SignUpForm()
    return render(request, 'signup-v15.html', locals())


def create(request):
    request.active_tab = reverse(index)
    login_form = LoginForm()
    signup_form = SignUpForm(request.POST)
    if signup_form.is_valid():
        user = User.objects.create_user(username=signup_form.cleaned_data['email'],
                                   email=signup_form.cleaned_data['email'],
                                   name=signup_form.cleaned_data['name'],
                                   password=signup_form.cleaned_data['password'])

        code = request.POST.get('c')
        if code:
            try:
                coupon = Coupon.objects.get(code=code)
                user.usercoupon_set.create(coupon=coupon)
            except Coupon.DoesNotExist:
                pass

        record_acquisition(request, user)

        user = auth.authenticate(username=user.username, password=signup_form.cleaned_data['password'])
        auth.login(request, user)
        import accounting.controllers.traders
        path = reverse(accounting.controllers.traders.new)
        ex = request.user_tracking_ex
        url = '{}?ex={}&via=dr'.format(path, ex)
        res = HttpResponseRedirect(url)
        return res

    # messages.add_message(request, messages.WARNING, signup_form.errors)

    return render(request, 'signup-v15.html', locals())


class LoginForm(Form):
    username = fields.CharField(
        label='이메일 또는 사업자등록번호',
        widget=TextInput(
            attrs={
                'class': 'input-slt',
                'style': 'background-image: url(/static/mtx-v15/images/ic-email.svg);',
                'placeholder': '이메일 또는 사업자등록번호',
                'autocapitalize': 'off',
            }
        )
    )
    password = fields.CharField(
        label='비밀번호',
        widget=PasswordInput(
            attrs={
                'class': 'input-slt',
                'style': 'background-image: url(/static/mtx-v15/images/ic-lock.svg);',
                'placeholder': '비밀번호'
            }
        )
    )


class ResetForm(Form):
    email = fields.EmailField(
        label='이메일',
        widget=TextInput(
            attrs={
                'class': 'input-slt',
                'style': 'background-image: url(/static/mtx-v15/images/ic-email.svg);',
                'placeholder': '이메일'
            }
        )
    )


def login(request):
    if request.user.is_authenticated:
        return redirect(request.GET.get('next', '/dashboard'))

    response = handle_entity(request)
    if response:
        return response

    login_form = LoginForm()

    next = request.GET.get('next')
    next_to = '?next={}'.format(next) if next else ''

    return render(request, 'login-v15.html', locals())


def authenticate(request):
    login_form = LoginForm(request.POST)
    signup_form = SignUpForm()
    if login_form.is_valid():
        users = User.objects.filter(Q(username=login_form.cleaned_data['username']) |
                                    Q(trader__registration_no=login_form.cleaned_data['username']))
        if users.exists():
            user = auth.authenticate(username=users[0].username, password=login_form.cleaned_data['password'])
            if user is not None:
                auth.login(request, user)
                res = HttpResponseRedirect(request.GET.get('next', '/dashboard'))
                return res
            else:
                login_form.add_error('password',
                                     '비밀번호가 틀렸습니다.<br><a href="/validations/find_password">비밀번호를 잃어버리셨나요?</a>')
        else:
            login_form.add_error('username', '존재하지 않는 사용자입니다. (가입한 정보를 잊으신 경우, 모바일택스 고객센터 1833-8332로 연락주시면 확인 후 조치해드리겠습니다.)')

    modal = "login"
    next = request.GET.get('next')
    next_to = '?next={}'.format(next) if next else ''

    return render(request, 'login-v15.html', locals())


def logout(request):
    one_signal_user_id = request.session.get('one_signal_user_id')
    if one_signal_user_id:
        OneSignal.objects.filter(one_signal_user_id=one_signal_user_id).update(user=None)
    auth.logout(request)
    return HttpResponseRedirect(request.GET.get('next', '/'))


@login_required
def index(request):
    request.active_tab = reverse(index)
    trader = request.user.trader_set.first()
    return render(request, 'accounts/index.html', locals())


@login_required
def send_email_validation(request):
    Validation.send_validate_email(request.user)
    messages.add_message(request, messages.SUCCESS, '인증 메일을 발송했습니다. 메일함을 확인해보세요.')
    return redirect(index)


def change_password(request):

    if len(request.POST['password']) < 4:
        messages.add_message(request, messages.ERROR, '비밀번호는 4자 이상이어야 합니다.')
        return index(request)

    if request.POST['password'] != request.POST['password_confirm']:
        messages.add_message(request, messages.ERROR, '비밀번호가 일치하지 않습니다.')
        return index(request)

    request.user.set_password(request.POST['password'])
    request.user.save()

    update_session_auth_hash(request, request.user)

    messages.add_message(request, messages.SUCCESS, '비밀번호를 변경했습니다.')
    return redirect(index)
