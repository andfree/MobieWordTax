import datetime
import logging
import traceback
import requests
import json

import slackclient
from dateutil.relativedelta import relativedelta
from django.conf import settings
from django.utils.html import escape

from accounting.celery import Celery
from accounting.fax import Fax
from accounting.alimtalk import Alimtalk

from celery.utils.log import get_task_logger
logger = get_task_logger(__name__)

app = Celery('mobiletax')
app.config_from_object('django.conf:settings', namespace='CELERY')


@app.task
def push_notification(user, title, message, badge):
    from accounting.models import OneSignal

    include_player_ids = list(OneSignal.objects.filter(user=user).values_list('one_signal_user_id', flat=True))
    if not include_player_ids:
        return

    header = {'Content-Type': 'application/json; charset=utf-8',
              'Authorization': f'Basic {settings.ONE_SIGNAL_API_KEY}'}

    payload = {
        'app_id': settings.ONE_SIGNAL_APP_ID,
        'heading': {'en': title},
        'contents': {'en': message},
        'ios_badgeType': 'SetTo',
        'ios_badgeCount': badge,
        'include_player_ids': include_player_ids,
    }

    requests.post('https://onesignal.com/api/v1/notifications', headers=header, data=json.dumps(payload))


@app.task
def send_slackbot_message(text, channel=settings.SLACK_BOT_CHANNEL, trader_name='[bot]'):
    if settings.DEBUG: return

    logging.warning('send_slackbot_message() to %s from %s\n%s', channel, trader_name, text)
    sc = slackclient.SlackClient(settings.SLACK_BOT_TOKEN)
    sc.api_call('chat.postMessage',
                channel=channel,
                text=text,
                as_user=True,
                username='모바일택스')


message_notification_format = '''{icon} http://mobiletax.kr/manager/traders/{message.trader.id}/chat
*{message.trader.business_name}*: {message.content}'''

@app.task
def send_slackbot_critical_report(tag, msg, exception=None):
    if settings.DEBUG: return

    logging.warning('send_slackbot_critical_report() %s %s', tag, msg)
    if exception:
        text = '*[{}]* {}\n\n*{}*\n\n{}'.format(tag, msg, str(exception),
                                            traceback.format_exc())
    else:
        text = '*[{}]* {}'.format(tag, msg)

    sc = slackclient.SlackClient(settings.SLACK_BOT_TOKEN)
    sc.api_call('chat.postMessage',
                channel=settings.SLACK_BOT_CRITICAL_REPORT_TO,
                text=text,
                as_user=False,
                username='문제봇')

@app.task
def send_unread_message_notification_to_managers(message_id):
    if settings.DEBUG: return

    from accounting.models import Message
    message = Message.objects.get(id=message_id)

    sent = False
    for manager in message.trader.manager_set.filter(slackid__isnull=False):
        sent = True
        send_slackbot_message(message_notification_format.format(
                                message=message,
                                icon=''),
                              channel='@' + manager.slackid,
                              trader_name=message.trader.business_name)

    if not sent:
        send_slackbot_message(message_notification_format.format(
                                message=message,
                                icon=':moneybag:'),
                              channel='#new-client',
                              trader_name=message.trader.business_name)
    else:
        broadcast_unread_message_notification_to_managers.apply_async(
            args=[message_id],
            countdown=settings.UNREAD_MANAGER_NOTIFICATION_DELAY
        )


@app.task
def broadcast_unread_message_notification_to_managers(message_id):
    if settings.DEBUG: return

    from accounting.models import Message
    message = Message.objects.get(id=message_id)

    if message.readers.filter(is_staff=True).exists(): return

    send_slackbot_message(message_notification_format.format(
                            message=message,
                            icon=':turtle:'),
                          channel='#client',
                          trader_name=message.trader.business_name)


@app.task
def send_fax(receiver_number, business_name, attachment_id):
    Fax.send_fax(receiver_number, business_name, attachment_id)


@app.task
def update_fax_status(receipt_number, attachment_id):
    Fax.update_status(receipt_number, attachment_id)


@app.task
def make_thumbnail(image_id, trader_id, sender_id, created=None):
    from django.contrib.contenttypes.models import ContentType
    from django.core.exceptions import ObjectDoesNotExist
    from accounting.models import Attachment, Message, Trader, User
    from accounting.controllers.files import make_thumbnail

    image = Attachment.objects.get(id=image_id)
    make_thumbnail(image, None)

    # 메세지를 추가로 생성할 필요가 없는 경우
    if image.message or not trader_id or not sender_id:
        return

    try:
        trader = Trader.objects.get(id=trader_id)
        sender = User.objects.get(id=sender_id)

        message = Message.objects.create(
            trader=trader,
            sender=sender,
            type='attachment',
            title='첨부파일',
            content=image.file.name,
            content_type=ContentType.objects.get_for_model(Attachment),
            content_id=image.id,
        )

        if created:
            message.created = created
            message.save(update_fields=['created'])
            image.created = created

        image.message = message
        image.save()
    except ObjectDoesNotExist:
        # 비동기로 처리되는 특성상 trader나 sender가 여러 이유로 존재하지 않을 수도 있다.
        return


@app.task
def send_alimtalk(sender, receiver, template_code, replace_msg):
    try:
        result = Alimtalk.send(sender, receiver, template_code, replace_msg)
        logging.info('[tasks.send_alimtalk][success] %s', result)
    except Exception as e:
        logging.error('[tasks.send_alimtalk][error] request([%s], [%s], [%s], [%s]) response(%s)'
            , sender, receiver, template_code, replace_msg, e)
        raise e


@app.task
def send_message_from_accounting_manager(trader_id, content):
    from accounting.models import Trader
    trader = Trader.objects.get(id=trader_id)

    sender = trader.accounting_manager
    type_ = 'text'
    content = escape(content).replace('\n', '<br>')

    if not sender:
        from accounting.models import ensure_mobiletax_user
        sender = ensure_mobiletax_user()
        type_ = 'notice'

    sender.message_set.create(
        trader=trader,
        type=type_,
        title=content,
        content=content
    )


@app.task
def init_account(account_id):
    from accounting.models import Account, CardApproval, Message, ensure_mobiletax_user
    from accounting.codef import get_card_approval_list

    account = Account.objects.get(id=account_id)
    if account.status == 'in progress':
        return

    connected_id = account.trader.connectedid_set.first()
    if not connected_id:
        return

    yesterday = (datetime.datetime.now() - relativedelta(days=1)).date()
    latest = account.latest or datetime.date(1900, 1, 1)
    if latest >= yesterday:
        return

    account.status = 'in progress'
    account.message = None
    account.save(update_fields=['status', 'message'])

    approvals = []
    try:
        for i in range(0, 6, 3):
            end_date = min(yesterday - relativedelta(months=i) + relativedelta(day=31), yesterday)
            start_date = (end_date - relativedelta(months=2)).replace(day=1)
            start_date = max(start_date, latest)
            if start_date > end_date or end_date < latest:
                continue

            approvals.extend(get_card_approval_list(account, start_date, end_date))

        CardApproval.objects.bulk_create(approvals)
        account.latest = max(yesterday, latest)
        account.status = 'successful'
        account.message = None
        account.save(update_fields=['latest', 'status', 'message'])

        Message.objects.create(trader=account.trader,
                               sender=ensure_mobiletax_user(),
                               type='notice',
                               title='연동 완료 안내',
                               content=f'{dict(Account.ORGANIZATIONS).get(account.organization, "신용카드")} 연동을 완료하였습니다.')
    except Exception as e:
        message = None
        errors = getattr(e, 'args', [])
        if errors and isinstance(errors, tuple):
            message = errors[0]

        if isinstance(message, dict):
            message = message.get('message')

        account.status = 'failed'
        account.message = message
        account.save(update_fields=['status', 'message'])

        Message.objects.create(trader=account.trader,
                               sender=ensure_mobiletax_user(),
                               type='notice',
                               title='연동 실패 안내',
                               content=f'{dict(Account.ORGANIZATIONS).get(account.organization, "신용카드")} 연동을 완료하였습니다. {message}')
        raise e


@app.task
def init_card_sales(card_sales_id):
    from accounting.models import CardSales, CardSalesApproval, Deposit, Message, ensure_mobiletax_user
    from accounting.codef import get_card_sales_approval_list, get_deposit_list

    card_sales = CardSales.objects.get(id=card_sales_id)
    if card_sales.status == 'in progress':
        return

    yesterday = (datetime.datetime.now() - relativedelta(days=1)).date()
    latest = card_sales.latest or datetime.date(1900, 1, 1)
    if latest >= yesterday:
        return

    card_sales.status = 'in progress'
    card_sales.message = None
    card_sales.save(update_fields=['status', 'message'])

    approvals = []
    deposits = []
    try:
        for i in range(12, -1, -1):
            end_date = min(yesterday - relativedelta(months=i) + relativedelta(day=31), yesterday)
            start_date = end_date.replace(day=1)
            start_date = max(start_date, latest)
            if start_date > end_date or end_date < latest:
                continue

            approvals.extend(get_card_sales_approval_list(card_sales, start_date, end_date))
            deposits.extend(get_deposit_list(card_sales, start_date, end_date))

        CardSalesApproval.objects.bulk_create(approvals)
        Deposit.objects.bulk_create(deposits)
        card_sales.latest = max(yesterday, latest)
        card_sales.status = 'successful'
        card_sales.save(update_fields=['latest', 'status'])

        Message.objects.create(trader=card_sales.trader,
                               sender=ensure_mobiletax_user(),
                               type='notice',
                               title='연동 완료 안내',
                               content='카드매출 연동이 완료되었습니다.')
    except Exception as e:
        message = None
        errors = getattr(e, 'args', [])
        if errors and isinstance(errors, tuple):
            message = errors[0]

        if isinstance(message, dict):
            dic = message
            message = dic.get('extraMessage') or dic.get('message')

        card_sales.status = 'failed'
        card_sales.message = message
        card_sales.save(update_fields=['status', 'message'])

        Message.objects.create(trader=card_sales.trader,
                               sender=ensure_mobiletax_user(),
                               type='notice',
                               title='연동 실패 안내',
                               content=f'카드매출 연동에 실패했습니다. {message}')
        raise e


@app.task
def init_business(trader_id):
    from accounting.models import Trader
    from accounting.codef import update_business_status

    trader = Trader.objects.get(id=trader_id)
    update_business_status(trader)


@app.task
def init_hometax(hometax_id):
    from accounting.models import Hometax, Check, Message, WithholdingTax, CashSalesReceipt, CashPurchaseReceipt, \
        ensure_mobiletax_user
    from accounting.codef import get_check_list, get_withholding_tax_report, update_business_status, \
        get_cash_sales_receipt, get_cash_purchase_receipt

    hometax = Hometax.objects.get(id=hometax_id)
    if hometax.status == 'in progress':
        return

    latest = hometax.latest or datetime.date(1900, 1, 1)
    yesterday = (datetime.datetime.now() - relativedelta(days=1)).date()
    if latest >= yesterday:
        return

    hometax.status = 'in progress'
    hometax.message = None
    hometax.save(update_fields=['status', 'message'])

    try:
        last_year = max(yesterday.replace(year=yesterday.year - 1) + relativedelta(days=1), latest)
        taxes = get_withholding_tax_report(hometax, last_year, yesterday)
        for tax in taxes:
            WithholdingTax.objects.update_or_create(hometax=hometax, issued=tax.issued, defaults={
                'personnel': tax.personnel,
                'amount': tax.amount,
            })

        checks = []
        for i in range(12, -1, -3):
            end_date = min(yesterday - relativedelta(months=i) + relativedelta(day=31), yesterday)
            start_date = (end_date - relativedelta(months=2)).replace(day=1)
            start_date = max(start_date, latest)
            if start_date > end_date or end_date < latest:
                continue

            checks.extend(get_check_list(hometax, start_date, end_date, transe_type='01', inquiry_type='01'))
            checks.extend(get_check_list(hometax, start_date, end_date, transe_type='01', inquiry_type='02'))
            checks.extend(get_check_list(hometax, start_date, end_date, transe_type='01', inquiry_type='03'))
            checks.extend(get_check_list(hometax, start_date, end_date, transe_type='01', inquiry_type='04'))
            checks.extend(get_check_list(hometax, start_date, end_date, transe_type='02', inquiry_type='01'))
            checks.extend(get_check_list(hometax, start_date, end_date, transe_type='02', inquiry_type='02'))
            checks.extend(get_check_list(hometax, start_date, end_date, transe_type='02', inquiry_type='03'))
            checks.extend(get_check_list(hometax, start_date, end_date, transe_type='02', inquiry_type='04'))

        Check.objects.bulk_create(checks)

        sales_receipts = get_cash_sales_receipt(hometax, last_year, yesterday)
        CashSalesReceipt.objects.bulk_create(sales_receipts)
        purchase_receipts = get_cash_purchase_receipt(hometax, last_year, yesterday)
        CashPurchaseReceipt.objects.bulk_create(purchase_receipts)

        hometax.latest = max(yesterday, latest)
        hometax.status = 'successful'
        hometax.message = None
        hometax.save(update_fields=['latest', 'status', 'message'])

        Message.objects.create(trader=hometax.trader,
                               sender=ensure_mobiletax_user(),
                               type='notice',
                               title='연동 완료 안내',
                               content='홈택스 연동을 완료하였습니다.')
    except Exception as e:
        message = None
        errors = getattr(e, 'args', [])
        if errors and isinstance(errors, tuple):
            message = errors[0]

        if isinstance(message, dict):
            dic = message
            message = dic.get('extraMessage') or dic.get('message')

        hometax.status = 'failed'
        hometax.message = message
        hometax.save(update_fields=['status', 'message'])

        Message.objects.create(trader=hometax.trader,
                               sender=ensure_mobiletax_user(),
                               type='notice',
                               title='연동 실패 안내',
                               content=f'홈택스 연동에 실패했습니다. {message}')
        raise e
