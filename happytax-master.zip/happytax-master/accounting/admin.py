from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.forms import UserChangeForm, UserCreationForm, ReadOnlyPasswordHashField
from django.utils.translation import ugettext_lazy as _

from accounting.models import User, Invoice, Trader, Voucher, Document, Tax, Attachment, Validation, \
    JournalEntry, Message, Post, Thumbnail, Employee, Salary, SalaryItem, CustomField, Device, Entity, Boilerplate, \
    Reader, Memo, Read, OneSignal, Report, ConnectedId, Account, Hometax, Card, MemberStore, CardSales, Deposit, \
    CardSalesApproval, Check, CardApproval, WithholdingTax, CashSalesReceipt, CashPurchaseReceipt

UserCreationForm.Meta.model = User


class CustomUserChangeForm(UserChangeForm):
    password = ReadOnlyPasswordHashField(label=_("Password"),
                                         help_text=_("비밀번호는 원문 그대로 저장되지 않으므로, 사용자의 비밀번호를 볼 수 있는 방법"
                                                     "은 없습니다, 하지만 <a href=\"../password/\">이 양식</a>을 사용하여 비밀번호를 "
                                                     "변경할 수 있습니다."))
    class Meta:
        model = User
        fields = UserChangeForm.Meta.fields


class CustomUserAdmin(UserAdmin):
    form = CustomUserChangeForm
    add_form = UserCreationForm

    fieldsets = (
        (None, {
            'fields': (
                'name',
                'registration_no',
                'phone',
                'current_trader',
                'is_validated',
                'beta',
            )
        }),
        ('매니저', {
            'fields': (
                'team',
                'is_team_leader',
                'for_new_client',
                'condition',
                'work_starting_time',
                'work_finishing_time',
                'out_of_office_message',
                'day_off_message',
                'slackid',
                'direct_number',
                'fax_number',
            )
        }),
        ('기본정보', {
            'fields': ()
        })
    ) + UserAdmin.fieldsets

    list_display = ('username', 'name', 'phone', 'email', 'is_staff', 'is_superuser', 'date_joined')
    search_fields = ('username', 'name', 'phone', 'email')
    raw_id_fields = ('current_trader',)


class DeviceAdmin(admin.ModelAdmin):
    list_display = ('user', 'user_agent',)
    raw_id_fields = ('user',)


class TraderAdmin(admin.ModelAdmin):
    raw_id_fields = ('user', 'accounting_manager',)


class VoucherAdmin(admin.ModelAdmin):
    list_display = ('trader', 'type',)
    raw_id_fields = ('trader', 'attachment',)


admin.site.register(User, CustomUserAdmin)
admin.site.register(Entity)
admin.site.register(Device, DeviceAdmin)
admin.site.register(Trader, TraderAdmin)
admin.site.register(Voucher, VoucherAdmin)


class DocumentAdmin(admin.ModelAdmin):
    list_display = ('trader', 'type', 'state', 'created', 'processed')
    search_fields = ('trader__business_name',)
    raw_id_fields = ('trader',)


admin.site.register(Document, DocumentAdmin)


class MemoAdmin(admin.ModelAdmin):
    raw_id_fields = ('trader',)


admin.site.register(Memo, MemoAdmin)


class InvoiceAdmin(admin.ModelAdmin):
    list_display = ('trader', 'invoice_type', 'supplier_name', 'consumer_name', 'value_of_supply', 'vat', 'total', 'issued', )
    list_display_links = ('invoice_type', 'supplier_name', 'consumer_name')
    list_filter = ('invoice_type',)
    raw_id_fields = ('trader',)


class JournalEntryAdmin(admin.ModelAdmin):
    list_display = ('trader', 'uid', 'issued', 'type', 'account_title', 'counterpart', 'description', 'amount')
    list_filter = ('type',)
    raw_id_fields = ('trader',)


admin.site.register(Invoice, InvoiceAdmin)
admin.site.register(JournalEntry, JournalEntryAdmin)
admin.site.register(Tax)


class AttachmentAdmin(admin.ModelAdmin):
    list_display = ('message_trader', 'message_sender', 'file', 'manager', 'created')
    raw_id_fields = ['message', 'manager']
    list_select_related = ['message', 'manager']

    def message_trader(self, obj):
        return obj.message.trader if obj.message else None

    def message_sender(self, obj):
        return obj.message.sender if obj.message else None


admin.site.register(Attachment, AttachmentAdmin)


class ThumbnailAdmin(admin.ModelAdmin):
    raw_id_fields = ('image',)


admin.site.register(Thumbnail, ThumbnailAdmin)
admin.site.register(Validation)


class MessageAdmin(admin.ModelAdmin):
    list_display = ('trader', 'sender', 'type', 'content', 'created')
    raw_id_fields = ('trader', 'sender',)


class ReadAdmin(admin.ModelAdmin):
    raw_id_fields = ('chat_room', 'user',)


class ReaderAdmin(admin.ModelAdmin):
    raw_id_fields = ('message', 'user',)


admin.site.register(Message, MessageAdmin)
admin.site.register(Read, ReadAdmin)
admin.site.register(Reader, ReaderAdmin)


class PostAdmin(admin.ModelAdmin):
    list_display = ('writer', 'title', 'type', 'created')
    list_filter = ('type', )


admin.site.register(Post, PostAdmin)
admin.site.register(Employee)
admin.site.register(Salary)
admin.site.register(CustomField)
admin.site.register(SalaryItem)


class BoilerplateAdmin(admin.ModelAdmin):
    raw_id_fields = ('parent', 'author',)


admin.site.register(Boilerplate, BoilerplateAdmin)


class OneSignalAdmin(admin.ModelAdmin):
    raw_id_fields = ('user',)


admin.site.register(OneSignal, OneSignalAdmin)


class ReportAdmin(admin.ModelAdmin):
    raw_id_fields = ('sender', 'traders',)
    exclude = ('raw',)
    readonly_fields = ('md5_hash',)


admin.site.register(Report, ReportAdmin)


class HometaxAdmin(admin.ModelAdmin):
    raw_id_fields = ('trader',)


admin.site.register(Hometax, HometaxAdmin)


class CardSalesAdmin(admin.ModelAdmin):
    raw_id_fields = ('trader',)


admin.site.register(CardSales, CardSalesAdmin)


class ConnectedIdAdmin(admin.ModelAdmin):
    raw_id_fields = ('trader',)


admin.site.register(ConnectedId, ConnectedIdAdmin)


class AccountAdmin(admin.ModelAdmin):
    raw_id_fields = ('trader',)


admin.site.register(Account, AccountAdmin)


class CardAdmin(admin.ModelAdmin):
    raw_id_fields = ('account',)


admin.site.register(Card, CardAdmin)
admin.site.register(MemberStore)


class CardApprovalAdmin(admin.ModelAdmin):
    raw_id_fields = ('card', 'member_store',)
    ordering = ('-used_date',)


admin.site.register(CardApproval, CardApprovalAdmin)


class CardSalesApprovalAdmin(admin.ModelAdmin):
    raw_id_fields = ('card_sales',)
    ordering = ('-used_date',)


admin.site.register(CardSalesApproval, CardSalesApprovalAdmin)


class DepositAdmin(admin.ModelAdmin):
    raw_id_fields = ('card_sales',)
    ordering = ('-deposit_date',)


admin.site.register(Deposit, DepositAdmin)


class CheckAdmin(admin.ModelAdmin):
    raw_id_fields = ('hometax',)
    ordering = ('-issue_date',)


admin.site.register(Check, CheckAdmin)


class WithholdingTaxAdmin(admin.ModelAdmin):
    raw_id_fields = ('hometax',)
    ordering = ('-issued',)


admin.site.register(WithholdingTax, WithholdingTaxAdmin)


class CashSalesReceiptAdmin(admin.ModelAdmin):
    raw_id_fields = ('hometax',)
    ordering = ('-used_date',)


admin.site.register(CashSalesReceipt, CashSalesReceiptAdmin)


class CashPurchaseReceiptAdmin(admin.ModelAdmin):
    raw_id_fields = ('hometax',)
    ordering = ('-used_date',)


admin.site.register(CashPurchaseReceipt, CashPurchaseReceiptAdmin)
