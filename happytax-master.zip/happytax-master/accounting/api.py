import json

import django_filters
from django.db.models.aggregates import Count, Sum
from django.db.models.query import Prefetch
from django.db.models import Q
from django.http import JsonResponse
from django.urls.base import reverse
from django.utils import timezone
from rest_framework import fields, serializers, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import BasePermission
from rest_framework.status import HTTP_403_FORBIDDEN

from accounting import tasks
from accounting.controllers.files import file_url
from accounting.fax import Fax
from accounting.models import User, Message, Attachment, Voucher, Trader, Invoice, Employee, Salary, JournalEntry, \
    Memo, Tax, CustomField, SalaryItem, AccountTitle
from accounting.ntsreport import format, withholding
from accounting.tax import 원천세
from django.shortcuts import get_object_or_404
from rest_framework.response import Response

from marketing.models import Acquisition

from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

analytics = None


class IsAdminUserOrOptions(BasePermission):

    def has_permission(self, request, view):
        return request.method == 'OPTIONS' or (request.user and request.user.is_staff)


class IsOwner(BasePermission):
    def has_permission(self, request, view):
        if request.user.is_staff:
            return True

        return str(getattr(request.user, view.lookup_field)) == view.kwargs.get(view.lookup_field)


class UserSerializer(serializers.ModelSerializer):
    client_set = serializers.PrimaryKeyRelatedField(many=True, read_only=True)

    class Meta:
        model = User
        exclude = ('password',)


class MemoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Memo
        fields = '__all__'


class TraderDetailSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    manager_set = UserSerializer(many=True, read_only=True)
    accounting_manager = UserSerializer(read_only=True)

    class Meta:
        model = Trader
        fields = '__all__'


class TraderSerializer(serializers.ModelSerializer):
    # unread_count = serializers.SerializerMethodField()
    memo_set = serializers.SerializerMethodField()

    # def get_unread_count(self, obj):
    #     if hasattr(obj, 'unread_message_set'):
    #         return len(obj.unread_message_set)

    #     return 0

    def get_memo_set(self, obj):
        if hasattr(obj, 'prefetched_memo_set'):
            return [MemoSerializer(memo).data for memo in obj.prefetched_memo_set]

        return []

    class Meta:
        model = Trader
        fields = '__all__'


class AttachmentForTaxSerializer(serializers.ModelSerializer):
    class Meta:
        model = Attachment
        fields = '__all__'


class TaxForTraderSerializer(serializers.ModelSerializer):
    attachments = AttachmentForTaxSerializer(many=True, read_only=True)
    pdf = serializers.SerializerMethodField()
    cost = serializers.SerializerMethodField()

    class Meta:
        model = Tax
        fields = '__all__'


class TaxReportSerializer(serializers.ModelSerializer):
    # TODO : use tax_engine
    output = serializers.SerializerMethodField()
    # 당월에 마감된 데이터
    reported = serializers.SerializerMethodField()
    # 직전 신고 데이터 예) 수정신고 1차의 경우, 정기신고데이터
    previous = serializers.SerializerMethodField()
    parsed = serializers.SerializerMethodField()
    # trader, period, type 이 같은 taxes 예) 정기신고, 수정신고 1차, 2차..
    siblings_id = serializers.SerializerMethodField()

    def get_output(self, obj):
        if obj.type == 'withholding-tax':
            return 원천세(obj).__dict__

    def get_reported(self, obj):
        if obj.type == 'withholding-tax':
            return json.loads(obj.info.get('reported')) if obj.info.get('reported') else None

    def get_previous(self, obj):
        if obj.type == 'withholding-tax':
            try:
                previous_tax = obj.get_previous_by_created(trader=obj.trader, period=obj.period, type=obj.type,
                                                           ready_to_report__isnull=False)
                return json.loads(previous_tax.info['reported'])
            except:
                pass

    def get_parsed(self, obj):
        if obj.type == 'withholding-tax':
            period_date = datetime.strptime(obj.period, '%Y-%m')
            submit_date = datetime.today()
            if period_date.month == submit_date.month:
                submit_date += relativedelta(months=1)

            report_args = {
                '귀속연월': obj.period,
                '지급연월': obj.period,
                '제출연월': submit_date.strftime('%Y%m'),
                '작성일자': submit_date.strftime('%Y%m10'),
            }
            report = withholding.generate_nts_report(obj, **report_args)
            return format.parse(withholding.get_descriptor(), report.splitlines())

    def get_siblings_id(self, obj):
        siblings = Tax.objects.filter(trader=obj.trader, period=obj.period, type=obj.type).order_by('created')
        return [tax.id for tax in siblings]

    class Meta:
        model = Tax
        fields = '__all__'


class TraderMonthlySummarySerializer(TraderSerializer):
    employee_count = serializers.IntegerField(read_only=True)
    salary_count = serializers.IntegerField(read_only=True)
    salary_journalentry_count = serializers.IntegerField(read_only=True)
    daily_worker_count = serializers.IntegerField(read_only=True)
    daily_worker_salary_count = serializers.IntegerField(read_only=True)
    tax_set = TaxForTraderSerializer(many=True, read_only=True)


class TradersViewSet(viewsets.ModelViewSet):
    serializer_class = TraderSerializer
    permission_classes = [IsAdminUserOrOptions]
    filter_fields = ('report_salary',)
    KEYWORDS = ['unread', 'memo', 'paid', 'trader[]']

    def get_queryset(self):
        traders = Trader.objects.order_by('business_name')

        # if 'unread' in self.request.query_params:
        #     traders = traders.prefetch_related(
        #         Prefetch('message_set',
        #                  queryset=Message.objects.exclude(readers=self.request.user),
        #                  to_attr='unread_message_set')
        #     )

        if 'memo' in self.request.query_params or 'memo' in self.request.data:
            traders = traders.prefetch_related(
                Prefetch('memo_set',
                         to_attr='prefetched_memo_set')
            )

        if self.request.query_params.get('manager'):
            traders = traders.filter(manager_set__id=self.request.query_params.get('manager'))

        if 'new' in self.request.query_params:
            traders = traders.filter(accounting_manager__isnull=True, created__gt=timezone.now() - timedelta(days=10))
        if 'activating' in self.request.query_params:
            traders = traders.filter(activation__in=['trying', 'in_review'])
        if 'activated' in self.request.query_params:
            traders = traders.filter(activation='activated')
        if 'paid' in self.request.query_params:
            traders = traders.filter(cms_activated__isnull=False)
        if 'mine' in self.request.query_params:
            traders = traders.filter(manager_set__in=[self.request.user])
        if 'search' in self.request.query_params:
            traders = traders.filter(Q(business_name__icontains=self.request.query_params.get('search'))
                                     | Q(registration_no__icontains=self.request.query_params.get('search'))
                                     | Q(user__name__icontains=self.request.query_params.get('search'))
                                     )

        if 'trader[]' in self.request.query_params:
            traders = traders.filter(id__in=self.request.query_params.getlist('trader[]'))

        if 'accounting_tool' in self.request.query_params:
            traders = traders.filter(accounting_tool=self.request.query_params.get('accounting_tool'))

        if 'order_by_created' in self.request.query_params:
            traders = traders.order_by('-created')

        return traders

    def get_serializer_class(self):
        if 'user_detail' in self.request.query_params:
            return TraderDetailSerializer
        return TraderSerializer

    def partial_update(self, request, *args, **kwargs):
        trader = Trader.objects.get(id=kwargs['pk'])
        for k in request.data:
            if k in self.KEYWORDS:
                continue

            if not hasattr(TraderSerializer, k):
                trader.memo_set.update_or_create(key=k, defaults={'value': request.data[k]})

        kwargs['partial'] = True
        return self.update(request, *args, **kwargs)

    @action(detail=True)
    def salaries_summary(self, request, pk=None):
        trader = get_object_or_404(self.get_queryset(), pk=pk)

        # use TruncMonth > django 1.10 : http://stackoverflow.com/questions/8746014/django-group-by-date-day-month-year
        from django.db import connection
        truncate_date = connection.ops.date_trunc_sql('month', 'month')
        summary_set = Salary.objects.filter(
            employee__trader=trader,
            month__year=request.query_params.get('year')
        ).extra({'month': truncate_date}).values('month', 'employee__type').annotate(
            Count('id'), Sum('base_pay'), Sum('income_tax'), Sum('rural_special_tax')
        ).order_by('month')

        summaries = [{
            '인원': int(x['id__count']),
            '기본급': int(x['base_pay__sum']),
            '소득세': int(x['income_tax__sum']),
            '농특세': int(x['rural_special_tax__sum']),
            '귀속연월': x['month'].strftime('%Y%m'),
            '소득종류': x['employee__type']} for x in summary_set]
        return Response(summaries)

    @action(detail=True)
    def tax_per_employee(self, request, pk=None):
        trader = get_object_or_404(self.get_queryset(), pk=pk)
        annotated = Salary.objects.filter(
            employee__trader=trader,
            month__year=request.query_params.get('year')
        ).values('employee').annotate(
            Sum('base_pay'), Sum('income_tax'), Sum('rural_special_tax')
        )

        taxes = []
        for tax in annotated:
            employee = Employee.objects.get(id=tax['employee'])
            taxes.append({
                'id': employee.id,
                '성명': employee.name,
                '주소득세': int(tax['income_tax__sum']),
                '주농특세': int(tax['rural_special_tax__sum']),
                '종소득세': employee.info.get('종(전)_소득세', 0),
                '종농특세': employee.info.get('종(전)_농특세', 0)
            })
        return Response(taxes)

    @action(methods=['get', 'post'], detail=True)
    def taxes(self, request, pk=None):
        if request.method == 'GET':
            tax_type = request.GET['type']
            meta_name = tax_type.replace('-', '_')
            period = request.GET['period']
        elif request.method == 'POST':
            tax_type = request.data['type']
            meta_name = tax_type.replace('-', '_')
            period = request.data['period']
        return Response(getattr(self, meta_name)(request, pk, tax_type, period))

    def withholding_tax(self, request, pk, tax_type, period):
        trader = get_object_or_404(self.get_queryset(), pk=pk)

        if request.method == 'POST':
            tax = trader.tax_set.create(type=tax_type, period=period)
            if request.data.get('신고구분상세코드'):
                tax.info['신고구분상세코드'] = request.data['신고구분상세코드']
                tax.save()

        if request.GET.get('id'):
            taxes = trader.tax_set.filter(id=request.GET['id'])
        else:
            taxes = trader.tax_set.filter(type=tax_type, period=period)
        return TaxReportSerializer(taxes.last()).data

    @action(methods=['post'], detail=True)
    def journalize_salary(self, request, pk):
        trader = get_object_or_404(self.get_queryset(), pk=pk)
        귀속연월 = datetime.strptime(request.data.get('귀속연월'), '%Y-%m').date()
        trader.journalize_salary(귀속연월)
        return Response()

    @action(methods=['get'], detail=False)
    def statistics(self, request, *args):
        all_queryset = Trader.objects.all()
        data = {
            'all': len(all_queryset),
            'new': len(
                all_queryset.filter(accounting_manager__isnull=True, created__gt=timezone.now() - timedelta(days=10))),
            'activating': len(all_queryset.filter(activation__in=['trying', 'in_review'])),
            'activated': len(all_queryset.filter(activation='activated')),
            'paid': len(all_queryset.filter(cms_activated__isnull=False).exclude(activation='test')),
            'mine': len(all_queryset.filter(manager_set__in=[request.user])),
        }
        return Response(data)


class AttachmentSerializer(serializers.ModelSerializer):
    file = serializers.SerializerMethodField('file_url')
    info = serializers.DictField()

    def file_url(self, obj):
        return file_url(obj)

    class Meta:
        model = Attachment
        fields = '__all__'


class AttachmentViewSet(viewsets.ModelViewSet):
    queryset = Attachment.objects.all()
    serializer_class = AttachmentSerializer
    permission_classes = [IsAdminUserOrOptions]

    @action(methods=['post'], detail=False)
    def faxes(self, request):
        resource_ids = request.data.get('ids', [])
        fax_numbers = request.data.get('fax_numbers', [])

        for i in range(len(resource_ids)):
            attachment = self.get_queryset().get(id=resource_ids[i])
            attachment.info['faxes'].append({
                'sent': timezone.now(),
                'fax_number': fax_numbers[i].replace('-', ''),
                'status': '요청',
            })
            attachment.save(update_fields=['info'])

            tasks.send_fax.delay(fax_numbers[i], '근로복지공단', resource_ids[i])

        serializer = self.get_serializer(self.get_queryset().filter(id__in=resource_ids), many=True)
        return Response(serializer.data)

    @action(methods=['post'], detail=False)
    def download(self, request):
        for resource_id in request.data.get('ids', []):
            attachment = Attachment.objects.get(id=resource_id)
            attachment.downloaded = True
            attachment.save(update_fields=['downloaded'])

        return Response({'result': 'OK'})

    @action(methods=['post'], detail=False)
    def print(self, request):
        for resource_id in request.data.get('ids', []):
            attachment = Attachment.objects.get(id=resource_id)
            attachment.printed = True
            attachment.save(update_fields=['printed'])

        return Response({'result': 'OK'})

    @action(methods=['post'], detail=False)
    def handle(self, request):
        for resource_id in request.data.get('ids', []):
            attachment = Attachment.objects.get(id=resource_id)
            attachment.handled = True
            attachment.save(update_fields=['handled'])

        return Response({'result': 'OK'})

    @action(methods=['post'], detail=True)
    def statuses(self, request, pk):
        attachment = self.get_queryset().get(pk=pk)
        for fax in attachment.info['faxes']:
            if fax['status'] == '요청':
                Fax.update_status(fax['receiptNum'], attachment.id)

        return Response()

    @action(methods=['get'], detail=False)
    def images(self, request):
        queryset = self.get_queryset().filter(message__trader=request.query_params['trader'],
                                              message__sender=request.query_params['sender'],
                                              mimetype__startswith='image').order_by('-created')
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


class VoucherSerializer(serializers.ModelSerializer):
    labels = serializers.SerializerMethodField()
    info = serializers.DictField()

    def get_labels(self, obj):
        return {k: v.label for k, v in Voucher.FORMS[obj.type].base_fields.items()}

    class Meta:
        model = Voucher
        fields = '__all__'


class ContentObjectField(serializers.RelatedField):

    def to_representation(self, value):
        if isinstance(value, Voucher):
            return VoucherSerializer(value).data
        elif isinstance(value, Attachment):
            return AttachmentSerializer(value).data

        raise Exception('unsupported content object')


class MessageSerializer(serializers.ModelSerializer):
    trader = TraderSerializer()
    sender = UserSerializer()
    type_display = serializers.CharField(source='get_type_display')
    attachment_set = AttachmentSerializer(many=True)
    content_object = ContentObjectField(read_only=True)
    created = serializers.SerializerMethodField()

    def get_created(self, obj):
        return timezone.localtime(obj.created).strftime('%m-%d %H:%M')

    class Meta:
        model = Message
        fields = '__all__'


class UsersViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = (IsOwner,)

    @action(methods=['get'], detail=False)
    def me(self, request):
        if not request.user.is_authenticated:
            return Response({
                'message': 'not authenticated',
                'redirect_url': reverse('admin:login')
            }, status=HTTP_403_FORBIDDEN)

        return Response(UserSerializer(request.user).data)

    def update(self, request, *args, **kwargs):
        response = super().update(request, *args, **kwargs)
        if response.status_code == 200 and response.data['for_new_client']:
            User.objects.filter(for_new_client=True).update(
                condition=response.data['condition'],
                work_starting_time=response.data['work_starting_time'],
                work_finishing_time=response.data['work_finishing_time'],
                out_of_office_message=response.data['out_of_office_message'],
                day_off_message=response.data['day_off_message']
            )

        return response

    @action(detail=True)
    def get_inbox_count(self, request, pk=None):
        user = get_object_or_404(self.queryset.all(), pk=pk)
        return Response(user.inbox_count())

    def get_queryset(self):
        queryset = super().get_queryset()
        if 'is_staff' in self.request.query_params:
            queryset = queryset.filter(is_staff=True)

        return queryset

    @action(methods=['post', 'delete'], detail=True)
    def client_set(self, request, pk):
        user = get_object_or_404(self.queryset.all(), pk=pk)
        if request.method == 'POST':
            user.client_set.add(Trader.objects.get(id=request.data['trader']))
        elif request.method == 'DELETE':
            user.client_set.remove(Trader.objects.get(id=request.data['trader']))
        return Response({
            'client_set': [client.id for client in user.client_set.all()]
        })


class ChoiceField(fields.Field):
    default_error_messages = fields.ChoiceField.default_error_messages

    def __init__(self, choices, **kwargs):
        super().__init__(**kwargs)

        self.representations = {}
        self.internal_values = {}
        for choice in choices:
            self.representations[choice[0]] = choice[1]
            self.internal_values[choice[1]] = choice[0]

    def to_internal_value(self, data):
        try:
            return self.internal_values[data]
        except KeyError:
            self.fail('invalid_choice', input=data)

    def to_representation(self, value):
        return self.representations.get(value, '')


class InvoiceSerializer(serializers.ModelSerializer):
    invoice_type = ChoiceField(Invoice.INVOICE_TYPES)
    voucher_type = ChoiceField(Invoice.VOUCHER_TYPES)

    class Meta:
        model = Invoice
        fields = '__all__'


class InvoicesViewSet(viewsets.ModelViewSet):
    queryset = Invoice.objects.select_related('upload').order_by('issued')
    serializer_class = InvoiceSerializer

    def get_queryset(self):
        queryset = super().get_queryset()

        trader_id = self.request.query_params.get('trader')
        if trader_id:
            trader = Trader.objects.get(id=trader_id)
            queryset = queryset.filter(trader=trader)

        period = self.request.GET.get('period')
        if period:
            vat, created = trader.tax_set.get_or_create(period=period,
                                                        type='vat-normal',
                                                        defaults={'amount': 0})

            queryset = queryset.filter(issued__range=vat.range())

        return queryset


class DateField(serializers.DateField):
    def to_internal_value(self, data):
        if data is not None and not data:
            return None

        return super().to_internal_value(data)


class EmployeeSerializer(serializers.ModelSerializer):
    quitted = DateField(required=False, allow_null=True)
    info = serializers.JSONField(default=dict)
    attachment_set = serializers.SerializerMethodField()

    class Meta:
        model = Employee
        fields = '__all__'

    def get_attachment_set(self, obj):
        if hasattr(obj, 'prefetched_attachment_set'):
            return [AttachmentSerializer(attachment).data for attachment in obj.prefetched_attachment_set]

        return []


class EmployeeViewSet(viewsets.ModelViewSet):
    queryset = Employee.objects
    serializer_class = EmployeeSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        queryset = queryset.prefetch_related(Prefetch('attachment_set', to_attr='prefetched_attachment_set'))

        if self.request.query_params.get('trader'):
            queryset = queryset.filter(trader__id=self.request.query_params.get('trader'))

        return queryset

    def filter_queryset(self, queryset):
        queryset = super(EmployeeViewSet, self).filter_queryset(queryset)
        return queryset.order_by('created')

    @action(methods=['post'], detail=False)
    def salaries_for_month(self, request):
        employees = self.queryset.filter(id__in=request.data['employees'])
        for employee in employees:
            try:
                payday = int(employee.payday)
            except (ValueError, TypeError) as err:
                payday = 1

            date = datetime.strptime('{}-{:02d}'.format(request.data['month'], payday), '%Y-%m-%d')
            employee.insert_salary_for_month(date)

        return Response()

    @action(methods=['get'], detail=False)
    def severance_pay(self, request):
        employees = self.get_queryset().filter(quitted__isnull=False)
        severance_pay = {}
        for employee in employees:
            severance_pay[employee.id] = {'name': employee.name, 'severance_pay': employee.severance_pay()}
        return JsonResponse(severance_pay)

    def destroy(self, request, *args, **kwargs):
        # TODO prevent delete if related salary exists
        return super().destroy(request, *args, **kwargs)


class SalaryItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = SalaryItem
        fields = '__all__'


class SalarySerializer(serializers.ModelSerializer):
    employee = EmployeeSerializer(read_only=True)
    employee_id = serializers.PrimaryKeyRelatedField(queryset=Employee.objects.all(), write_only=True)
    info = serializers.JSONField(default=dict)
    salaryitem_set = SalaryItemSerializer(many=True, read_only=True)

    class Meta:
        model = Salary
        fields = '__all__'

    def create(self, validated_data):
        validated_data['employee'] = validated_data.pop('employee_id')
        if not validated_data.get('base_pay'):
            validated_data['base_pay'] = validated_data['employee'].base_pay

        return super().create(validated_data)

    def update(self, instance, validated_data):
        if 'employee_id' in validated_data:
            validated_data['employee'] = validated_data['employee_id']

        return super().update(instance, validated_data)


class SalariesFilter(django_filters.rest_framework.FilterSet):
    year = django_filters.NumberFilter(name='month', lookup_expr='year')
    month = django_filters.NumberFilter(name='month', lookup_expr='month')

    class Meta:
        model = Salary
        fields = ['year', 'month']


class SalariesViewSet(viewsets.ModelViewSet):
    queryset = Salary.objects.select_related('employee').prefetch_related('salaryitem_set').order_by('month')
    serializer_class = SalarySerializer
    filter_class = SalariesFilter

    def get_queryset(self):

        queryset = super().get_queryset()

        if self.request.query_params.get('trader'):
            queryset = queryset.filter(employee__trader__id=self.request.query_params.get('trader'))

        return queryset

    def filter_queryset(self, queryset):
        queryset = super(SalariesViewSet, self).filter_queryset(queryset)
        return queryset.order_by('employee__created')

    @action(methods=['post'], detail=True)
    def update_salary_item(self, request, pk):
        salary = self.get_object()
        value = {'number_value': None, 'string_value': ''}

        if not request.data['value']:
            pass
        elif request.data['value'].isnumeric():
            value['number_value'] = request.data['value']
        else:
            value['string_value'] = request.data['value']

        salary.salaryitem_set.update_or_create(field=CustomField.objects.get(id=request.data['field']), defaults=value)

        return Response(SalarySerializer(self.get_object()).data)


class JournalEntrySerializer(serializers.ModelSerializer):
    class Meta:
        model = JournalEntry
        fields = '__all__'


class JournalEntryViewSet(viewsets.ModelViewSet):
    queryset = JournalEntry.objects.order_by('id')
    serializer_class = JournalEntrySerializer

    def get_queryset(self):
        queryset = super().get_queryset()

        if self.request.query_params.get('trader'):
            queryset = queryset.filter(trader__id=self.request.query_params.get('trader'))

        return queryset

    @action(methods=['get'], detail=False)
    def transactions(self, request):
        queryset = JournalEntry.objects.order_by('tid')
        self.page = self.paginate_queryset(queryset.distinct('tid'))
        return self.get_paginated_response([{
            'tid': e.tid,
            '차변': JournalEntrySerializer(queryset.filter(tid=e.tid, type='차변'), many=True).data,
            '대변': JournalEntrySerializer(queryset.filter(tid=e.tid, type='대변'), many=True).data
        } for e in self.page])


class AcquisitionGroupSerializer(serializers.ModelSerializer):
    user_count = serializers.IntegerField()

    class Meta:
        model = Acquisition
        fields = ['campaign', 'source', 'medium', 'content', 'user_count']


class CustomFieldSerializer(serializers.ModelSerializer):
    info = serializers.JSONField(default=dict)

    class Meta:
        model = CustomField
        fields = '__all__'


class CustomFieldViewSet(viewsets.ModelViewSet):
    queryset = CustomField.objects
    serializer_class = CustomFieldSerializer

    @action(methods=['get'], detail=False)
    def salary_schema(self, request):
        return Response(CustomField.SALARY_INFO_SCHEMA)

    def get_queryset(self):
        queryset = super().get_queryset().order_by('-category', '-name')
        if 'category' in self.request.query_params:
            queryset = queryset.filter(category=self.request.query_params['category'])

        return queryset


class AccountTitleSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccountTitle
        fields = '__all__'


class AccountTitleViewSet(viewsets.ModelViewSet):
    queryset = AccountTitle.objects.order_by('id')
    serializer_class = AccountTitleSerializer
