import base64
import datetime
import json
from urllib.parse import quote, unquote_plus

import requests
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
from constance import config
from django.conf import settings

from accounting.models import Hometax, ConnectedId, CardSales, Deposit, CardSalesApproval, Check, CardApproval, Card, \
    MemberStore, WithholdingTax, CashSalesReceipt, CashPurchaseReceipt

CODEF_TOKEN_ENDPOINT = 'https://oauth.codef.io/oauth/token'
CODEF_MAX_RETRY = 1

der = base64.b64decode(settings.CODEF_PUBLIC_KEY)
pub = RSA.importKey(der)
cipher = PKCS1_OAEP.new(pub)


def get_number(dic, key, default):
    raw = dic.get(key, '').strip()
    try:
        return int(dic.get(key, '').strip() or default)
    except ValueError:
        return default


def string_to_base64(s):
    return base64.b64encode(s.encode('utf-8'))


def base64_to_string(b):
    return base64.b64decode(b).decode('utf-8')


def encrypt(data):
    cipher_text = cipher.encrypt(data.encode())
    return base64.b64encode(cipher_text).decode('utf-8')


def request_token(force_refresh=False):
    token = config.CODEF_SANDBOX_ACCESS_TOKEN if settings.CODEF_SANDBOX else config.CODEF_ACCESS_TOKEN
    if token and not force_refresh:
        return token

    credentials = string_to_base64(f'{settings.CODEF_CLIENT_ID}:{settings.CODEF_CLIENT_SECRET}').decode('utf-8')
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': f'Basic {credentials}',
    }

    res = requests.post(CODEF_TOKEN_ENDPOINT, data='grant_type=client_credentials&scope=read', headers=headers)
    if res.status_code != 200:
        return None

    j = res.json()
    token = j.get('access_token', None)
    if not token:
        return None

    if settings.CODEF_SANDBOX:
        config.CODEF_SANDBOX_ACCESS_TOKEN = token
    else:
        config.CODEF_ACCESS_TOKEN = token

    return token


def login_to_hometax(login_type, username, password):
    get_total_check_list(login_type, username, password)


def login_to_card_sales(username, password):
    body = {
        'organization': CardSales.ORGANIZATION,
        'id': username,
        'password': encrypt(password),
    }
    data = post('/v1/kr/card/a/cardsales/registration-status', body)
    return bool(int(data.get('resRegistrationStatus', '0')))


def get_total_check_list(login_type, username, password, inquiry_type='01', transe_type='01', search_type='01', start_date=None, end_date=None, sort_by='1'):
    if not start_date:
        start_date = datetime.datetime.now().strftime('%Y%m%d')

        if search_type == '01' and not end_date:
            end_date = start_date
        elif search_type == '02':
            start_date = start_date[:-2]
        elif search_type in ('03', '04'):
            start_date = start_date[:-4]

    body = {
        'organization': Hometax.ORGANIZATION,
        'loginType': login_type,
        'id': username,
        'userPassword': encrypt(password),
        'inquiryType': inquiry_type,
        'transeType': transe_type,
        'searchType': search_type,
        'startDate': start_date,
        'endDate': end_date,
        'sortby': sort_by,
    }
    data = post('/v1/kr/public/nt/tax-invoice/total-check-list', body)
    return data.get('resTotalList', [])


def get_account_list(business_type, organization, client_type, login_type, username=None, password=None):
    account = {
        'countryCode': 'KR',
        'businessType': business_type,
        'organization': organization,
        'clientType': client_type,
        'loginType': login_type,
    }

    if id and password:
        account.update({
            'id': username,
            'password': encrypt(password),
        })

    return [account]


def get_connected_id():
    print(post('/v1/account/connectedId-list', {}))


def get_account(connected_id):
    body = {
        'connectedId': connected_id,
    }
    data = post('/v1/account/list', body)
    return data.get('accountList', [])


def create_account(business_type, organization, client_type, login_type, username, password):
    body = {
        'accountList': get_account_list(business_type, organization, client_type, login_type, username, password),
    }

    data = post('/v1/account/create', body)
    connected_id = data.get('connectedId', None)
    success_list = data.get('successList', [{}])
    account = success_list[0]
    return {
        'connected_id': connected_id,
        'business_type': account['businessType'],
        'organization': account['organization'],
        'client_type': account['clientType'],
        'login_type': account['loginType'],
    }


def add_account(connected_id, business_type, organization, client_type, login_type, username, password):
    body = {
        'connectedId': connected_id,
        'accountList': get_account_list(business_type, organization, client_type, login_type, username, password),
    }

    try:
        data = post('/v1/account/add', body)
    except Exception as e:
        if e.args[0]['code'] == 'CF-04019':
            ConnectedId.objects.filter(connected_id=connected_id).delete()
            return create_account(business_type, organization, client_type, login_type, username, password)

        raise e

    connected_id = data.get('connectedId', None)
    success_list = data.get('successList', [{}])
    account = success_list[0]
    return {
        'connected_id': connected_id,
        'business_type': account['businessType'],
        'organization': account['organization'],
        'client_type': account['clientType'],
        'login_type': account['loginType'],
    }


def delete_account(connected_id, business_type, organization, client_type, login_type):
    body = {
        'connectedId': connected_id,
        'accountList': get_account_list(business_type, organization, client_type, login_type),
    }
    post('/v1/account/delete', body)


def post(path, body, retry=0) -> dict:
    if retry > CODEF_MAX_RETRY:
        return {}

    token = request_token(bool(retry))

    url = f'{settings.CODEF_ENDPOINT}{path}'
    data = quote(json.dumps(body))
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {token}',
    }
    res = requests.post(url, data=data, headers=headers)
    if res.status_code == 401:
        return post(path, body, retry=retry+1)

    j = json.loads(unquote_plus(res.text))
    data = j.get('data', {})
    if isinstance(data, dict) and len(data.get('errorList', [])):
        raise Exception(data['errorList'][0])

    result = j.get('result', {})
    if result.get('code') != 'CF-00000':
        raise Exception(result)

    return data


def get_card_list(connected_id, organization):
    body = {
        'connectedId': connected_id,
        'organization': organization,
    }

    return post('/v1/kr/card/p/account/card-list', body=body)


def get_card_approval_list(account, start_date, end_date):
    connected_id = account.trader.connectedid_set.first()
    organization = account.organization
    body = {
        'connectedId': connected_id.connected_id,
        'organization': organization,
        'birthDate': '',
        'startDate': start_date.strftime('%Y%m%d'),
        'endDate': end_date.strftime('%Y%m%d'),
        'orderBy': '0',
        'inquiryType': '1',
        'memberStoreInfoType': '3',
    }

    data = post('/v1/kr/card/p/account/approval-list', body=body)
    if isinstance(data, dict):
        data = [data]

    approvals = []
    cards = {}
    for datum in data:
        used_date = datum.get('resUsedDate')
        used_time = datum.get('resUsedTime')
        card_name = datum.get('resCardName', '').strip()
        card_no = datum.get('resCardNo', '').strip()
        card_name = card_name or card_no
        if not used_date or not used_time or not card_name:
            continue

        used_date = datetime.datetime.strptime(f'{used_date} {used_time}', '%Y%m%d %H%M%S')
        card = cards.get(card_name)
        if not card:
            card, _ = Card.objects.get_or_create(account=account, name=card_name)

        used_amount = get_number(datum, 'resUsedAmount', 0)
        payment_type = datum.get('resPaymentType')
        installment_month = get_number(datum, 'resInstallmentMonth', 0)
        account_currency = datum.get('resAccountCurrency')
        approval_no = datum.get('resApprovalNo')
        try:
            payment_due_date = datetime.datetime.strptime(datum.get('resPaymentDueDate'), '%Y%m%d')
        except ValueError:
            payment_due_date = None
        home_foreign_type = datum.get('resHomeForeignType')
        cancel_yn = datum.get('resCancelYN')
        cancel_amount = get_number(datum, 'resCancelAmount', 0)
        vat = get_number(datum, 'resVAT', 0)
        cash_back = get_number(datum, 'resCashBack', 0)
        krw_amt = get_number(datum, 'resKRWAmt', 0)

        member_store_name = datum.get('resMemberStoreName')
        member_store_corp_no = datum.get('resMemberStoreCorpNo')
        member_store_type = datum.get('resMemberStoreType')
        member_store_tel_no = datum.get('resMemberStoreTelNo')
        member_store_addr = datum.get('resMemberStoreAddr')
        member_store = None

        if member_store_corp_no:
            member_store, _ = MemberStore.objects.get_or_create(corp_no=member_store_corp_no, defaults={
                'name': member_store_name,
                'type': member_store_type,
                'tel_no': member_store_tel_no,
                'addr': member_store_addr,
            })

        approvals.append(CardApproval(**{
            'card': card,
            'used_date': used_date,
            'card_no': card_no,
            'card_name': card_name,
            'used_amount': used_amount,
            'payment_type': payment_type,
            'installment_month': installment_month,
            'account_currency': account_currency,
            'approval_no': approval_no,
            'payment_due_date': payment_due_date,
            'home_foreign_type': home_foreign_type,
            'cancel_yn': cancel_yn,
            'cancel_amount': cancel_amount,
            'vat': vat,
            'cash_back': cash_back,
            'krw_amt': krw_amt,
            'member_store_name': member_store_name,
            'member_store': member_store,
        }))

    return approvals


def get_card_sales_approval_list(card_sales, start_date, end_date):
    body = {
        'organization': CardSales.ORGANIZATION,
        'id': card_sales.username,
        'password': card_sales.password,
        'startDate': start_date.strftime('%Y%m%d'),
        'endDate': end_date.strftime('%Y%m%d'),
    }

    data = post('/v1/kr/card/a/cardsales/approval-list', body=body)
    if isinstance(data, dict):
        data = [data]

    approvals = []
    for datum in data:
        used_date = datum.get('resUsedDate')
        used_time = datum.get('resUsedTime')
        if not used_date or not used_time:
            continue

        used_date = datetime.datetime.strptime(f'{used_date} {used_time}', '%Y%m%d %H%M%S')
        trans_type_nm = datum.get('TransTypeNm')
        card_no = datum.get('resCardNo')
        card_name = datum.get('resCardName')
        used_amount = int(datum.get('resUsedAmount', '').strip() or '0')
        installment_month = int(datum.get('resInstallmentMonth', '').strip() or '0')
        approval_no = datum.get('resApprovalNo')
        member_store_corp_no = datum.get('resMemberStoreCorpNo')
        comm_member_store_group = datum.get('commMemberStoreGroup')
        card_company = datum.get('resCardCompany')

        approvals.append(CardSalesApproval(**{
            'card_sales': card_sales,
            'used_date': used_date,
            'trans_type_nm': trans_type_nm,
            'card_no': card_no,
            'card_name': card_name,
            'used_amount': used_amount,
            'installment_month': installment_month,
            'approval_no': approval_no,
            'member_store_corp_no': member_store_corp_no,
            'comm_member_store_group': comm_member_store_group,
            'card_company': card_company,
        }))

    return approvals


def get_deposit_list(card_sales, start_date, end_date):
    body = {
        'organization': CardSales.ORGANIZATION,
        'id': card_sales.username,
        'password': card_sales.password,
        'startDate': start_date.strftime('%Y%m%d'),
        'endDate': end_date.strftime('%Y%m%d'),
    }

    data = post('/v1/kr/card/a/cardsales/deposit-list', body=body)
    if isinstance(data, dict):
        data = [data]

    deposits = []
    for datum in data:
        deposit_date = datum.get('resDepositDate')
        if not deposit_date:
            continue

        account_in = int(datum.get('resAccountIn', '').strip() or '0')
        comm_member_store_group = datum.get('commMemberStoreGroup')
        card_company = datum.get('resCardCompany')
        payment_account = datum.get('resPaymentAccount')
        bank_name = datum.get('resBankName')
        deposit_date = datetime.datetime.strptime(deposit_date, '%Y%m%d').date()
        sales_count = int(datum.get('resSalesCount', '').strip() or '0')
        sales_amount = int(datum.get('resSalesAmount', '').strip() or '0')
        suspense_amount = int(datum.get('resSuspenseAmount', '').strip() or '0')
        member_store_no = datum.get('resMemberStoreNo')
        other_deposit = int(datum.get('resOtherDeposit', '').strip() or '0')

        deposits.append(Deposit(**{
            'card_sales': card_sales,
            'account_in': account_in,
            'comm_member_store_group': comm_member_store_group,
            'card_company': card_company,
            'payment_account': payment_account,
            'bank_name': bank_name,
            'deposit_date': deposit_date,
            'sales_count': sales_count,
            'sales_amount': sales_amount,
            'suspense_amount': suspense_amount,
            'member_store_no': member_store_no,
            'other_deposit': other_deposit,
        }))

    return deposits


def get_check_list(hometax, start_date, end_date, transe_type='01', inquiry_type='01'):
    body = {
        'organization': Hometax.ORGANIZATION,
        'loginType': hometax.login_type,
        'id': hometax.username,
        'userPassword': hometax.password,
        'secureCardSkipYN': '1',
        'inquiryType': inquiry_type,
        'searchType': '01',
        'startDate': start_date.strftime('%Y%m%d'),
        'endDate': end_date.strftime('%Y%m%d'),
        'sortby': '1',
        'orderBy': '0',
        'transeType': transe_type,
        'identity': hometax.trader.registration_no.replace('-', ''),
    }

    data = post('/v1/kr/public/nt/tax-invoice/check-list', body=body)
    if isinstance(data, dict):
        data = [data]

    checks = []
    for datum in data:
        issue_date = datum.get('resIssueDate')
        if not issue_date:
            continue

        issue_nm = datum.get('resIssueNm', '')
        tax_amt = int(datum.get('resTaxAmt', '').strip() or '0')
        issue_date = datetime.datetime.strptime(issue_date, '%Y%m%d').date()
        approval_no = datum.get('resApprovalNo')
        supply_value = int(datum.get('resSupplyValue', '').strip() or '0')
        reporting_date = datum.get('resReportingDate', '').strip()
        reporting_date = datetime.datetime.strptime(reporting_date, '%Y%m%d').date() if reporting_date else None
        transfer_date = datum.get('resTransferDate', '').strip()
        transfer_date = datetime.datetime.strptime(transfer_date, '%Y%m%d').date() if transfer_date else None
        supplier_reg_number = datum.get('resSupplierRegNumber')
        supplier_establish_no = datum.get('resSupplierEstablishNo')
        supplier_company_name = datum.get('resSupplierCompanyName')
        supplier_name = datum.get('resSupplierName')
        contractor_reg_number = datum.get('resContractorRegNumber')
        contractor_establish_no = datum.get('resContractorEstablishNo')
        contractor_company_name = datum.get('resContractorCompanyName')
        contractor_name = datum.get('resContractorName')
        total_amount = int(datum.get('resTotalAmount', '').strip() or '0')
        e_tax_invoice_type = datum.get('resETaxInvoiceType')
        note = datum.get('resNote')
        receipt_or_charge = datum.get('resReceiptOrCharge')
        email = datum.get('resEmail')
        email1 = datum.get('resEmail1')
        email2 = datum.get('resEmail2')
        rep_items = datum.get('resRepItems')

        checks.append(Check(**{
            'hometax': hometax,
            'transe_type': transe_type,
            'inquiry_type': inquiry_type,
            'issue_nm': issue_nm,
            'tax_amt': tax_amt,
            'issue_date': issue_date,
            'approval_no': approval_no,
            'supply_value': supply_value,
            'reporting_date': reporting_date,
            'transfer_date': transfer_date,
            'supplier_reg_number': supplier_reg_number,
            'supplier_establish_no': supplier_establish_no,
            'supplier_company_name': supplier_company_name,
            'supplier_name': supplier_name,
            'contractor_reg_number': contractor_reg_number,
            'contractor_establish_no': contractor_establish_no,
            'contractor_company_name': contractor_company_name,
            'contractor_name': contractor_name,
            'total_amount': total_amount,
            'e_tax_invoice_type': e_tax_invoice_type,
            'note': note,
            'receipt_or_charge': receipt_or_charge,
            'email': email,
            'email1': email1,
            'email2': email2,
            'rep_items': rep_items,
        }))

    return checks


def update_business_status(trader):
    body = {
        'organization': '0004',
        'reqIdentityList': [{'reqIdentity': trader.registration_no}],
    }
    data = post('/v1/kr/public/nt/business/status', body)
    if not isinstance(data, list) or not len(data):
        return

    status = data[0]
    taxation_type_code = status.get('resTaxationTypeCode')
    if not taxation_type_code:
        return

    if taxation_type_code == '1':
        trader.is_corporation = False
        trader.taxation = 'normal'
        trader.save(update_fields=['is_corporation', 'taxation'])
    elif taxation_type_code == '2':
        trader.is_corporation = False
        trader.taxation = 'simplified'
        trader.save(update_fields=['is_corporation', 'taxation'])
    elif taxation_type_code == '90':
        trader.is_corporation = True
        trader.taxation = 'normal'
        trader.save(update_fields=['is_corporation', 'taxation'])


def get_withholding_tax_report(hometax, start_date, end_date, inquiry_type='0'):
    body = {
        'organization': '0005',
        'loginType': hometax.login_type,
        'id': hometax.username,
        'userPassword': hometax.password,
        'startDate': start_date.strftime('%Y%m%d'),
        'endDate': end_date.strftime('%Y%m%d'),
        'identity': hometax.trader.registration_no,
        'inquiryType': inquiry_type,
    }

    data = post('/v1/kr/public/nt/report/withholding-tax', body=body)
    if isinstance(data, dict):
        data = [data]

    taxes = []
    for datum in data:
        issued = datum.get('resYearMonth')
        if not issued:
            continue

        issued = datetime.datetime.strptime(issued, '%Y%m').date()
        spec_list = datum.get('resTaxAmtSpecList', [])
        spec = next((s for s in spec_list if s.get('resCodeNo') == 'A99'), None)
        if not spec:
            continue

        personnel = int(spec.get('resPersonnel', '').strip() or '0')
        amount = int(spec.get('resTotalPaymentAmt', '').strip() or '0')

        taxes.append(WithholdingTax(**{
            'hometax': hometax,
            'issued': issued,
            'personnel': personnel,
            'amount': amount,
        }))

    return taxes


def get_cash_sales_receipt(hometax, start_date, end_date):
    body = {
        'organization': '0003',
        'loginType': hometax.login_type,
        'id': hometax.username,
        'userPassword': hometax.password,
        'identity': hometax.trader.registration_no,
        'startDate': start_date.strftime('%Y%m%d'),
        'endDate': end_date.strftime('%Y%m%d'),
        'orderBy': '0',
    }

    data = post('/v1/kr/public/nt/cash-receipt/sales-details', body=body)
    if isinstance(data, dict):
        data = [data]

    receipts = []
    for datum in data:
        used_date = datum.get('resUsedDate')
        used_time = datum.get('resUsedTime')
        if not used_date or not used_time:
            continue

        used_date = datetime.datetime.strptime(f'{used_date} {used_time}', '%Y%m%d %H%M%S')
        trans_type_nm = datum.get('resTransTypeNm')
        issue_type = datum.get('resIssueType')
        approval_no = datum.get('resApprovalNo')
        supply_value = int(datum.get('resSupplyValue', '').strip() or '0')
        vat = int(datum.get('resVAT', '').strip() or '0')
        tip = int(datum.get('resTip', '').strip() or '0')
        id_means = datum.get('resIDMeans')
        total_amount = int(datum.get('resTotalAmount', '').strip() or '0')
        company_identity_no = datum.get('resCompanyIdentityNo')
        company_nm = datum.get('resCompanyNm')

        receipts.append(CashSalesReceipt(**{
            'hometax': hometax,
            'used_date': used_date,
            'trans_type_nm': trans_type_nm,
            'issue_type': issue_type,
            'approval_no': approval_no,
            'supply_value': supply_value,
            'vat': vat,
            'tip': tip,
            'id_means': id_means,
            'total_amount': total_amount,
            'company_identity_no': company_identity_no,
            'company_nm': company_nm,
        }))

    return receipts


def get_cash_purchase_receipt(hometax, start_date, end_date):
    body = {
        'organization': '0003',
        'loginType': hometax.login_type,
        'id': hometax.username,
        'userPassword': hometax.password,
        'identity': hometax.trader.registration_no,
        'startDate': start_date.strftime('%Y%m%d'),
        'endDate': end_date.strftime('%Y%m%d'),
        'orderBy': '0',
        'inquiryType': '0',
    }

    data = post('/v1/kr/public/nt/cash-receipt/purchase-details', body=body)
    if isinstance(data, dict):
        data = [data]

    receipts = []
    for datum in data:
        used_date = datum.get('resUsedDate')
        used_time = datum.get('resUsedTime')
        if not used_date or not used_time:
            continue

        used_date = datetime.datetime.strptime(f'{used_date} {used_time}', '%Y%m%d %H%M%S')
        user_nm = datum.get('resUserNm')
        company_nm = datum.get('resCompanyNm')
        company_identity_no = datum.get('resCompanyIdentityNo')
        trans_type_nm = datum.get('resTransTypeNm')
        deduct_description = datum.get('resDeductDescription')
        member_store_name = datum.get('resMemberStoreName')
        member_store_corp_no = datum.get('resMemberStoreCorpNo')
        approval_no = datum.get('resApprovalNo')
        supply_value = int(datum.get('resSupplyValue', '').strip() or '0')
        vat = int(datum.get('resVAT', '').strip() or '0')
        tip = int(datum.get('resTip', '').strip() or '0')
        id_means = datum.get('resIDMeans')
        total_amount = int(datum.get('resTotalAmount', '').strip() or '0')

        receipts.append(CashPurchaseReceipt(**{
            'hometax': hometax,
            'used_date': used_date,
            'user_nm': user_nm,
            'company_nm': company_nm,
            'company_identity_no': company_identity_no,
            'trans_type_nm': trans_type_nm,
            'deduct_description': deduct_description,
            'member_store_name': member_store_name,
            'member_store_corp_no': member_store_corp_no,
            'approval_no': approval_no,
            'supply_value': supply_value,
            'vat': vat,
            'tip': tip,
            'id_means': id_means,
            'total_amount': total_amount,
        }))

    return receipts
