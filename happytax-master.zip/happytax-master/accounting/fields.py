from accounting.widgets import MonthInput
from django.forms.fields import DateField
import datetime


class MonthField(DateField):
    widget = MonthInput

    def to_python(self, value):
        try:
            value = datetime.datetime.strptime(value, '%Y-%m')
        except ValueError:
            return None

        # 32일을 더해 익월의 첫째 날을 구한 후 하루를 빼서 입력된 달이 몇 월이든 상관없이 마지막 날을 구한다.
        value += datetime.timedelta(days=32)
        value = value.replace(day=1)
        value -= datetime.timedelta(days=1)

        return super(MonthField, self).to_python(value.strftime('%Y-%m-%d'))