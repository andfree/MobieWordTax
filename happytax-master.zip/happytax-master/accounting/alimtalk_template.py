from urllib.parse import quote_plus


class AlimtalkTemplate:

    DEEP_LINK_FORMAT = 'https://q2849.app.goo.gl/?link={}&apn=kr.mobiletax&amv=29&ibi=kr.mobiletax.mobiletax&isi=1040046595&imv=1.0.11&'
    TEMPLATES = {
        'API0001': {
            'subject': '[회원가입 완료 안내]',
            'msg_format': '''{user_name}님, 모바일택스 회원가입을 진심으로 축하드립니다!
- 가입 ID : {user_id}
정식 서비스 신청을 하시면 1:1로 전담 세무전문가가 배정됩니다.
장부작성을 기반으로 각종 세금신고, 인건비, 4대 보험, 절세 컨설팅까지 모든 세무를 손쉽게 해결해드립니다.
기타 서비스와 관련해서 더 궁금한 사항이 있으시면 무료 상담을 신청해주세요!''',
            'btn_types': '웹링크',
            'btn_txts': '모바일택스 바로가기',
            'btn_urls1': 'https://mobiletax.kr/accounts/welcome?from=alimtalk',
            'btn_urls2': '',
            'failed_type': 'LMS',
        },

        'API0002': {
            'subject': '[상담신청 완료 안내]',
            'msg_format': '''{user_name}님, {trader_name}에 대한 상담신청이 완료되었습니다.
- 상담요청시간 : {counsel_time}
정확한 상담시간은 카카오 알림톡을 통해 다시 안내드릴게요!''',
            'btn_types': '웹링크',
            'btn_txts': '모바일택스 바로가기',
            'btn_urls1': 'https://mobiletax.kr/counsel/apply_complete?from=alimtalk',
            'btn_urls2': '',
            'failed_type': 'LMS',
        },

        'API0003': {
            'subject': '[상담시간 안내]',
            'msg_format': '''{user_name}님, {trader_name}에 대한 상담전화를 {counseler}가 {counsel_time}에 드릴 예정입니다.
- 상담 시간 : {counsel_time}
- 상담 {counseler_position} : {counseler_name}
상담시간을 바꾸고 싶으실 경우에는 모바일택스 상담창에서 시간변경을 요청해주세요.''',
            'btn_types': '웹링크',
            'btn_txts': '모바일택스 상담창 바로가기',
            'btn_urls1': 'https://mobiletax.kr/messages?from=alimtalk',
            'btn_urls2': '',
            'failed_type': 'LMS',
        },

        'API0004': {
            'subject': '[정식 서비스 신청 안내]',
            'msg_format': '''{user_name}님, {trader_name}에 대한 전화 상담은 만족스러우셨나요?
전화 상담에서 말씀드린바와 같이 정식 서비스를 신청하시면, 더이상 세무에 일일이 신경쓸 필요가 없습니다.
- 1:1 세무전문가 배정, 매 월 회계장부 작성관리를 알아서!
- 부가세, 종합소득세(법인세), 4대보험, 인건비 등 각종 세무신고 업무를 알아서!
- 세액공제와 비용처리로 절세까지 알아서!
전국 5,000명이 넘는 사업자분들이 인정한 세무서비스! 이제 매출에만 집중하세요.
*서비스 과금은 최종 홈택스 세무대리인 수임동의 후에 진행됩니다.''',
            'btn_types': '웹링크',
            'btn_txts': '정식 서비스 신청하기',
            'btn_urls1': 'https://mobiletax.kr/fullsvc/intro?from=alimtalk',
            'btn_urls2': '',
            'failed_type': 'LMS',
        },

        'API0005': {
            'subject': '[정식 서비스 신청완료 안내]',
            'msg_format': '''{user_name}님, {trader_name}에 대한 정식 서비스 신청을 해주셔서 감사합니다.
올려주신 서류검토가 완료되면 초기세팅 상담이 진행됩니다. 이후, 본격적인 세무업무가 시작됩니다!
초기세팅 상담내용은 아래와 같습니다.
- 회계장부 작성을 위해 해당 상호의 사업내용 상세파악
- 홈택스 세무대리인 수임동의
초기세팅 상담은 30분 정도 소요되며, 정식 서비스 신청일로부터 영업일 기준 1일 이내에 전화를 통해 진행됩니다.
향후 사장님의 절세를 위해 반드시 필요한 과정이므로, 잠시 시간 내주시면 감사하겠습니다 :)''',
            'btn_types': '웹링크',
            'btn_txts': '모바일택스 바로가기',
            'btn_urls1': 'https://mobiletax.kr/fullsvc/thanks?from=alimtalk',
            'btn_urls2': '',
            'failed_type': 'LMS',
        },

        'API0006': {
            'subject': '[드디어, 정식 서비스가 시작되었습니다]',
            'msg_format': '''{user_name}님, {trader_name}에 대한 담당 매니저가 배정되었습니다.
- 담당 매니저 이름 : {mng_name}
- 담당 매니저 직통번호 : {mng_phone} (저장해주세요.)
아래 링크를 통해 담당 매니저를 확인하시고, 본격적인 서비스 이용 전에 반드시 알아야할 사항을 체크해주세요!''',
            'btn_types': '웹링크',
            'btn_txts': '담당 매니저 확인하기',
            'btn_urls1': 'https://mobiletax.kr/fullsvc/mymanager?from=alimtalk',
            'btn_urls2': '',
            'failed_type': 'LMS',
        },

        'APIV101': {
            'subject': '[모바일택스 이용을 위한 유선상담 안내]',
            'msg_format': '''{user_name}님, 다음 정보를 <모바일택스 상담창>에 남겨주세요.
①연락 가능 시간
②연락처

정식 서비스 이용을 위해 전문가 상담이 진행될 예정입니다. 보다 꼼꼼한 상담을 위해 30분정도 소요됩니다.

감사합니다.

*본 메시지는 정식 서비스 이용 신청을 위한 모든 자료 업로드 및 약관동의를 해주신 고객분들에게만 전달되는 메시지입니다. 알림용으로 전달되었으며, 본 카카오톡 프로필은 채팅이 불가합니다.

*모바일택스 앱을 설치하시면 상담창에 대한 알림을 받아보실 수 있습니다.''',
            'btn_types': '웹링크',
            'btn_txts': '모바일택스 상담창 바로가기',
            'btn_urls1': 'https://mobiletax.kr/messages?from=alimtalk',
            'btn_urls2': '',
            'failed_type': 'LMS',
            'failed_msg_format': '''{user_name}님, 다음 정보를 <모바일택스 상담창>에 남겨주세요.
①연락 가능 시간
②연락처

[모바일택스 상담창 바로가기]
https://mobiletax.kr/messages

정식 서비스 이용을 위해 전문가 상담이 진행될 예정입니다. 보다 꼼꼼한 상담을 위해 30분정도 소요됩니다.

감사합니다.

*본 메시지는 정식 서비스 이용 신청을 위한 모든 자료 업로드 및 약관동의를 해주신 고객분들에게만 전달되는 메시지입니다.

*모바일택스 앱을 설치하시면 상담창에 대한 알림을 받아보실 수 있습니다.
앱 설치하기 : https://bit.ly/2zuiUHP''',
        }
    }


    @classmethod
    def generate_params(cls, sender, receiver, template_code, replace_msg):
        template = cls.TEMPLATES[template_code]

        alimtalk_msg = cls.parse_alimtalk_msg(template, replace_msg)
        failed_msg = cls.parse_failed_msg(template, replace_msg) if template['failed_type'] != 'N' else ''

        return {
            'template_code': template_code,
            'callback': sender.replace('-', ''),
            'phone': receiver.replace('-', ''),
            'msg': alimtalk_msg,
            'failed_msg': failed_msg,
            'failed_type': template['failed_type'],
            'failed_subject': template['subject'],
            'btn_types': template['btn_types'],
            'btn_txts': template['btn_txts'],
            'btn_urls1': cls.generate_deep_link(template['btn_urls1']) if template['btn_urls1'] != '' else '',
            'btn_urls2': cls.generate_deep_link(template['btn_urls2']) if template['btn_urls2'] != '' else '',
        }


    @classmethod
    def generate_deep_link(cls, link):
        return cls.DEEP_LINK_FORMAT.format(quote_plus(link))


    # 알림톡 메시지
    @classmethod
    def parse_alimtalk_msg(cls, template, replace_msg):
        alimtalk_format = '{subject}\r\n\r\n{msg_body}'

        subject = template['subject']
        msg_body = cls.parse_msg_body(template['msg_format'], replace_msg)

        return alimtalk_format.format(subject=subject, msg_body=msg_body)


    # 알림톡 전송실패 시, 전송할 문자 message
    @classmethod
    def parse_failed_msg(cls, template, replace_msg):
        if template.get('failed_msg_format', -1) != -1:
            return template['failed_msg_format'].format(**replace_msg)
        else:
            failed_msg_format = '{msg_body}\r\n\r\n*{btn_txts}\r\n{btn_urls1}'

            msg_body = cls.parse_msg_body(template['msg_format'], replace_msg)
            btn_txts = template['btn_txts']
            btn_urls1 = cls.generate_deep_link(template['btn_urls1']) if template['btn_urls1'] != '' else ''

            return failed_msg_format.format(msg_body=msg_body, btn_txts=btn_txts, btn_urls1=btn_urls1)


    # alimtalk or sms message's body
    @classmethod
    def parse_msg_body(cls, msg_format, replace_msg):
        return msg_format.format(**replace_msg)
