import datetime
import hashlib
import json
import logging
import mimetypes
import uuid
import time
from calendar import monthrange
from datetime import timedelta
from decimal import Decimal

import annoying.fields
import six
from PIL import Image
from dateutil.relativedelta import relativedelta
from django.conf import settings
from django.contrib.auth.models import AbstractUser, Group
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
from django.core.mail import send_mail
from django.core.serializers.json import DjangoJSONEncoder
from django.db import models, transaction
from django.db.models.aggregates import Sum, Min
from django.db.models.functions import Coalesce
from django.db.models.query_utils import Q
from django.db.models.signals import post_save, post_delete
from django.dispatch.dispatcher import receiver
from django.forms import fields
from django.forms.forms import Form
from django.utils import timezone
from django.utils.html import strip_tags
from django_extensions.db.fields.json import JSONField
from djangox.mako import template_lookup
from mako.template import Template

from accounting import tasks
from accounting.fields import MonthField
from accounting.tasks import send_unread_message_notification_to_managers, init_account, init_card_sales, init_hometax, \
    init_business
from accounting.tax import 부가가치세, 원천세

# fix for django-extensions JSONField bug
from accounting.util import floor


def jsonfield_fixed_get_db_prep_save(self, value, connection, **kwargs):
    """Convert our JSON object to a string before we save"""
    if value is None and self.null:
        return None
    # default values come in as strings; only non-strings should be
    # run through `dumps`
    if not isinstance(value, six.string_types):
        value = json.dumps(value, cls=DjangoJSONEncoder)
    return value


JSONField.get_db_prep_save = jsonfield_fixed_get_db_prep_save


class User(AbstractUser):
    # TODO: after removing duplicate emails, migrate below
    # email = models.EmailField(max_length=100, unique=True)

    name = models.CharField(max_length=100, blank=True)
    registration_no = models.CharField(max_length=100, blank=True)
    phone = models.CharField(max_length=100, blank=True)
    current_trader = models.OneToOneField('Trader', related_name='current_user', null=True, blank=True, on_delete=models.SET_NULL)
    gcmkey = models.CharField(max_length=1000, null=True, blank=True)
    apnskey = models.CharField(max_length=1000, null=True, blank=True)
    is_validated = models.BooleanField(default=False)
    beta = models.BooleanField(default=False)

    '''
    For managers only.
    '''
    team = models.CharField(max_length=30, null=True, blank=True, verbose_name='팀명')
    is_team_leader = models.BooleanField(default=False, verbose_name='팀장')
    for_new_client = models.BooleanField(default=False, verbose_name='신규상담')
    condition = models.CharField(max_length=30, default='부재중 메시지 사용하지 않음', verbose_name='상태')
    work_starting_time = models.PositiveSmallIntegerField(default=10, verbose_name='근무 시작 시간')
    work_finishing_time = models.PositiveSmallIntegerField(default=17, verbose_name='근무 종료 시간')
    out_of_office_message = models.TextField(default='', null=True, blank=True, verbose_name='근무 외 시간 메시지')
    day_off_message = models.TextField(default='', null=True, blank=True, verbose_name='휴가 메시지')
    client_set = models.ManyToManyField('Trader', related_name='manager_set')
    slackid = models.CharField(max_length=100, null=True, blank=True, verbose_name='슬랙계정')
    direct_number = models.CharField(max_length=100, null=True, blank=True, verbose_name='직통번호')
    fax_number = models.CharField(max_length=100, null=True, blank=True, verbose_name='팩스번호')

    class Meta:
        ordering = ('name',)

    def save(self, *args, **kwargs):
        self.phone = self.phone.replace('-', '')
        super().save(*args, **kwargs)

    def inbox_count(self):
        return Message.objects.filter(trader__user=self, sender__is_staff=True).exclude(readers__in=[self]).count()

    def __str__(self):
        return self.name


User._meta.get_field("username").max_length = 200
User._meta.get_field("username")._validators = []


def ensure_deleted_user():
    if User.objects.filter(username='deleted_user').exists():
        return User.objects.get(username='deleted_user')

    return User.objects.create_superuser(username='deleted_user', email=None, password=None, name='삭제된 사용자')


def ensure_mobiletax_user():
    if User.objects.filter(username='mobiletax').exists():
        return User.objects.get(username='mobiletax')

    return User.objects.create_superuser(username='mobiletax', email=None, password=None, name='모바일택스')


class Entity(models.Model):
    platform = models.TextField()
    ip_address = models.GenericIPAddressField()
    utm = annoying.fields.JSONField(default=dict)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = 'Entities'

    def __str__(self):
        return '{} {}'.format(self.ip_address, self.platform)


class Device(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    user_agent = models.TextField()
    login_ip_address = models.GenericIPAddressField(null=True, blank=True)
    push_token = models.CharField(max_length=1000, null=True, blank=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return '{}: {}'.format(self.user, self.user_agent)


class Trader(models.Model):
    dict(activated='success', trying='warning', in_review='danger', require_information='muted', requested_to_delete='muted', require_payment='결제필요')
    ACTIVATION_STATUSES = [
        ('require_information', '비활성', 'muted'),
        ('trying', '활성화 시도중', 'warning'),
        ('in_review', '매니저 검토중', 'danger'),
        ('activated', '활성화됨', 'success'),
        ('require_payment', '결제 안됨', 'muted'),
        ('requested_to_delete', '삭제요청됨', 'danger'),
        ('test', '테스트 계정', 'muted'),
    ]

    BUSINESS_CONDITIONS = [
        ('', ''),
        ('폐업', '폐업'),
    ]

    TAXATIONS = [
        ('normal', '일반과세자'),
        ('simplified', '간이과세자'),
        ('tax-free', '면세사업자'),
    ]

    ACCOUNTING_TOOLS = [
        ('duzon', '더존'),
        ('mobiletax', '모바일택스')
    ]

    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET(ensure_deleted_user))
    registration_no = models.CharField(max_length=100, blank=True, unique=True, verbose_name='사업자번호')
    business_name = models.CharField(max_length=200, blank=True, verbose_name='상호')
    business_type = models.CharField(max_length=100, blank=True)
    business_condition = models.CharField(max_length=100, blank=True, choices=BUSINESS_CONDITIONS, verbose_name='폐업')
    is_corporation = models.BooleanField(default=False, verbose_name='법인여부')
    is_restaurant = models.BooleanField(default=False, verbose_name='음식점')
    taxation = models.CharField(max_length=100, choices=TAXATIONS, default='normal', verbose_name='과세종류')
    other_vat_sales = models.IntegerField(default=0)
    other_vat_purchase = models.IntegerField(default=0)
    other_income_sales = models.IntegerField(default=0)
    other_income_purchase = models.IntegerField(default=0)
    other_income = models.IntegerField(default=0)
    activation = models.CharField(max_length=100, default='require_information', choices=[(e[0], e[1]) for e in ACTIVATION_STATUSES], verbose_name='활성화')
    monthly_price = models.DecimalField(max_digits=20, decimal_places=0, default=Decimal('0'), blank=True, verbose_name='월 이용료')
    last_received = models.DateTimeField(null=True, blank=True, verbose_name='최근 받은 알림 메시지')
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    report_salary = models.BooleanField(default=False, verbose_name='인건비 신고 필요')
    cms_activated = models.DateTimeField(null=True, blank=True, verbose_name='CMS 등록일')
    payment_started = models.DateTimeField(null=True, blank=True, verbose_name='결제시작일')
    accounting_manager = models.ForeignKey(User,
                                           related_name='accounting_client_set',
                                           null=True,
                                           blank=True,
                                           verbose_name='기장총괄',
                                           on_delete=models.SET_NULL)
    accounting_tool = models.CharField(max_length=100, choices=ACCOUNTING_TOOLS, default='duzon')
    info = JSONField(default={}, blank=True)
    unread_counts = JSONField(default=dict, blank=True)

    def __str__(self):
        return self.business_name

    @property
    def business_registration_documents(self):
        return self.document_set.filter(type='사업자등록증')

    @property
    def property_contract_documents(self):
        return self.document_set.filter(type='임대차계약서')

    @property
    def backbook_documents(self):
        return self.document_set.filter(type='통장사본')

    def get_activation_display_for_user(self):
        labels = {
            'require_information': '정식서비스 신청전',
            'trying': '정보등록중',
            'in_review': '담당자 검토중',
            'activated': '이용중',
        }
        return labels.get(self.activation, '확인중')

    def tax_periods(self):
        this_year = datetime.date.today().year
        begin_year = int((Tax.objects.aggregate(Min('period'))['period__min'] or str(this_year))[:4])

        if self.taxation in ['simplified', 'tax-free']:
            return ['%s' % (year) for year in range(begin_year, this_year + 1)]
        elif self.is_corporation:
            return ['%s-%dQ' % (year, quarter) for year in range(begin_year, this_year + 1) for quarter in range(1, 5)]
        else:
            return ['%s-%dH' % (year, half) for year in range(begin_year, this_year + 1) for half in range(1, 3)]

    def period_of_date(self, dt):
        if self.taxation in ['simplified', 'tax-free']:
            return str(dt.year)
        else:
            for p, r in VAT_PERIOD_RANGE.items():
                if self.is_corporation and p.endswith('H'):
                    continue
                if not self.is_corporation and p.endswith('Q'):
                    continue

                if r[0][0] <= dt.month <= r[1][0]:
                    return '%d-%s' % (dt.year, p)

            logging.error('Wrong taxation: %s %s %s', self.is_corporation, self.taxation, dt)
            return str(dt.year)

    def tax_years(self):
        this_year = datetime.date.today().year
        for year in [this_year, this_year - 1]:
            if not self.tax_set.filter(period=year, type='income-tax').exists():
                self.tax_set.create(period=year, type='income-tax', amount=0)

        return [tax.period for tax in self.tax_set.filter(type='income-tax').order_by('-period')]

    def next_vat_report_period(self, date=None):
        date = date or datetime.date.today()

        if self.taxation in ['simplified', 'tax-free']:
            return f'{date.year}-Y'

        def find_nearest_period(date, periods):
            for p in periods:
                report_date = datetime.date(p[0], VAT_PERIOD_RANGE[p[1]][2][1], VAT_PERIOD_RANGE[p[1]][2][2])
                if (report_date - date).days > 0:
                    return '{}-{}'.format(p[0] + VAT_PERIOD_RANGE[p[1]][2][0], p[1])

        if self.is_corporation:
            return find_nearest_period(date, [
                (date.year, '4Q'),
                (date.year, '1Q'),
                (date.year, '2Q'),
                (date.year, '3Q'),
                (date.year + 1, '4Q')
            ])

        elif self.taxation == 'normal':
            return find_nearest_period(date, [
                (date.year, '2H'),
                (date.year, '1H'),
                (date.year + 1, '2H')
            ])

    def vat(self, period):
        return self.tax_set.get_or_create(type='vat-normal', period=period)[0]

    @property
    def is_activated(self):
        return self.activation == 'activated'

    def update_activation(self):
        cms_agreement = self.info.get('cms_agreement', False)
        mobiletax_agreement = self.info.get('mobiletax_agreement', False)
        document_types = {t[0] for t in Document.TYPES if t[0] != '임대차계약서'}

        old_activation = self.activation
        old_activation_display = self.get_activation_display()

        if self.document_set.count() == 0 and not cms_agreement and not mobiletax_agreement:
            self.activation = 'require_information'
        elif self.filter_documents('approved') >= document_types and cms_agreement:
            self.activation = 'activated'
        elif self.filter_documents('approved', 'uploaded') >= document_types and cms_agreement and mobiletax_agreement:
            self.activation = 'in_review'
        else:
            self.activation = 'trying'

        if old_activation != self.activation:
            tasks.send_slackbot_message(
                ':four_leaf_clover: http://mobiletax.kr/manager/traders/{}/chat {}({}): ~{}~ -> *{}*'.format(
                    self.id, self.business_name, self.user.phone,
                    old_activation_display, self.get_activation_display()),
                channel='#new-client')

        self.save()

    def filter_documents(self, *states):
        return set(self.document_set.filter(state__in=states).values_list('type', flat=True))

    def activation_color(self):
        return next(filter(lambda a: a[0] == self.activation, self.ACTIVATION_STATUSES))[2]

    def unread_messages(self, user):
        return Message.objects.filter(Q(trader=self) & ~Q(sender=user)).exclude(readers__in=[user])

    def check_ownership(self, user):
        if self.user != user:
            raise PermissionDenied('내가 등록한 상호가 아닙니다.')

    @property
    def acquisition(self):
        try:
            return self.user.acquisition
        except:
            return None

    def journalize_salary(self, issue_date):
        self.journalize_salary_full_time_employee(issue_date)
        self.journalize_salary_freelancer(issue_date)
        self.journalize_salary_daily_worker(issue_date)

    sum_expression = {k: Coalesce(Sum(k), 0) for k in [
        'base_pay', 'national_pension', 'health_insurance',
        'employment_insurance', 'longterm_care_insurance', 'income_tax',
        'local_income_tax', 'rural_special_tax', 'income_contingent_loan'
    ]}

    def journalize_salary_full_time_employee(self, issue_date):
        sums = Salary.objects.filter(
            employee__trader=self,
            employee__type='정직원',
            month__year=issue_date.year,
            month__month=issue_date.month,
        ).aggregate(**self.sum_expression)

        days_of_month = monthrange(issue_date.year, issue_date.month)[1]
        last_day_of_month = datetime.date(issue_date.year, issue_date.month, days_of_month)

        tid_prefix = 'salary-full-time-employee-{0.year}-{0.month}'.format(last_day_of_month)
        deduction = sum([v for k, v in sums.items() if k != 'base_pay'])
        self.journalize(tid_prefix, last_day_of_month,
                        debits=[('정직원 급여', '기본급', sums['base_pay'])],
                        credits=[
                            ('미지급 급여', '미지급금', sums['base_pay'] - deduction),
                            ('국민연금', '예수금', sums['national_pension']),
                            ('건강보험', '예수금', sums['health_insurance']),
                            ('고용보험', '예수금', sums['employment_insurance']),
                            ('장기요양보험료', '예수금', sums['longterm_care_insurance']),
                            ('소득세', '예수금', sums['income_tax']),
                            ('지방소득세', '예수금', sums['local_income_tax']),
                        ])

        if issue_date.month == 12:
            report_date = datetime.date(issue_date.year + 1, 1, 10)
        else:
            report_date = datetime.date(issue_date.year, issue_date.month + 1, 10)

        self.journalize(tid_prefix + '.미지급 급여', issue_date,
                        debits=[('미지급 급여', '미지급금', sums['base_pay'] - deduction)],
                        credits=[('미지급 급여 지급', '보통예금', sums['base_pay'] - deduction)])

        self.journalize(tid_prefix + '.국민연금 예수금', report_date,
                        debits=[('국민연금', '예수금', sums['national_pension'])],
                        credits=[('국민연금', '보통예금', sums['national_pension'])])
        self.journalize(tid_prefix + '.국민연금', report_date,
                        debits=[('국민연금', '보험료', sums['national_pension'])],
                        credits=[('국민연금', '보통예금', sums['national_pension'])])

        self.journalize(tid_prefix + '.건강보험 예수금', report_date,
                        debits=[('건강보험', '예수금', sums['health_insurance'])],
                        credits=[('건강보험', '보통예금', sums['health_insurance'])])
        self.journalize(tid_prefix + '.건강보험', report_date,
                        debits=[('건강보험', '보험료', sums['health_insurance'])],
                        credits=[('건강보험', '보통예금', sums['health_insurance'])])

        self.journalize(tid_prefix + '.고용보험 예수금', report_date,
                        debits=[('고용보험', '예수금', sums['employment_insurance'])],
                        credits=[('고용보험', '보통예금', sums['employment_insurance'])])
        self.journalize(tid_prefix + '.고용보험', report_date,
                        debits=[('고용보험', '보험료', sums['employment_insurance'])],
                        credits=[('고용보험', '보통예금', sums['employment_insurance'])])

        self.journalize(tid_prefix + '.장기요양보험료 예수금', report_date,
                        debits=[('장기요양보험료', '예수금', sums['longterm_care_insurance'])],
                        credits=[('장기요양보험료', '보통예금', sums['longterm_care_insurance'])])
        self.journalize(tid_prefix + '.장기요양보험료', report_date,
                        debits=[('장기요양보험료', '보험료', sums['longterm_care_insurance'])],
                        credits=[('장기요양보험료', '보통예금', sums['longterm_care_insurance'])])

        self.journalize(tid_prefix + '.산재보험', report_date,
                        debits=[('산재보험', '보험료', 0)],
                        credits=[('산재보험', '보통예금', 0)])

        self.journalize(tid_prefix + '.소득세', report_date,
                        debits=[('소득세', '예수금', sums['income_tax'])],
                        credits=[('소득세', '보통예금', sums['income_tax'])])

        self.journalize(tid_prefix + '.지방소득세', report_date,
                        debits=[('지방소득세', '예수금', sums['local_income_tax'])],
                        credits=[('지방소득세', '보통예금', sums['local_income_tax'])])

    def journalize_salary_freelancer(self, issue_date):
        sums = Salary.objects.filter(
            employee__trader=self,
            employee__type='프리랜서',
            month__year=issue_date.year,
            month__month=issue_date.month,
        ).aggregate(**self.sum_expression)

        days_of_month = monthrange(issue_date.year, issue_date.month)[1]
        last_day_of_month = datetime.date(issue_date.year, issue_date.month, days_of_month)
        if issue_date.month == 12:
            report_date = datetime.date(issue_date.year + 1, 1, 10)
        else:
            report_date = datetime.date(issue_date.year, issue_date.month + 1, 10)

        tid_prefix = 'salary-freelancer-{0.year}-{0.month}'.format(last_day_of_month)
        deduction = sum([v for k, v in sums.items() if k != 'base_pay'])
        self.journalize(tid_prefix, last_day_of_month,
                        debits=[('사업소득 지급', '기본급', sums['base_pay'])],
                        credits=[
                            ('미지급 급여', '미지급금', sums['base_pay'] - deduction),
                            ('소득세', '예수금', sums['income_tax']),
                            ('지방소득세', '예수금', sums['local_income_tax']),
                        ])

        self.journalize(tid_prefix + '.미지급 급여', issue_date,
                        debits=[('미지급 급여', '미지급금', sums['base_pay'] - deduction)],
                        credits=[('미지급 급여 지급', '보통예금', sums['base_pay'] - deduction)])
        self.journalize(tid_prefix + '.소득세', report_date,
                        debits=[('소득세', '예수금', sums['income_tax'])],
                        credits=[('소득세', '보통예금', sums['income_tax'])])

        self.journalize(tid_prefix + '.지방소득세', report_date,
                        debits=[('지방소득세', '예수금', sums['local_income_tax'])],
                        credits=[('지방소득세', '보통예금', sums['local_income_tax'])])

    def journalize_salary_daily_worker(self, issue_date):
        sums = Salary.objects.filter(
            employee__trader=self,
            employee__type='일용직',
            month__year=issue_date.year,
            month__month=issue_date.month,
        ).aggregate(**self.sum_expression)

        days_of_month = monthrange(issue_date.year, issue_date.month)[1]
        last_day_of_month = datetime.date(issue_date.year, issue_date.month, days_of_month)
        if issue_date.month == 12:
            report_date = datetime.date(issue_date.year + 1, 1, 10)
        else:
            report_date = datetime.date(issue_date.year, issue_date.month + 1, 10)

        tid_prefix = 'salary-daily-worker-{0.year}-{0.month}'.format(last_day_of_month)
        deduction = sum([v for k, v in sums.items() if k != 'base_pay'])
        self.journalize(tid_prefix, last_day_of_month,
                        debits=[('일용직 급여', '기본급', sums['base_pay'])],
                        credits=[
                            ('일용직 미지급 급여', '미지급금', sums['base_pay'] - deduction),
                            ('일용직 고용보험', '예수금', sums['employment_insurance']),
                        ])


        self.journalize(tid_prefix + '.미지급 급여', issue_date,
                        debits=[('일용직 미지급 급여', '미지급금', sums['base_pay'] - deduction)],
                        credits=[('일용직 미지급 급여 지급', '보통예금', sums['base_pay'] - deduction)])
        self.journalize(tid_prefix + '.고용보험 예수금', report_date,
                        debits=[('일용직 고용보험', '예수금', sums['employment_insurance'])],
                        credits=[('일용직 고용보험', '보통예금', sums['employment_insurance'])])
        self.journalize(tid_prefix + '.고용보험', report_date,
                        debits=[('고용보험', '보험료', sums['employment_insurance'])],
                        credits=[('고용보험', '보통예금', sums['employment_insurance'])])

    def journalize(self, tid, issue_date, debits, credits):
        for debit in debits:
            if debit[2] == 0: continue
            self.journalentry_set.update_or_create(
                type='차변',
                tid=tid,
                description_key=tid + '.' + debit[0],
                defaults=dict(
                    issued=issue_date,
                    description=debit[0],
                    account_title=debit[1],
                    amount=debit[2]
                )
            )
        for credit in credits:
            if credit[2] == 0: continue
            self.journalentry_set.update_or_create(
                type='대변',
                tid=tid,
                description_key=tid + '.' + credit[0],
                defaults=dict(
                    issued=issue_date,
                    description=credit[0],
                    account_title=credit[1],
                    amount=credit[2]
                )
            )

    def memo(self, key, default_value=''):
        memo = self.memo_set.filter(key=key).first()
        if memo is None:
            return default_value

        return memo.value


@receiver(post_save, sender=Trader)
def welcome(sender, instance, created, **kwargs):
    if not created:
        return

    Message.objects.create(
        trader=instance,
        sender=ensure_mobiletax_user(),
        type='notice',
        title='환영합니다!',
        content='''<p>안녕하세요 <strong>{}</strong> 대표님,<br />
        모바일택스 계정 생성을 축하드립니다!</p>
        <p>모바일택스는 대표님이 직접 일일이 세무내역을 입력해야 하는 회계 프로그램이 아닙니다.<br />
        회원님들에게 세무 대행 및 기장 서비스를 더욱 효과적으로 제공하기 위해 만든 정보 제공 및 수취용 어플리케이션입니다.
        </p>'''.format(instance.user.name)
    )

    Message.objects.create(
        trader=instance,
        sender=ensure_mobiletax_user(),
        type='notice',
        title='서비스 이용 안내',
        content='''<p>본 서비스를 이용하기 위해서는 계정 활성화와 유료가입(월 기장수수료 납입)이 필요합니다.
        <a href="/traders/{}" style="text-decoration: underline;">정보 등록 페이지</a>에서
        정보를 입력해주시면 모바일택스 매니저가 가입절차 진행 후 계정을 활성화시켜 드립니다.</p>'''.format(instance.id)
    )

    Message.objects.create(
        trader=instance,
        sender=ensure_mobiletax_user(),
        type='notice',
        title='언제든 도와드리겠습니다.',
        content='''<p>설정하는데 도움이 필요하면 언제든 상담창에 질문 남겨주시면 도와드리겠습니다.<br />
        유료가입 문의는 <a href="tel:18338332" style="text-decoration: underline;">1833-8332</a>로 직접 전화하셔도 되고,
        연락가능한 시간대와 전화번호를 남겨주시면 전화 드리겠습니다.<br />부담 갖지 말고 연락주세요.<br />
        감사합니다.</p>'''
    )

    # traders.create() sends slack msg


class Memo(models.Model):
    REQUIRED_FIELDS = ['대표자명', '업태', '종목', '업종코드', '구분', '과세유형',
                '우편번호', '사업장소재지', '사업장법정동코드', '본점(자택)주소',
                '주민(법인등록번호)', '전화번호', '팩스번호',
                '사업장관할서', '주소지관할서', '주민세납세지',
                '환급 은행', '환급 계좌번호', '환급 예금주']

    trader = models.ForeignKey(Trader, on_delete=models.CASCADE)
    key = models.CharField(max_length=200, verbose_name='항목명')
    value = models.TextField(verbose_name='내용')

    def __str__(self):
        return '%s/%s=%s' % (self.trader.business_name, self.key, self.value)


class Invoice(models.Model):
    INVOICE_TYPES = [
        ('sales', '매출'), ('purchases', '매입')
    ]
    VOUCHER_TYPES = [
        ('전자세금계산서', '전자세금계산서'),
        ('전자계산서', '전자계산서'),
        ('종이세금계산서', '종이세금계산서'),
        ('종이계산서', '종이계산서'),
        ('카드단말기', '카드단말기'),
        ('카드사용내역', '카드사용내역'),
        ('현금영수증', '현금영수증'),
        ('현금영수증(지출증빙용)', '현금영수증(지출증빙용)'),
        ('일반전표', '일반전표'),
        ('카과', '카드과세'),
        ('카면', '카드면세'),
        ('현과', '현금과세'),
        ('현면', '현금면세'),
        ('과세', '종이세금계산서'),
        ('면세', '종이계산서'),
        ('건별', '현금매출'),
        ('기타', '기타'),
    ]

    trader = models.ForeignKey(Trader, on_delete=models.CASCADE)
    invoice_type = models.CharField(max_length=100, choices=INVOICE_TYPES)
    voucher_type = models.CharField(max_length=100, choices=VOUCHER_TYPES)
    account_title = models.CharField(max_length=100, blank=True, null=True)
    journal = models.CharField(max_length=100, blank=True, null=True)
    issue_id = models.CharField(max_length=100, null=True, blank=True)
    written = models.DateField(null=True, blank=True)
    issued = models.DateField()
    sent = models.DateField(null=True, blank=True)

    supplier_no = models.CharField(max_length=100, null=True, blank=True, verbose_name='공급자 사업자번호')
    supplier_sub_no = models.CharField(max_length=100, null=True, blank=True, verbose_name='공급자 종사업장번호')
    supplier_name = models.CharField(max_length=200, null=True, blank=True, verbose_name='공급자 상호')
    supplier_representative = models.CharField(max_length=200, null=True, blank=True, verbose_name='공급자 대표')
    supplier_email = models.EmailField(null=True, blank=True, verbose_name='공급자 이메일')

    consumer_no = models.CharField(max_length=100, null=True, blank=True, verbose_name='공급받는자 사업자번호')
    consumer_sub_no = models.CharField(max_length=100, null=True, blank=True, verbose_name='공급받는자 종사업장번호')
    consumer_name = models.CharField(max_length=200, null=True, blank=True, verbose_name='공급받는자 상호')
    consumer_representative = models.CharField(max_length=200, null=True, blank=True, verbose_name='공급받는자 대표')
    consumer_email = models.EmailField(null=True, blank=True, verbose_name='공급받는자 이메일')
    consumer_email_sub = models.EmailField(null=True, blank=True, verbose_name='공급받는자 이메일2')

    product_name = models.CharField(max_length=1000, null=True, blank=True)
    value_of_supply = models.DecimalField(max_digits=20, decimal_places=0, default=Decimal('0'), blank=True, verbose_name='공급가액')
    vat = models.DecimalField(max_digits=20, decimal_places=0, default=Decimal('0'), blank=True, verbose_name='부가세')
    total = models.DecimalField(max_digits=20, decimal_places=0, default=Decimal('0'), blank=True, verbose_name='합계금액')

    description = models.TextField(blank=True)

    @property
    def counterpart_name(self):
        if self.invoice_type == 'sales':
            return self.consumer_name
        else:
            return self.supplier_name


class AccountTitle(models.Model):
    id = models.IntegerField(primary_key=True)
    title = models.CharField(max_length=200, db_index=True)
    category = models.CharField(max_length=200)
    relation = models.ForeignKey('AccountTitle', related_name='related', null=True, blank=True, on_delete=models.CASCADE)
    std_code = models.IntegerField(null=True, blank=True)
    std_title = models.CharField(max_length=200, null=True, blank=True)
    info = annoying.fields.JSONField(default=dict)


class JournalEntry(models.Model):
    trader = models.ForeignKey(Trader, on_delete=models.CASCADE)
    type = models.CharField(max_length=10)
    tid = models.CharField(max_length=100, null=True, blank=True)
    uid = models.CharField(max_length=100, null=True, blank=True)
    issued = models.DateField()
    account_title = models.CharField(max_length=200, null=True, blank=True)
    account_title_key = models.CharField(max_length=200, null=True, blank=True)
    counterpart = models.CharField(max_length=200, null=True, blank=True)
    counterpart_key = models.CharField(max_length=200, null=True, blank=True)
    description = models.CharField(max_length=200, null=True, blank=True)
    description_key = models.CharField(max_length=200, null=True, blank=True)
    amount = models.DecimalField(max_digits=20, decimal_places=0, default=Decimal('0'), blank=True, verbose_name='금액')
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    closing = models.BooleanField(default=False)


class Receipt(models.Model):
    trader = models.ForeignKey(Trader, on_delete=models.CASCADE)
    account_title = models.CharField(max_length=100)
    counterpart_name = models.CharField(max_length=1000)
    amount = models.DecimalField(max_digits=20, decimal_places=0)
    issued = models.DateField()
    description = models.TextField()


LAST_YEAR = -1
VAT_PERIOD_RANGE = {
    '1H': ((1, 1), (6, 30), (0, 7, 25)),
    '2H': ((7, 1), (12, 31), (LAST_YEAR, 1, 25)),
    '1Q': ((1, 1), (3, 31), (0, 4, 25)),
    '2Q': ((4, 1), (6, 30), (0, 7, 25)),
    '3Q': ((7, 1), (9, 30), (0, 10, 25)),
    '4Q': ((10, 1), (12, 31), (LAST_YEAR, 1, 25)),
    'Y': ((1, 1), (12, 31), (LAST_YEAR, 1, 25)),
}


def tax_period_display(period):
    if len(str(period)) == 4:
        return '%s년' % period

    return period.replace('-', '년 ').replace('1H', '상반기').replace('2H', '하반기').replace('Q', '분기')


class Tax(models.Model):
    TYPES = [
        ('income-tax', '소득세'),
        ('vat-normal', '부가가치세 일반과세자'),
        ('vat-simplified', '부가가치세 간이과세자'),
        ('income-tax-statement', '종합소득세 납부서'),
        ('vat-statement', '부가가치세 납부서'),
        ('withholding-tax-statement', '원천세 납부서'),
        ('withholding-tax', '원천세'),
    ]

    REQUIRED_INFO_FIELDS = [
        {
            'name': '신고구분상세코드',
            'choices': ['정기신고', '수정신고', '기한후신고', '경정청구'],
        }, {
            'name': '보정신고구분',
            'choices': ['Y', 'N'],
        }
    ]

    trader = models.ForeignKey(Trader, on_delete=models.CASCADE)
    type = models.CharField(max_length=100, choices=TYPES)
    period = models.CharField(max_length=100)
    amount = models.IntegerField(default=0)
    assessment = models.DecimalField(max_digits=20, decimal_places=0, default=Decimal('0'), blank=True, verbose_name='과세표준')
    sales = models.DecimalField(max_digits=20, decimal_places=0, default=Decimal('0'), blank=True, verbose_name='매출')
    purchases = models.DecimalField(max_digits=20, decimal_places=0, default=Decimal('0'), blank=True, verbose_name='매입')
    cost = models.DecimalField(max_digits=20, decimal_places=0, default=Decimal('0'), blank=True, verbose_name='경비')
    paid = models.DateTimeField(null=True, blank=True)
    ready_to_report = models.DateTimeField(null=True, blank=True)
    reported = models.DateTimeField(null=True, blank=True)
    info = JSONField(default={})
    file = models.FileField(null=True, blank=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    due = models.DateTimeField(null=True, blank=True)
    ntsreport = models.TextField(null=True, blank=True)
    attachments = models.ManyToManyField('Attachment', related_name='attachments')

    @property
    def label(self):
        if self.type == 'vat-normal':
            return '부가가치세'
        elif self.type == 'income-tax' and self.trader.is_corporation:
            return '법인세'
        elif self.type == 'income-tax' and not self.trader.is_corporation:
            return '종합소득세'
        elif self.type == 'withholding-tax' and not self.trader.is_corporation:
            return '원천세'

    @property
    def report_date(self):
        year = '{}년 '.format(self.year + 1)

        if self.type == 'income-tax':
            if self.trader.is_corporation:
                return year + '3월 31일'
            else:
                return year + '5월 31일'

        elif self.type == 'vat-normal':
            if self.trader.taxation == 'simplified':
                return year + '1월 25일'
            elif self.trader.taxation == 'tax-free':
                return '-'
            else:
                year = '{}년 '.format(self.year - VAT_PERIOD_RANGE[self.period[5:]][2][0])
                return year + '{}월 {}일'.format(*VAT_PERIOD_RANGE[self.period[5:]][2][1:])

    def message_title(self):
        return template_lookup.get_template('tax/%s.html' % self.type).get_def('title').render(tax=self)

    def message_content(self):
        return template_lookup.get_template('tax/%s.html' % self.type).render_unicode(tax=self, **settings.MAKO_DEFAULT_CONTEXT)

    def range(self):
        year = int(self.period[:4])

        if len(self.period) == 4:
            return (datetime.date(year, 1, 1), datetime.date(year, 12, 31))
        else:
            r = VAT_PERIOD_RANGE[self.period[5:]]
            return (datetime.date(year, *r[0]), datetime.date(year, *r[1]))

    @property
    def period_display(self):
        if self.type == 'vat-normal':
            year, half = self.period.split('-')
            return '%s년 %s' % (year, '상반기' if half == '1H' else '하반기')
        else:
            return '%s년' % self.period

    @property
    def previous_period(self):
        year = self.year
        half_or_quarter = self.half_or_quarter
        if half_or_quarter == 'Y':
            return '{}-Y'.format(year - 1)

        n, unit = int(half_or_quarter[0]) - 1, half_or_quarter[1]
        if not n:
            n = 2 if unit == 'H' else 4
            year -= 1

        return '{}-{}{}'.format(year, n, unit)

    def __str__(self):
        return '%s %s %s %s' % (self.trader, self.type, self.period, self.amount)

    @property
    def year(self):
        return int(str(self.period).split('-')[0])

    @property
    def half_or_quarter(self):
        return self.period.split('-')[1]

    def calculate(self):
        if self.type == 'income-tax':
            purchases_year = self.trader.invoice_set.filter(invoice_type='purchases', issued__year=self.year).aggregate(Sum('value_of_supply'))['value_of_supply__sum'] or 0
            sales_year = self.trader.invoice_set.filter(invoice_type='sales', issued__year=self.year).aggregate(Sum('value_of_supply'))['value_of_supply__sum'] or 0
            self.cost = sales_year - purchases_year - int(self.assessment)

    def part(self, name):
        if not hasattr(self, 'tax_engine'):
            if self.type.startswith('vat'):
                self.tax_engine = 부가가치세(self)

        return getattr(self.tax_engine, name)

    def remove_dependency(self, on_delete=True):
        affected_tax_id = self.info.pop('affecting_tax', None)
        affecting_taxes_id = self.info.pop('수정신고세액변동', []) if on_delete else []
        if affected_tax_id:
            try:
                affected_tax = Tax.objects.get(id=affected_tax_id)
                affected_tax.info['수정신고세액변동'].remove(self.id)
                affected_tax.save(update_fields=['info'])
            except ObjectDoesNotExist:
                pass
        affecting_taxes = Tax.objects.filter(id__in=affecting_taxes_id)
        for tax in affecting_taxes:
            tax.info.pop('affecting_tax', None)
            tax.save(update_fields=['info'])

        if not on_delete:
            self.save(update_fields=['info'])


@receiver(post_save, sender=Tax)
def save_tax(sender, instance, created, **kwargs):
    if instance.type == 'withholding-tax':
        # info만 업데이트 하는 등 parital update에는 아래 로직을 수행하지 않음
        is_partial_update = kwargs.get('update_fields')
        if is_partial_update:
            return
        # 마감 취소시에는 데이터 삭제
        if instance.ready_to_report is None:
            instance.info.pop('reported', None)
            instance.info.pop('차월이월환급세액', None)
            instance.remove_dependency(False)
            return

        tax_result = 원천세(instance)
        instance.info['reported'] = tax_result.to_json()
        instance.info['차월이월환급세액'] = tax_result.차월이월환급세액
        instance.save(update_fields=['info'])

        # 수정신고세액변동이 존재할 시 마감일에 해당하는 당월분 정기신고에 수정신고변동내용을 기록함
        if tax_result.신고구분상세코드 == '수정신고':
            previous_tax = instance.get_previous_by_created(trader=instance.trader, period=instance.period,
                                                            type=instance.type, ready_to_report__isnull=False)
            reported = json.loads(previous_tax.info['reported'])
            for f in ['소득세', '농특세', '가산세']:
                납부세액_key = f if f == '가산세' else '납부세액' + f
                previous = reported['records']['A99'][납부세액_key] if 납부세액_key in reported['records']['A99'] else 0
                instance.info['수정신고발생' + f] = int(tax_result.records['A99'][납부세액_key] - previous)
            instance.save(update_fields=['info'])

            제출연월 = (instance.ready_to_report - relativedelta(months=1)).strftime('%Y-%m')
            if 제출연월 == instance.period:
                return
            try:
                affected_tax = Tax.objects.filter(trader=instance.trader, period=제출연월, type=instance.type).first()
            except ObjectDoesNotExist:
                return

            if sum(instance.info.get('수정신고발생' + f, 0) for f in ['소득세', '농특세', '가산세']) != 0:
                if affected_tax.info.get('수정신고세액변동'):
                    affected_tax.info['수정신고세액변동'].append(instance.id) if instance.id not in affected_tax.info[
                        '수정신고세액변동'] else None
                else:
                    affected_tax.info['수정신고세액변동'] = [instance.id]
                instance.info['affecting_tax'] = affected_tax.id
                instance.save(update_fields=['info'])
                affected_tax.save(update_fields=['info'])


@receiver(post_delete, sender=Tax)
def delete_tax(sender, instance, **kwargs):
    if instance.type == 'withholding-tax':
        instance.remove_dependency()


class Employee(models.Model):

    TYPES = ['정직원', '일용직', '프리랜서']
    INFO_SCHEMA = {
        '두루누리': {
            'type': 'string',
            'choices': [
                {'value': '신규가입근로자'},
                {'value': '기존가입근로자'},
                {'value': '미적용'}
            ]
        },
        '학자금대출': {
            'type': 'string',
        },
        '종(전)근무지': {
            'type': 'string',
        },
        '종(전)근무지_사업자등록번호': {
            'type': 'string',
        },
        '종(전)_소득세': {
            'type': 'decimal',
        },
        '종(전)_농어촌특별세': {
            'type': 'decimal',
        },
        '고용주 가족여부': {
            'type': 'string',
            'choices': [
                {'value': '예'},
                {'value': '아니오'}
            ]
        }
    }

    trader = models.ForeignKey(Trader, on_delete=models.CASCADE)
    name = models.CharField(max_length=100, verbose_name='이름')
    registration_no = models.CharField(max_length=100, verbose_name='주민등록번호')
    type = models.CharField(max_length=100, verbose_name='고용형태', choices=[(type, type) for type in TYPES])
    base_pay = models.DecimalField(max_digits=20, decimal_places=0, verbose_name='기본급')
    payday = models.CharField(max_length=2, null=True, blank=True)
    dependents = models.PositiveSmallIntegerField(default=1)
    created = models.DateField(auto_now_add=True)
    joined = models.DateField(null=True, blank=True, verbose_name='입사일')
    quitted = models.DateField(null=True, blank=True, verbose_name='퇴사일')
    note = models.TextField(default='', blank=True)
    info = JSONField(default=dict)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    def insert_salary_for_month(self, date):
        return self.salary_set.update_or_create(
            month=date,
            defaults=dict(
                base_pay=self.base_pay
            )
        )[0]

    def severance_pay(self):
        result = {
            '최근3개월': [],
            '재직일수': 0,
            '퇴직금액': 0
        }
        if self.joined is None or self.quitted is None:
            return result

        # 퇴사일은 마지막 근무일 + 1 이지만, 재직일수를 구할 떄 + 1을 하므로 그냥 계산해도 된다.
        result['재직일수'] = (self.quitted - self.joined).days

        if result['재직일수'] < 365:
            return result

        # 해당 기간의 마지막 근무일자
        last_day = self.quitted - timedelta(days=1)
        left_day = 0
        check_month = 3

        # (퇴직당월의 근무일) + (check_month-1)개월 + ((check_month)개월전의 근무일 - (1달 - 퇴직당월의 근무일))
        while check_month >= 0:
            # 해당 달의 근무시작일자
            start = last_day - timedelta(days=last_day.day - 1)
            if check_month == 0 and left_day != 0:
                start = last_day - timedelta(days=left_day - 1)
            elif check_month == 0:
                break

            end = last_day
            work_day = end.day - start.day + 1
            ratio = Decimal(work_day / monthrange(last_day.year, last_day.month)[1])
            try:
                salary = Salary.objects.get(employee=self, month__year=last_day.year, month__month=last_day.month)
            except ObjectDoesNotExist:
                return result
            # 일급을 구한 후 근무일수를 곱하여 해당 달의 임금을 산정한다
            base_pay = floor(salary.base_pay * ratio)
            result['최근3개월'].append({'start': start, 'end': end, 'work_day': work_day, 'ratio': ratio, 'base_pay': base_pay})
            left_day += monthrange(last_day.year, last_day.month)[1] - work_day
            last_day = start - timedelta(days=1)
            check_month -= 1

        최근3개월총일수 = sum([x['work_day'] for x in result['최근3개월']])
        최근3개월총금액 = sum([x['base_pay'] for x in result['최근3개월']])
        평균임금 = 최근3개월총금액 / 최근3개월총일수
        임금 = floor(평균임금)
        result['퇴직금액'] = floor(((임금 * 30) * result['재직일수']) / 365)

        return result


@receiver(post_save, sender=Employee)
def save_employee(sender, instance, created, **kwargs):
    if created:
        if not instance.trader.report_salary:
            instance.trader.report_salary = True
            instance.trader.save()


@receiver(post_delete, sender=Employee)
def delete_employee(sender, instance, **kwargs):
    if instance.trader.employee_set.count() == 0:
        instance.trader.report_salary = False
        instance.trader.save()


class Salary(models.Model):

    RATES = {
        '정직원': {
            'national_pension': Decimal(0.045),
            'health_insurance': Decimal(0.0306),
            # 사업주는 사업장 규모에 따라 고용안정, 직업능력 개발사업 요율이 더해진다.
            # https://www.ei.go.kr/ei/eih/eg/ei/eiEminsr/retrieveEi0301Info.do
            'employment_insurance': Decimal(0.009),
            'longterm_care_insurance': Decimal(0.0020043),
        },
        '프리랜서': {
            'national_pension': Decimal(0),
            'health_insurance': Decimal(0),
            'employment_insurance': Decimal(0),
            'longterm_care_insurance': Decimal(0),
        },
        '일용직': {
            'national_pension': Decimal(0),
            'health_insurance': Decimal(0),
            'employment_insurance': Decimal(0.0065),
            'longterm_care_insurance': Decimal(0),
        }
    }

    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    month = models.DateField()
    base_pay = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    bonus = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    national_pension = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    national_pension_adjustment = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    health_insurance = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    employment_insurance = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    longterm_care_insurance = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    income_tax = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    local_income_tax = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    rural_special_tax = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    income_contingent_loan = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    ready_to_report = models.BooleanField()
    info = JSONField(default={})

    class Meta:
        verbose_name_plural = 'Salaries'

    def __str__(self):
        return '{} {}년 {}월'.format(self.employee.name, self.month.year, self.month.month)

    def save(self, force_insert=False, force_update=False, using=None, update_fields=None):
        if not self.pk:
            self.ready_to_report = self.employee.type != '일용직'
        else:
            if '근로내용' in self.info:
                pay = 0
                for 근로내용 in self.info['근로내용'].values():
                    try:
                        pay += int(근로내용['지급액'])
                    except ValueError:
                        pass

                self.ready_to_report = pay == self.base_pay

        self.update_base_pay()
        super().save(force_insert=force_insert, force_update=force_update, using=using, update_fields=update_fields)

    def update_base_pay(self):
        self.national_pension = floor(self.calc_national_pension(), -1)
        self.health_insurance = floor(self.base_pay * Salary.RATES[self.employee.type]['health_insurance'], -1)
        self.employment_insurance = floor(self.calc_employment_insurance(), -1)
        self.longterm_care_insurance = floor(self.base_pay * Salary.RATES[self.employee.type]['longterm_care_insurance'], -1)
        self.income_tax = self.calc_income_tax()
        self.local_income_tax = floor(self.income_tax * Decimal(0.1), -1)

    def calc_income_tax(self):
        if self.employee.type == '정직원':
            return self.regular_income_tax(self.employee.dependents)
        elif self.employee.type == '프리랜서':
            return self.freelancer_income_tax(self.base_pay)
        elif self.employee.type == '일용직':
            return Decimal(0)

    def freelancer_income_tax(self, base_pay):
        return floor(base_pay * Decimal(0.03), -1)

    def regular_income_tax(self, 공제대상자=1):

        # 퇴사월을 포함한 이후에는 소득세가 부과되지 않는다.
        if self.employee.quitted is not None:
            귀속월 = datetime.date(self.month.year, self.month.month, 1)
            퇴사월 = datetime.date(self.employee.quitted.year, self.employee.quitted.month, 1)
            if 귀속월 >= 퇴사월:
                return 0

        # 부가세가 과세되는 최소 기본급
        if self.base_pay < 1060000:
            return 0

        기본급 = self.base_pay
        간이세액 = 0

        # 기본급에 따른 간이세액
        if 기본급 > 10000000:
            세율구간 = (
                (45000000, Decimal(0.392)),
                (14000000, Decimal(0.3724)),
                (10000000, Decimal(0.343)),
            )

            for 기준액, 세율 in 세율구간:
                if 기본급 <= 기준액:
                    continue

                간이세액 += (기본급 - 기준액) * 세율
                기본급 = 기준액

            기본급 = 10000000
            간이세액 = floor(간이세액, -1)

        # 소득구간에 따라 월급여액을 정규화
        if 기본급 < 10000000:
            간격 = None
            if 기본급 < 1500000:
                간격 = 5000
            elif 기본급 < 3000000:
                간격 = 10000
            elif 기본급 < 10000000:
                간격 = 20000

            월급여액 = int(기본급 / 간격) * 간격 + Decimal(간격 / 2)
        else:
            월급여액 = 10000000

        총급여액 = 월급여액 * 12

        # 근로소득공제
        공제율구간 = (
            (100000000, Decimal(0.02)),
            (45000000, Decimal(0.05)),
            (15000000, Decimal(0.15)),
            (5000000, Decimal(0.4)),
            (0, Decimal(0.7)),
        )

        근로소득공제 = 0
        근로소득금액 = 총급여액
        for 기준액, 공제율 in 공제율구간:
            if 총급여액 <= 기준액:
                continue

            근로소득공제 += (총급여액 - 기준액) * 공제율
            총급여액 = 기준액

        총급여액 = 근로소득금액
        근로소득금액 -= 근로소득공제
        인적공제 = 공제대상자 * 1500000

        # 연금보험료공제
        # 국민연금 기준소득액의 상한/하한에 의한 제한
        if 월급여액 < 250000:
            월급여액 = 250000
        elif 월급여액 > 3980000:
            월급여액 = 3980000

        국민연금부담금 = floor(월급여액, -3) * Decimal(0.045)
        국민연금부담금 = floor(국민연금부담금, -1)
        연금보험료공제 = 국민연금부담금 * 12

        # 특별소득공제 등
        공제유형 = 공제대상자 - 1 if 공제대상자 < 3 else -1

        기본공제 = (3100000, 3600000, 5000000)
        공제율구간 = (
            (45000000, (Decimal(0.04), Decimal(0.04), Decimal(0.07))),
            (70000000, (Decimal(0.015), Decimal(0.02), Decimal(0.05))),
            (120000000, (Decimal(0.005), Decimal(0.01), Decimal(0.03))),
        )

        특별소득공제등 = 기본공제[공제유형]
        for 기준액, 공제율 in 공제율구간:
            if 총급여액 <= 기준액:
                특별소득공제등 += 총급여액 * 공제율[공제유형]
                break

        if 30000000 < 총급여액 <= 45000000:
            특별소득공제등 -= (총급여액 - 30000000) * Decimal(0.05)

        if 공제대상자 >= 3 and 총급여액 > 40000000:
            특별소득공제등 += (총급여액 - 40000000) * Decimal(0.04)

        과세표준 = 근로소득금액 - 인적공제 - 연금보험료공제 - 특별소득공제등

        # 산출세액
        세율구간 = (
            (500000000, Decimal(0.4)),
            (150000000, Decimal(0.38)),
            (88000000, Decimal(0.35)),
            (46000000, Decimal(0.24)),
            (12000000, Decimal(0.15)),
            (0, Decimal(0.06)),
        )

        산출세액 = 0
        for 기준액, 세율 in 세율구간:
            if 과세표준 <= 기준액:
                continue

            산출세액 += (과세표준 - 기준액) * 세율
            과세표준 = 기준액

        산출세액 = floor(산출세액)
        결정세액 = 산출세액

        # 근로소득세액공제
        근로소득세액공제 = 0
        if 산출세액 > 500000:
            근로소득세액공제 += (산출세액 - 500000) * Decimal(0.3)
            산출세액 = 500000

        근로소득세액공제 += 산출세액 * Decimal(0.55)

        근로소득세액공제한도 = (
            (70000000, 500000),
            (55000000, 630000),
            (0, 660000),
        )

        for 기준액, 한도 in 근로소득세액공제한도:
            if 총급여액 <= 기준액:
                continue

            if 근로소득세액공제 > 한도:
                근로소득세액공제 = 한도

            break

        근로소득세액공제 = floor(근로소득세액공제)
        결정세액 -= 근로소득세액공제
        간이세액 += floor(결정세액 / Decimal(12), -1)

        return 간이세액

    def calc_national_pension(self):
        국민연금기준급여 = self.base_pay
        try:
            salary_item = self.salaryitem_set.get(field__name='국민연금 기준급여')
            if salary_item.number_value is not None:
                국민연금기준급여 = salary_item.number_value
        except SalaryItem.DoesNotExist:
            pass

        return self.apply_durunuri(국민연금기준급여, Salary.RATES[self.employee.type]['national_pension'])

    def calc_employment_insurance(self):
        if self.employee.info.get('고용주 가족여부') == '예':
            return 0

        return self.apply_durunuri(self.base_pay, Salary.RATES[self.employee.type]['employment_insurance'])

    def apply_durunuri(self, 급여, 세율):
        세액 = 급여 * 세율
        if 급여 < 1400000:
            두루누리 = self.employee.info.get('두루누리')
            # 최초 가입근로자이거나 피보험기간이 3년 이상 단절된 근로자
            if 두루누리 == '신규가입근로자':
                세액 *= Decimal(0.4)
            elif 두루누리 == '기존가입근로자':
                세액 *= Decimal(0.6)

        return 세액


@receiver(post_save, sender=Salary)
def save_salary(sender, instance, created, **kwargs):
    if not created:
        return

    month = instance.month - relativedelta(months=1)
    salary = Salary.objects.prefetch_related('salaryitem_set').filter(employee=instance.employee,
                                                                      month__year=month.year,
                                                                      month__month=month.month).first()
    if not salary:
        return

    try:
        salary_item = salary.salaryitem_set.get(field__name='국민연금 기준급여')
        salary_item.pk = None
        salary_item.salary = instance
        salary_item.save()
    except SalaryItem.DoesNotExist:
        return


class InvoiceForm(Form):
    type = 'invoice'

    issued = fields.DateField(label='발행날짜')
    counterpart_name = fields.CharField(label='거래처')
    counterpart_registration_no = fields.CharField(label='거래처 사업자번호')
    product_name = fields.CharField(label='품목')
    value_of_supply = fields.DecimalField(label='공급가액')
    vat = fields.DecimalField(label='부가세')
    total = fields.DecimalField(label='합계금액')


class ReceiptForm(Form):
    type = 'receipt'
    issued = fields.DateField(label='발행날짜')
    counterpart_name = fields.CharField(label='거래처')
    product_name = fields.CharField(label='품목')
    total = fields.DecimalField(label='금액')


class CashSalesForm(Form):
    issued = MonthField(label='날짜', initial=time.strftime("%Y-%m"))
    amount = fields.IntegerField(label='금액(VAT포함)')


class SalaryForm(Form):
    type = 'salary'

    EMPLOYER_TYPES = [(type, type) for type in Employee.TYPES]

    issued = MonthField(label='지급월', initial=time.strftime("%Y-%m"))
    name = fields.CharField(label='이름')
    registration_no = fields.CharField(label='주민등록번호')
    employer_type = fields.ChoiceField(label='고용형태', choices=EMPLOYER_TYPES)
    salary_before_tax = fields.IntegerField(label='세전금액')
    insurance = fields.CharField(label='4대보험', required=False)
    withholding_tax = fields.CharField(label='원천징수세액', required=False)
    salary_after_tax = fields.CharField(label='세후금액')


class Voucher(models.Model):
    FORMS = {
        'receipt': ReceiptForm,
        'simple-receipt': ReceiptForm,
        'purchase-tax-invoice': InvoiceForm,
        'sales-tax-invoice': InvoiceForm,
        'purchase-invoice': InvoiceForm,
        'sales-invoice': InvoiceForm,
        'salary': SalaryForm,
        'cash-sales': CashSalesForm,
        'others': ReceiptForm,
    }
    TYPES = [
        ('unknown', '미확인', ReceiptForm),
        ('receipt', '영수증', ReceiptForm),
        ('simple-receipt', '간이 영수증', ReceiptForm),
        ('purchase-tax-invoice', '종이세금계산서 매출', InvoiceForm),
        ('sales-tax-invoice', '종이세금계산서 매입', InvoiceForm),
        ('purchase-invoice', '종이계산서 매출', InvoiceForm),
        ('sales-invoice', '종이계산서 매입', InvoiceForm),
        ('salary', '인건비', SalaryForm),
        ('cash-sales', '현금매출', CashSalesForm),
        ('others', '기타', ReceiptForm),
    ]

    MANUALLY_CLASSIFIABLE_TYPES = [
        'receipt',
        'simple-receipt',
        'purchase-tax-invoice',
        'sales-tax-invoice',
        'purchase-invoice',
        'sales-invoice',
        'others',
    ]
    trader = models.ForeignKey(Trader, on_delete=models.CASCADE)
    repeat_key = models.CharField(max_length=100, blank=True, null=True)
    type = models.CharField(max_length=100, choices=[e[:2] for e in TYPES])
    file = models.FileField(null=True, blank=True)
    mimetype = models.CharField(max_length=100, null=True, blank=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    preprocessed = models.DateTimeField(null=True, blank=True)
    processed = models.DateTimeField(null=True, blank=True)
    attachment = models.ForeignKey('Attachment', null=True, blank=True, on_delete=models.CASCADE)
    info = JSONField(default={})


class Message(models.Model):
    TYPES = [
        ('income-tax-report', '종합소득세 신고서'),
        ('vat-report', '부가가치세 신고서'),
        ('income-tax-statement', '종합소득세 납부서'),
        ('vat-statement', '부가가치세 납부서'),
        ('withholding-tax-statement', '원천세 납부서'),
        ('information-request', '자료요청'),
        ('notice', '공지사항'),
        ('text', '텍스트'),
        ('voucher', '증빙자료'),
        ('attachment', '첨부파일'),
        ('local-income-tax-statement', '지방소득세 납부서'),
        ('national-income-tax-statement', '소득세 납부서'),
        ('withholding-tax-status-report', '원천징수이행상황신고서')
    ]

    DISPLAY_TYPES = ['income-tax-report', 'vat-report', 'income-tax-statement', 'vat-statement', 'withholding-tax-statement', 'information-request', 'local-income-tax-statement', 'withholding-tax-status-report', 'national-income-tax-statement']
    TAX_DOCUMENT_TYPES = ['income-tax-report', 'vat-report', 'income-tax-statement', 'vat-statement', 'withholding-tax-statement', 'local-income-tax-statement', 'withholding-tax-status-report', 'national-income-tax-statement']

    templates = {
        'empty': {
            'type': None,
            'title': '',
            'content': ''
        },
        'vat-report': {
            'title': '[****년 *기 부가가치세 신고서]를 보내드립니다.',
            'content': '****년 *기 부가가치세 신고서입니다. 특이사항이 있는 지 확인 부탁드립니다. 특이사항이 있으면 담당자에게 연락을 주시고, '
                       '특이사항이 없으면 [확인했음] 버튼을 클릭해 주세요. 신고서 제출 후 납부서를 보내드리겠습니다.',
            'process': 'read',
        },
        'income-tax-report': {
            'title': '[****년 *기 종합소득세 신고서]를 보내드립니다.',
            'content': '****년 *기 부가가치세 신고서입니다. 특이사항이 있는 지 확인 부탁드립니다. 특이사항이 있으면 담당자에게 연락을 주시고, '
                       '특이사항이 없으면 [확인했음] 버튼을 클릭해 주세요. 신고서 제출 후 납부서를 보내드리겠습니다.',
            'process': 'read',
        },
        'income-tax-statement': {
            'title': '[****년 종합소득세 납부서]를 보내드립니다.',
            'content': '',
            'process': 'read',
        },
        'vat-statement': {
            'title': '[****년 *기 부가가치세 납부서]를 보내드립니다.',
            'content': '',
            'process': 'read',
        },
        'withholding-tax-statement': {
            'title': '[****년 *월 원천세 납부서]를 보내드립니다.',
            'content': '',
            'process': 'read',
        },
        'information-request': {
            'title': '[****년 *기 부가가치세] 신고를 위한 자료를 요청드립니다.',
            'content': '****년 *월 **일까지 ****년 *기(*~*월) 부가가치세 신고를 해야 합니다. *월 **일까지 종이세금계산서, 종이계산서, 간이영수증 등을 '
                       '스마트폰을 통해 사진찍어 보내주시길 바랍니다.',
            'process': 'manager',
        },
        'notice': {
            'title': '[공지사항] ',
            'content': '',
            'process': 'read',
        },
        'local-income-tax-statement': {
            'title': '[****년 **월 지방소득세 납부서]를 보내드립니다.',
            'content': '',
            'process': 'read',
        },
        'withholding-tax-status-report': {
            'title': '[****년 **월 원천징수이행상황신고서]를 보내드립니다.',
            'content': '',
            'process': 'read',
        },
        'national-income-tax-statement': {
            'title': '[****년 **월 소득세 납부서]를 보내드립니다.',
            'content': '',
            'process': 'read',
        }
    }
    trader = models.ForeignKey(Trader, on_delete=models.CASCADE)
    sender = models.ForeignKey(User, on_delete=models.SET(ensure_deleted_user))
    group = models.CharField(max_length=100, db_index=True, null=True, blank=True)
    type = models.CharField(max_length=100, choices=TYPES, verbose_name='메세지 종류')
    mimetype = models.CharField(max_length=100, default='text/plain')
    title = models.TextField(null=True, blank=True, verbose_name='제목')
    content = models.TextField(blank=True, verbose_name='본문')
    content_id = models.PositiveIntegerField(null=True, blank=True)
    content_object = GenericForeignKey('content_type', 'content_id')
    content_type = models.ForeignKey(ContentType, null=True, blank=True, on_delete=models.SET_NULL)
    created = models.DateTimeField(auto_now_add=True)
    read = models.DateTimeField(null=True, blank=True)
    done = models.DateTimeField(null=True, blank=True)
    due = models.DateField(null=True, blank=True)
    readers = models.ManyToManyField(User, related_name='read_messages', through='Reader')
    info = JSONField(default={})

    def __str__(self):
        return '%s: %s' % (self.sender, self.content)

    @staticmethod
    def create_from_voucher(voucher):
        Message.objects.create(
            trader=voucher.trader,
            sender=voucher.trader.user,
            type='voucher',
            title='증빙자료',
            content=voucher.file.name or voucher.get_type_display(),
            content_type=ContentType.objects.get_for_model(Voucher),
            content_id=voucher.id,
        )

    def is_from_client(self):
        return self.trader.user == self.sender

    @staticmethod
    @transaction.atomic
    def read_by(user, messages):
        read_messages = Reader.objects.filter(
            user=user, message__id__in=[message.id for message in messages]
        ).values_list('message_id', flat=True)

        messages = filter(lambda m: m.id not in read_messages, messages)
        Reader.objects.bulk_create([Reader(user=user, message=message) for message in messages])


class Read(models.Model):
    chat_room = models.ForeignKey(Trader, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    read_id = models.PositiveIntegerField(default=0)

    class Meta:
        unique_together = ('chat_room', 'user',)


class Reader(models.Model):
    class Meta:
        db_table = 'accounting_message_readers'

    message = models.ForeignKey(Message, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)


class CustomField(models.Model):
    CATEGORIES = [
        ('인건비', '인건비'),
    ]

    SALARY_INFO_SCHEMA = {
        '유형': {
            'type': 'choice',
            'required': False,
            'choices': [
                {'value': '수입'},
                {'value': '공제'},
            ],
        },
        '과세여부': {
            'type': 'choice',
            'required': False,
            'choices': [
                {'value': '과세'},
                {'value': '비과세'},
                {'value': '면세'},
            ],
        },
        '월정': {
            'type': 'boolean',
            'required': False,
            'description': '월 정기급여'
        },
        '급여': {
            'type': 'boolean',
            'required': False,
            'description': '급여'
        },
        '상여': {
            'type': 'boolean',
            'required': False,
            'description': '상여'
        },
        '추가급여': {
            'type': 'boolean',
            'required': False,
            'description': '추가급여'
        },
        '추가상여': {
            'type': 'boolean',
            'required': False,
            'description': '추가상여'
        },
    }
    name = models.CharField(max_length=200)
    category = models.CharField(max_length=100, choices=CATEGORIES)
    info = annoying.fields.JSONField(default=dict)

    class Meta:
        unique_together = ('name', 'category',)

    def __str__(self):
        return self.name


class SalaryItem(models.Model):
    salary = models.ForeignKey(Salary, on_delete=models.CASCADE)
    field = models.ForeignKey(CustomField, on_delete=models.CASCADE)
    number_value = models.DecimalField(max_digits=20, decimal_places=0, blank=True, null=True)
    string_value = models.CharField(max_length=200, default='', blank=True)

    def __str__(self):
        return '{} {}'.format(self.salary, self.field.name)


@receiver(post_save, sender=SalaryItem)
def save_salary_item(sender, instance, created, **kwargs):
    instance.salary.save()


class Attachment(models.Model):
    THUMBNAIL_PRESET = {'small': (480, 480)}
    DEFAULT_THUMBNAIL = 'small'

    message = models.ForeignKey(Message, null=True, on_delete=models.CASCADE)
    file = models.FileField()
    mimetype = models.CharField(max_length=100, null=True, blank=True)
    filename = models.CharField(max_length=1000, null=True, blank=True)
    size = models.IntegerField(default=0)
    width = models.IntegerField(default=0)
    height = models.IntegerField(default=0)
    manager = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    employee = models.ForeignKey(Employee, null=True, blank=True, on_delete=models.CASCADE)
    downloaded = models.BooleanField(default=False)
    printed = models.BooleanField(default=False)
    handled = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)
    info = JSONField(default={'faxes': []})

    def __str__(self):
        return self.file.name

    @property
    def trader(self):
        return self.message.trader if self.message else None

    def save(self, force_insert=False, force_update=False, using=None,
             update_fields=None):
        try:
            if not self.filename:
                self.filename = self.file.name

            if not self.mimetype:
                self.mimetype = mimetypes.guess_type(self.filename)[0] or ''

            if not self.size:
                self.size = self.file.size

            if self.mimetype.startswith('image'):
                self.width, self.height = Image.open(self.file).size
        except Exception as e:
            logging.exception(e)

        super().save(force_insert, force_update, using, update_fields)

    def get_thumbnail_size(self, size=None):
        if size not in self.THUMBNAIL_PRESET:
            size = self.DEFAULT_THUMBNAIL

        return size, self.THUMBNAIL_PRESET[size]

    def get_actual_thumbnail_size(self, size=None):
        if size not in self.THUMBNAIL_PRESET:
            size = self.DEFAULT_THUMBNAIL
        size = self.THUMBNAIL_PRESET[size]

        x, y = self.width, self.height
        if x > size[0]:
            y = int(max(y * size[0] / x, 1))
            x = int(size[0])
        if y > size[1]:
            x = int(max(x * size[1] / y, 1))
            y = int(size[1])

        return x, y

    def get_thumbnail_filename(self, size=None):
        filename = self.file.name
        if not size:
            return filename

        size, _ = self.get_thumbnail_size(size)
        thumbnail = Thumbnail.objects.filter(image=self, alias=size).first()
        if thumbnail:
            filename = thumbnail.file.name

        return filename


class Thumbnail(models.Model):
    image = models.ForeignKey(Attachment, on_delete=models.CASCADE)
    file = models.FileField(null=True)
    alias = models.CharField(max_length=10, default='small')
    width = models.IntegerField(default=0)
    height = models.IntegerField(default=0)

    def __str__(self):
        return self.file.name


@receiver(post_save, sender=Message)
def send_push_notification(sender, instance, created, **kwargs):
    # from accounting.schema import OnMessageAdded
    # OnMessageAdded.broadcast(group=f'trader:{instance.trader.id}:message', payload={
    #     'message': instance
    # })

    if settings.DEBUG or not created:
        return

    if instance.sender.is_staff:
        badge_count = instance.trader.user.inbox_count()
        title = strip_tags(instance.title)
        content = strip_tags(instance.content)
        tasks.push_notification.apply_async(args=[instance.trader.user.id, title, content, badge_count], kwargs={})
    else:
        manager = instance.trader.accounting_manager or User.objects.filter(for_new_client=True).first()

        if manager:
            now = datetime.datetime.now()
            need_to_send = False
            content = ''

            if manager.condition == '부재중 메시지 사용':
                if manager.work_starting_time > now.hour or manager.work_finishing_time < now.hour:
                    need_to_send = True
                    content = manager.out_of_office_message
            elif manager.condition == '휴가':
                need_to_send = True
                content = manager.day_off_message

            if need_to_send:
                if not instance.trader.last_received or instance.trader.last_received.day != now.day:
                    instance.trader.last_received = now

                    tasks.send_message_from_accounting_manager.apply_async(
                        args=[instance.trader.id, content]
                    )

        for mng in instance.trader.manager_set.all():
            str_manager_id = str(mng.id)
            prev_unread_count = instance.trader.unread_counts.get(str_manager_id, 0)
            instance.trader.unread_counts[str_manager_id] = prev_unread_count + 1
        instance.trader.save()

        send_unread_message_notification_to_managers.apply_async(args=[instance.id],
                                                                 countdown=settings.MANAGER_NOTIFICATION_DELAY)


def format_business_registration_no(number):
    return '%s-%s-%s' % (number[:3], number[3:5], number[5:])


class Document(models.Model):
    TYPES = [
        ('사업자등록증', '사업자등록증'),
        ('임대차계약서', '임대차계약서'),
        ('통장사본', '통장사본'),
    ]

    STATES = [
        ('approved', '승인'),
        ('rejected', '문서오류'),
        ('uploaded', '전송완료')
    ]

    trader = models.ForeignKey(Trader, null=True, on_delete=models.CASCADE)
    type = models.CharField(max_length=100, choices=TYPES)
    state = models.CharField(max_length=100, choices=STATES)
    file = models.FileField()
    created = models.DateTimeField(auto_now_add=True)
    processed = models.DateTimeField(null=True, blank=True)


@receiver(post_save, sender=Document)
def update_trader_activation(sender, instance, created, **kwargs):
    instance.trader.update_activation()


class Post(models.Model):
    TYPES = [
        ('post', '게시물'),
        ('notice', '공지사항'),
        ('blog', '블로그')
    ]

    writer = models.ForeignKey(User, on_delete=models.SET(ensure_deleted_user))
    title = models.CharField(max_length=1000)
    type = models.CharField(max_length=100, choices=TYPES)
    content = models.TextField()
    created = models.DateTimeField(auto_now_add=True)


class Comment(models.Model):
    writer = models.ForeignKey(User, on_delete=models.SET(ensure_deleted_user))
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    content = models.TextField()
    created = models.DateTimeField(auto_now_add=True)


class Validation(models.Model):
    VALIDATION_TYPES = [
        ('validate-email', 'validate-email'),
        ('password-reset', 'password-reset'),
    ]
    type = models.CharField(max_length=100, choices=VALIDATION_TYPES)
    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.CASCADE)
    code = models.CharField(max_length=200)
    created = models.DateTimeField(auto_now_add=True)
    validated = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return '{type} {user} {validated}'.format(type=self.type, user=self.user.username, validated=bool(self.validated))
    def is_expired(self):
        if self.type == 'validate-email':
            return False
        elif self.type == 'password-reset':
            return timezone.now() - self.created < timedelta(hours=1)

        return False

    @staticmethod
    def send_validate_email(user):
        # if user is created via fb and fb user email is not public,
        # user has no email.
        if not user.email:
            return
        validation = Validation.objects.create(type='validate-email', user=user, code=uuid.uuid4())
        try:
            send_mail('모바일택스에 가입하신 메일 주소를 확인해주세요.',

                      Template('''
안녕하세요 ${user.name}님

모바일택스에 가입해주셔서 감사합니다. 모바일택스 서비스를 원활하게 이용하기 위해서 이메일 인증이 필요합니다. 아래 주소로 이동해서 이메일을 인증해주세요.

${settings.EMAIL_VALIDATION_HOST}/validations/${validation.code}


이메일 인증을 하지 않아도 정상적으로 서비스를 이용하실 수 있지만, 비밀번호를 잊어버렸을 때나 기타 여러 가지 경우에 불편함이 있습니다.

감사합니다.


모바일택스
mobiletax.kr

                      ''').render(user=user, settings=settings, validation=validation),
                      settings.DEFAULT_FROM_EMAIL,
                      [user.email], fail_silently=False)
        except Exception as e:
            tasks.send_slackbot_critical_report(
                'Email Error',
                'send_validate_email {}'.format(user.email),
                e)
            logging.exception(e)

    @staticmethod
    def send_reset_password(user):
        # checked if user.email is valid at valications.py send_reset_password()
        validation = Validation.objects.create(type='reset-password', user=user, code=uuid.uuid4())
        try:

            send_mail('모바일택스 비밀번호를 재설정합니다..',

                      Template('''
안녕하세요 ${user.name}님

비밀번호를 잊어버리셨나요? 아래 주소로 이동하면 비밀번호를 새로 설정할 수 있습니다.

${settings.EMAIL_VALIDATION_HOST}/validations/${validation.code}


감사합니다.


모바일택스
mobiletax.kr

                      ''').render(user=user, settings=settings, validation=validation),
                      settings.DEFAULT_FROM_EMAIL,
                      [user.email], fail_silently=False)
        except Exception as e:
            tasks.send_slackbot_critical_report(
                'Email Error',
                'send_reset_password {}'.format(user.email),
                e)
            logging.exception(e)

    class ValidationFailed(Exception):
        pass


@receiver(post_save, sender=User)
def validate_email(sender, instance, created, **kwargs):
    if settings.DEBUG: return

    if created:
        Validation.send_validate_email(instance)


class FaxForm(Form):
    number = fields.CharField(max_length=20, label='팩스 번호')


class Boilerplate(models.Model):
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.SET_NULL)
    author = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET(ensure_deleted_user))
    content = models.TextField()
    notice = models.BooleanField(default=False)
    private = models.BooleanField(default=False)
    usage = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.content


class BoilerplateHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    boilerplate = models.ForeignKey(Boilerplate, on_delete=models.CASCADE)
    updated = models.DateTimeField(auto_now=True)


class ChatRoom(models.Model):
    manager = models.ForeignKey(User, on_delete=models.CASCADE)
    traders = models.ManyToManyField('Trader')
    name = models.CharField(max_length=20)
    tag = models.CharField(max_length=20)


class OneSignal(models.Model):
    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.CASCADE)
    one_signal_user_id = models.CharField(max_length=36)

    class Meta:
        unique_together = ('user', 'one_signal_user_id',)

    def __str__(self):
        return self.user.name if self.user else '-'


class Report(models.Model):
    name = models.CharField(max_length=30, default='', blank=True)
    sender = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET(ensure_deleted_user))
    registration_no = models.CharField(max_length=100, default='', blank=True)
    has_co_invester = models.BooleanField(default=False)
    traders = models.ManyToManyField('Trader', blank=True)
    trader_count = models.PositiveSmallIntegerField(default=0)
    due_date = models.DateField(null=True, blank=True)
    period_begin = models.DateField(null=True, blank=True)
    period_end = models.DateField(null=True, blank=True)
    parsed = JSONField(default=dict, blank=True)
    raw = models.TextField()
    md5_hash = models.CharField(max_length=32)
    sent = models.DateTimeField(null=True, blank=True)
    confirmed = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class ConnectedId(models.Model):
    trader = models.ForeignKey(Trader, on_delete=models.CASCADE)
    connected_id = models.CharField(max_length=50)


class Account(models.Model):
    BUSINESS_TYPES = [
        ('BK', '은행'),
        ('CD', '카드'),
        ('ST', '증권'),
        ('IS', '보험'),
    ]
    ORGANIZATIONS = [
        ('0301', 'KB카드'),
        ('0302', '현대카드'),
        ('0303', '삼성카드'),
        ('0304', 'NH카드'),
        ('0305', '비씨카드'),
        ('0306', '신한카드'),
        # ('0307', '씨티카드'),
        ('0309', '우리카드'),
        ('0311', '롯데카드'),
        ('0313', '하나카드'),
        # ('0315', '전북카드'),
        # ('0316', '광주카드'),
        # ('0320', '수협카드'),
        # ('0321', '제주카드'),
    ]
    CLIENT_TYPES = [
        ('P', '개인'),
        ('B', '법인'),
        ('A', '통합'),
    ]
    LOGIN_TYPES = [
        ('0', '인증서'),
        ('1', '아이디'),
    ]
    STATUSES = [
        ('initializing', '초기화 중'),
        ('in progress', '수행 중'),
        ('successful', '성공'),
        ('failed', '실패')
    ]

    trader = models.ForeignKey(Trader, on_delete=models.CASCADE)
    business_type = models.CharField(max_length=2, choices=BUSINESS_TYPES)
    organization = models.CharField(max_length=10, choices=ORGANIZATIONS)
    client_type = models.CharField(max_length=1, choices=CLIENT_TYPES)
    login_type = models.CharField(max_length=1, choices=LOGIN_TYPES)
    latest = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, default='initializing', choices=STATUSES)
    message = models.CharField(max_length=200, null=True, blank=True)


@receiver(post_save, sender=Account)
def save_account(sender, instance, created, **kwargs):
    if not created:
        return

    if instance.business_type == 'CD':
        init_account.apply_async(args=[instance.id])


class Card(models.Model):
    account = models.ForeignKey(Account, on_delete=models.CASCADE)
    name = models.CharField(max_length=50)

    def __str__(self):
        return f'{self.account.trader.business_name}: {self.name}'


class MemberStore(models.Model):
    name = models.CharField(max_length=50)
    corp_no = models.CharField(max_length=10)
    type = models.CharField(max_length=50)
    tel_no = models.CharField(max_length=20)
    addr = models.CharField(max_length=100)
    no = models.CharField(max_length=50, null=True, blank=True)

    def __str__(self):
        return self.name


class CardApproval(models.Model):
    card = models.ForeignKey(Card, on_delete=models.CASCADE)
    used_date = models.DateTimeField()
    card_no = models.CharField(max_length=20, null=True, blank=True)
    card_name = models.CharField(max_length=50, null=True, blank=True)
    used_amount = models.IntegerField(default=0)
    payment_type = models.CharField(max_length=1)
    installment_month = models.SmallIntegerField(default=0)
    account_currency = models.CharField(max_length=3, null=True, blank=True)
    approval_no = models.CharField(max_length=50, null=True, blank=True)
    payment_due_date = models.DateField(null=True, blank=True)
    home_foreign_type = models.CharField(max_length=1, null=True, blank=True)
    cancel_yn = models.CharField(max_length=1, null=True, blank=True)
    cancel_amount = models.IntegerField(default=0)
    vat = models.IntegerField(default=0)
    cash_back = models.IntegerField(default=0)
    krw_amt = models.IntegerField(default=0)
    member_store_name = models.CharField(max_length=50)
    member_store = models.ForeignKey(MemberStore, null=True, on_delete=models.SET_NULL)

    def __str__(self):
        return f'{self.member_store_name}: {self.used_amount}원'


class Hometax(models.Model):
    ORGANIZATION = '0002'
    STATUSES = [
        ('initializing', '초기화 중'),
        ('in progress', '수행 중'),
        ('successful', '성공'),
        ('failed', '실패')
    ]

    trader = models.ForeignKey(Trader, on_delete=models.CASCADE)
    login_type = models.CharField(max_length=1, default='1')
    username = models.CharField(max_length=50, null=True, blank=True)
    password = models.CharField(max_length=500, null=True, blank=True)
    latest = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, default='initializing', choices=STATUSES)
    message = models.CharField(max_length=200, null=True, blank=True)


@receiver(post_save, sender=Hometax)
def save_hometax(sender, instance, created, **kwargs):
    if not created:
        return

    init_business.apply_async(args=[instance.trader.id])
    init_hometax.apply_async(args=[instance.id])


class CardSales(models.Model):
    ORGANIZATION = '0323'
    STATUSES = [
        ('initializing', '초기화 중'),
        ('in progress', '수행 중'),
        ('successful', '성공'),
        ('failed', '실패')
    ]

    trader = models.ForeignKey(Trader, on_delete=models.CASCADE)
    username = models.CharField(max_length=50, null=True, blank=True)
    password = models.CharField(max_length=500, null=True, blank=True)
    latest = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, default='initializing', choices=STATUSES)
    message = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        return str(self.trader)


@receiver(post_save, sender=CardSales)
def save_card_sales(sender, instance, created, **kwargs):
    if not created:
        return

    init_card_sales.apply_async(args=[instance.id])


class CardSalesApproval(models.Model):
    card_sales = models.ForeignKey(CardSales, on_delete=models.CASCADE)
    used_date = models.DateTimeField()
    trans_type_nm = models.CharField(max_length=10, null=True, blank=True)
    card_no = models.CharField(max_length=20, null=True, blank=True)
    card_name = models.CharField(max_length=50, null=True, blank=True)
    used_amount = models.IntegerField(default=0)
    installment_month = models.SmallIntegerField(default=0)
    approval_no = models.CharField(max_length=50, null=True, blank=True)
    member_store_corp_no = models.CharField(max_length=10, null=True, blank=True)
    comm_member_store_group = models.CharField(max_length=50, null=True, blank=True)
    card_company = models.CharField(max_length=50, null=True, blank=True)


class Deposit(models.Model):
    card_sales = models.ForeignKey(CardSales, on_delete=models.CASCADE)
    account_in = models.IntegerField(default=0)
    comm_member_store_group = models.CharField(max_length=50, null=True, blank=True)
    card_company = models.CharField(max_length=50, null=True, blank=True)
    payment_account = models.CharField(max_length=20, null=True, blank=True)
    bank_name = models.CharField(max_length=50, null=True, blank=True)
    deposit_date = models.DateField()
    sales_count = models.IntegerField(default=0)
    sales_amount = models.IntegerField(default=0)
    suspense_amount = models.IntegerField(default=0)
    member_store_no = models.CharField(max_length=10, null=True, blank=True)
    other_deposit = models.IntegerField(default=0)

    def __str__(self):
        return f'{self.card_sales} {self.deposit_date} {self.card_company} 입금'


class Check(models.Model):
    INQUIRY_TYPES = [
        ('01', '전자세금계산서'),
        ('02', '위수탁 전자세금계산서'),
        ('03', '전자계산서'),
        ('04', '위수탁 전자계산서'),
    ]
    TRANSE_TYPES = [
        ('01', '매출'),
        ('02', '매입'),
    ]

    hometax = models.ForeignKey(Hometax, on_delete=models.CASCADE)
    inquiry_type = models.CharField(max_length=2, choices=INQUIRY_TYPES)
    transe_type = models.CharField(max_length=2, choices=TRANSE_TYPES)
    issue_nm = models.CharField(max_length=50, null=True, blank=True)
    tax_amt = models.IntegerField(default=0)
    issue_date = models.DateField()
    approval_no = models.CharField(max_length=100, null=True, blank=True)
    supply_value = models.IntegerField(default=0)
    reporting_date = models.DateField(null=True, blank=True)
    transfer_date = models.DateField(null=True, blank=True)
    supplier_reg_number = models.CharField(max_length=50, null=True, blank=True)
    supplier_establish_no = models.CharField(max_length=4, null=True, blank=True)
    supplier_company_name = models.CharField(max_length=100, null=True, blank=True)
    supplier_name = models.CharField(max_length=100, null=True, blank=True)
    contractor_reg_number = models.CharField(max_length=50, null=True, blank=True)
    contractor_establish_no = models.CharField(max_length=4, null=True, blank=True)
    contractor_company_name = models.CharField(max_length=100, null=True, blank=True)
    contractor_name = models.CharField(max_length=100, null=True, blank=True)
    total_amount = models.IntegerField(default=0)
    e_tax_invoice_type = models.CharField(max_length=50, null=True, blank=True)
    note = models.CharField(max_length=200, null=True, blank=True)
    receipt_or_charge = models.CharField(max_length=100, null=True, blank=True)
    email = models.EmailField(null=True, blank=True)
    email1 = models.EmailField(null=True, blank=True)
    email2 = models.EmailField(null=True, blank=True)
    rep_items = models.CharField(max_length=100, null=True, blank=True)


class WithholdingTax(models.Model):
    hometax = models.ForeignKey(Hometax, on_delete=models.CASCADE)
    issued = models.DateField(null=True, blank=True)
    personnel = models.SmallIntegerField(default=0)
    amount = models.IntegerField(default=0)


class CashSalesReceipt(models.Model):
    hometax = models.ForeignKey(Hometax, on_delete=models.CASCADE)
    used_date = models.DateTimeField()
    trans_type_nm = models.CharField(max_length=10, null=True, blank=True)
    issue_type = models.CharField(max_length=10, null=True, blank=True)
    approval_no = models.CharField(max_length=10, null=True, blank=True)
    supply_value = models.IntegerField(default=0)
    vat = models.IntegerField(default=0)
    tip = models.IntegerField(default=0)
    id_means = models.CharField(max_length=10, null=True, blank=True)
    total_amount = models.IntegerField(default=0)
    company_identity_no = models.CharField(max_length=10, null=True, blank=True)
    company_nm = models.CharField(max_length=50, null=True, blank=True)


class CashPurchaseReceipt(models.Model):
    hometax = models.ForeignKey(Hometax, on_delete=models.CASCADE)
    used_date = models.DateTimeField()
    user_nm = models.CharField(max_length=50, null=True, blank=True)
    company_nm = models.CharField(max_length=50, null=True, blank=True)
    company_identity_no = models.CharField(max_length=10, null=True, blank=True)
    trans_type_nm = models.CharField(max_length=10, null=True, blank=True)
    deduct_description = models.CharField(max_length=10, null=True, blank=True)
    member_store_name = models.CharField(max_length=50, null=True, blank=True)
    member_store_corp_no = models.CharField(max_length=10, null=True, blank=True)
    approval_no = models.CharField(max_length=10, null=True, blank=True)
    supply_value = models.IntegerField(default=0)
    vat = models.IntegerField(default=0)
    tip = models.IntegerField(default=0)
    id_means = models.CharField(max_length=10, null=True, blank=True)
    total_amount = models.IntegerField(default=0)
