from django.forms.models import ModelForm, ModelChoiceField
from django.forms.widgets import HiddenInput
from django.shortcuts import redirect
from django.utils import timezone

from accounting.models import Employee, Trader


class EmployeeForm(ModelForm):

    trader = ModelChoiceField(queryset=Trader.objects, widget=HiddenInput)

    class Meta:
        model = Employee
        fields = ['trader', 'name', 'registration_no', 'type', 'base_pay']


def create(request):
    form = EmployeeForm(request.POST)
    if form.is_valid():
        form.save()

    return redirect(request.GET.get('back', request.META['HTTP_REFERER']))


def insert_salary(request, resource_id):
    employee = Employee.objects.get(id=resource_id)
    employee.insert_salary_for_month(timezone.now().date())

    return redirect(request.GET.get('back', request.META['HTTP_REFERER']))
