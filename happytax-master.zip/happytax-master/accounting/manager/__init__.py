from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import redirect, render

from accounting.manager import traders


@staff_member_required
def index(request):
    if 'trader' in request.session:
        return redirect(traders.chat, request.session['trader'].id)

    return render(request, 'manager/index.html', locals())
