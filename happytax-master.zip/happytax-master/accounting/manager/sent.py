from django.contrib.admin.views.decorators import staff_member_required
from djangox.mako import render_to_response


@staff_member_required
def index(request):
    return render_to_response('manager/index.html', locals())