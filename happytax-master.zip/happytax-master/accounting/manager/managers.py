import json

from django.shortcuts import render, redirect
from django.urls import reverse

from accounting.models import User, Trader, Message


def index(request):
    managers = User.objects.filter(is_staff=True, is_active=True)
    return render(request, 'manager/managers.html', locals())


def management(request):
    if not request.user.is_team_leader:
        return redirect(reverse(show, args=[request.user.id]))

    return redirect(reverse(show, args=[request.user.id]))


def show(request, resource_id):
    members = User.objects.none()
    if request.user.is_team_leader:
        members = User.objects.filter(team=request.user.team)

    message = Message.objects.filter(type='income-tax-review').last()
    year = message.created.year
    month = message.created.month

    manager = User.objects.get(id=resource_id)
    traders = Trader.objects.filter(accounting_manager=manager).prefetch_related('message_set')

    return render(request, 'manager/management.html', locals())
