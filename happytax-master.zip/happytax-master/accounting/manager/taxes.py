from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import redirect
from django.utils import timezone

from accounting.models import Tax
from accounting.tax import 부가가치세, 종합소득세, 원천세


@staff_member_required
def update(request, resource_id):
    tax = Tax.objects.get(id=resource_id)
    for key in request.POST:
        if key.startswith('vat_part_'):
            tax.info[부가가치세.PARTS[key]] = int(request.POST[key])
        elif key.startswith('income_tax_part_'):
            tax.info[종합소득세.PARTS[key]] = int(request.POST[key])
        elif key.startswith('withholding_tax_part_'):
            tax.info[원천세.PARTS[key]] = int(request.POST[key])
        elif key == 'amount':
            try:
                tax.amount = int(request.POST[key])
            except ValueError:
                tax.amount = 0
        else:
            setattr(tax, key, request.POST.get(key, '0'))

    tax.calculate()

    if 'auto' in request.POST:
        if tax.type == 'vat-normal':
            tax.amount = 부가가치세(tax).차감납부할세액
        elif tax.type == 'income-tax':
            tax.amount = 종합소득세(tax).신고기한내납부할세액

    tax.save()

    tax = Tax.objects.get(id=resource_id)
    return redirect(request.META['HTTP_REFERER'])


@staff_member_required
def ready(request, resource_id):
    tax = Tax.objects.get(id=resource_id)

    tax.ready_to_report = timezone.now() if 'ready_to_report' in request.POST else None
    tax.save()

    return redirect(request.META['HTTP_REFERER'])
