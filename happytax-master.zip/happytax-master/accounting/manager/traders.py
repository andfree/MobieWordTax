import json
import re
import logging
from datetime import timedelta, datetime
from dateutil.relativedelta import relativedelta
from django.conf import settings
from django.contrib import messages as messages_module
from django.contrib.admin.views.decorators import staff_member_required
from django.core.paginator import Paginator
from django.db.models import F
from django.db.models.aggregates import Count, Sum
from django.db.models.query_utils import Q
from django.forms.models import ModelForm, ModelChoiceField
from django.forms.widgets import HiddenInput
from django.http.response import HttpResponseRedirect, JsonResponse, HttpResponse
from django.shortcuts import render, redirect
from django.template.context import RequestContext
from django.utils import timezone
from django.core.exceptions import ObjectDoesNotExist
from djangox.mako import render_to_response
from accounting.api import MessageSerializer, UserSerializer, TraderSerializer
from accounting.models import Trader, Document, User, Memo, Voucher, Salary, Attachment, Message, Boilerplate, \
    ensure_mobiletax_user
from marketing.models import TraderCoupon, Acquisition, UserCoupon
from util import client_required
from accounting.tasks import send_alimtalk


class MemoForm(ModelForm):
    trader = ModelChoiceField(Trader.objects, widget=HiddenInput)

    keys = ['업무담당자', '업무담당자 전화', '업무담당자 이메일', '카드단말기번호', '홈택스 계정', '여신금융협회 계정', '근로복지공단팩스번호']

    class Meta:
        model = Memo
        fields = ['trader', 'key', 'value']


@staff_member_required
def paid(request):
    Trader.objects.filter(cms_activated__isnull=False).exclude(activation='test').prefetch_related('memo_set').order_by(
        'created')
    return render(request, 'manager/traders/sheet.html', locals())


@staff_member_required
def index(request):
    all_traders = Trader.objects.select_related('user', 'accounting_manager').prefetch_related('manager_set').order_by(
        'created')
    new_traders = all_traders.filter(accounting_manager__isnull=True, created__gt=timezone.now() - timedelta(days=10))
    activating_traders = all_traders.filter(activation__in=['trying', 'in_review'])
    activated_traders = all_traders.filter(activation='activated')
    paid_traders = all_traders.filter(cms_activated__isnull=False).exclude(activation='test')
    my_traders = all_traders.filter(manager_set__in=[request.user])

    monthly_revenue = paid_traders.aggregate(Sum('monthly_price'))['monthly_price__sum'] or 0

    query = request.GET.get('query', 'all')
    traders = locals()[query + '_traders']
    search = request.GET.get('search', '').strip()
    if search:
        managers = User.objects.filter(name__icontains=search, is_staff=True)
        traders = traders.filter(Q(business_name__icontains=search)
                                 | Q(registration_no__icontains=search)
                                 | Q(user__name__icontains=search)
                                 | Q(manager_set__in=managers)
                                 | Q(user__phone__icontains=search))
    page_number = request.GET.get('page', 1)
    page = Paginator(traders, settings.ITEMS_PER_PAGE).page(page_number)

    all_traders = all_traders.count()
    new_traders = new_traders.count()
    activating_traders = activating_traders.count()
    activated_traders = activated_traders.count()
    paid_traders = paid_traders.count()
    my_traders = my_traders.count()

    client_set = set(request.user.client_set.values_list('id', flat=True))
    return render_to_response('manager/traders/index.html', locals(), RequestContext(request))


@client_required
@staff_member_required
def chat(request, resource_id):
    trader = Trader.objects.get(id=resource_id)
    request.session['trader'] = trader
    selectUrl = 'manager.traders.chat'

    chat_messages = trader.message_set.order_by('-created').prefetch_related('readers')[:settings.MESSAGE_SIZE]
    chat_messages = reversed(chat_messages)

    form = TraderForm(instance=trader)
    memo_form = MemoForm(initial={'trader': trader})

    boilerplates = Boilerplate.objects.filter(author=request.user)

    context = locals()
    context['Voucher'] = Voucher

    return render(request, 'manager/traders/chat_manager.html', context)


@staff_member_required
def chat_new(request, resource_id=0):
    return render(request, 'manager/traders/chat.html', locals())


@client_required
@staff_member_required
def photos(request, resource_id):
    trader = Trader.objects.get(id=resource_id)
    request.session['trader'] = trader
    selectUrl = 'manager.traders.photos'

    attachments = Attachment.objects.filter(message__trader=trader,
                                            message__sender=trader.user)

    if request.GET.get('created'):
        created = datetime.fromtimestamp(int(request.GET.get('created')) / 1000)
        attachments = attachments.filter(created=created)
    if request.GET.get('downloaded', '1') == '0':
        attachments = attachments.filter(downloaded=False)
    if request.GET.get('printed', '1') == '0':
        attachments = attachments.filter(printed=False)
    if request.GET.get('handled', '1') == '0':
        attachments = attachments.filter(handled=False)

    attachments = attachments.filter(mimetype__startswith='image')
    attachments = attachments.order_by('-created')

    page_number = request.GET.get('page', 1)
    page = Paginator(attachments, settings.ITEMS_PER_PAGE).page(page_number)

    # TODO: what are you doing?
    for attachment in page.object_list:
        if attachment.width == 0 or attachment.height == 0:
            try:
                # update width, height in overrided save() function
                attachment.save()
            except Exception as e:
                logging.exception(e)

    return render(request, 'manager/traders/images.html', locals())


@client_required
@staff_member_required
def files(request, resource_id):
    trader = Trader.objects.get(id=resource_id)
    request.session['trader'] = trader
    selectUrl = 'manager.traders.files'

    attachments = Attachment.objects.filter(message__trader=trader,
                                            message__sender=trader.user)

    if request.GET.get('downloaded', '1') == '0':
        attachments = attachments.filter(downloaded=False)
    if request.GET.get('handled', '1') == '0':
        attachments = attachments.filter(handled=False)

    attachments = attachments.exclude(mimetype__startswith='image')
    attachments = attachments.order_by('-created')

    page_number = request.GET.get('page', 1)
    page = Paginator(attachments, settings.ITEMS_PER_PAGE).page(page_number)

    return render(request, 'manager/traders/files.html', locals())


@staff_member_required
def search_messages(request, resource_id):
    trader = Trader.objects.get(id=resource_id)

    keyword = request.POST.get('keyword')
    if not keyword:
        return HttpResponse()

    chat_messages = trader.message_set.order_by('-created').filter(content__icontains=keyword)
    chat_messages = reversed(list(chat_messages))

    return JsonResponse(MessageSerializer(chat_messages, many=True).data, safe=False)


@staff_member_required
def messages(request, resource_id):
    try:
        trader = Trader.objects.get(id=resource_id)
    except ObjectDoesNotExist:
        # when trader is deleted but trader chat page still opens
        return HttpResponse('NO TRADER<br>Trader may be deleted.<br>')

    after = int(request.GET.get('after', 0))
    before = int(request.GET.get('before', 0))

    chat_messages = trader.message_set.order_by('-created').prefetch_related('readers')

    if 'unresolved' in request.GET:
        chat_messages = chat_messages.filter(type='information-request', done__isnull=True)

    if after and before:
        chat_messages = chat_messages.filter(id__gte=after, id__lt=before)
    elif after:
        chat_messages = chat_messages.filter(id__gt=after)
    elif before:
        chat_messages = chat_messages.filter(id__lt=before)[:settings.MESSAGE_SIZE]
    else:
        chat_messages = chat_messages[:settings.MESSAGE_SIZE]


    # old logic for unread count
    # for message in chat_messages:
    #     message.read_by(request.user)

    # set unread count for manager zero
    # key in unread_count should be string string expression of manager id
    for mng in trader.manager_set.all():
        if mng.id == request.user.id:
            trader.unread_counts[str(request.user.id)] = 0
            trader.save()
            break

    chat_messages = reversed(list(chat_messages))

    mobiletax_id = ensure_mobiletax_user().id
    return render(request, 'messages/messages.html', locals())


@staff_member_required
def jsonmessages(request):
    trader = Trader.objects.get(id=request.GET.get('trader'))

    after = int(request.GET.get('after', 0))
    before = int(request.GET.get('before', 0))

    chat_messages = trader.message_set.order_by('-created').prefetch_related('readers')

    if 'unresolved' in request.GET:
        chat_messages = chat_messages.filter(type='information-request', done__isnull=True)

    if after:
        chat_messages = chat_messages.filter(id__gt=after)
    elif before:
        chat_messages = chat_messages.filter(id__lt=before)[:settings.MESSAGE_SIZE]
    else:
        chat_messages = chat_messages[:settings.MESSAGE_SIZE]

    Message.read_by(request.user, chat_messages)

    chat_messages = reversed(list(chat_messages))

    return JsonResponse(MessageSerializer(chat_messages, many=True).data, safe=False)


class TraderForm(ModelForm):
    accounting_manager = ModelChoiceField(User.objects.filter(is_staff=True, is_active=True), required=False,
                                          label='기장총괄')

    class Meta:
        model = Trader
        exclude = ['user', 'registration_no', 'business_name', 'business_type', 'business_condition', 'other_vat_sales',
                   'other_vat_purchase', 'other_income_sales', 'other_income_purchase', 'other_income', 'last_received',
                   'accounting_tool', 'info', 'unread_counts']


@client_required
@staff_member_required
def edit(request, resource_id):
    trader = Trader.objects.get(id=resource_id)

    form = TraderForm(instance=trader)

    memo_form = MemoForm(initial={'trader': trader})

    context = locals()
    context['json'] = json
    context['UserSerializer'] = UserSerializer
    context['TraderSerializer'] = TraderSerializer

    return render_to_response('manager/traders/edit.html', context, RequestContext(request))


@staff_member_required
def notify(request, resource_id):
    trader = Trader.objects.get(id=resource_id)
    Document.objects.filter(trader=trader, type=request.POST['type']).update(state=request.POST['state'])
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))


@staff_member_required
def update(request, resource_id):
    data = request.POST.copy()
    if not data['monthly_price']:
        data['monthly_price'] = '0'

    trader = Trader.objects.get(id=resource_id)
    form = TraderForm(data, instance=trader)
    if form.is_valid():
        form.save()
        messages_module.add_message(request, messages_module.SUCCESS, '사업자 정보가 변경되었습니다.')

    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))


@staff_member_required
def add_client(request, resource_id):
    trader = Trader.objects.get(id=resource_id)
    request.user.client_set.add(trader)

    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))


@staff_member_required
def remove_client(request, resource_id):
    trader = Trader.objects.get(id=resource_id)
    request.user.client_set.remove(trader)

    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))


@staff_member_required
def unpair_manager_trader(request):
    if not request.user.is_superuser:
        return JsonResponse({'result': 'error', 'reason': 'NOT_SUPERUSER'})

    tid = request.GET.get('t', '')
    uid = request.GET.get('u', '')

    try:
        trader = Trader.objects.get(id=tid)
        user = User.objects.get(id=uid)
        user.client_set.remove(trader)
        return JsonResponse({'result': 'success'})
    except:
        return JsonResponse({'result': 'error', 'reason': 'INVALID_USER_OR_TRADER', 't': tid, 'u': uid})


@staff_member_required
def check_report_salary(request, resource_id):
    trader = Trader.objects.get(id=resource_id)
    if trader.report_salary is True:
        trader.report_salary = False
    else:
        trader.report_salary = True
    trader.save()

    return HttpResponseRedirect(request.META.get('HTTP_REFERER') + '#check-report-salary')


@staff_member_required
def add_memo(request, resource_id):
    trader = Trader.objects.get(id=resource_id)

    data = request.POST.copy()
    data['value'] = data['value'].replace('\r\n', '<br>').replace('\n', '<br>')
    memo_form = MemoForm(data, initial={'trader': trader})

    if memo_form.is_valid():
        memo_form.save()

        return HttpResponseRedirect(request.META.get('HTTP_REFERER'))

    else:
        return edit(request, resource_id)


@staff_member_required
def delete_memo(request, resource_id):
    Memo.objects.get(id=request.POST['memo']).delete()

    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))


@staff_member_required
def apply_coupon(request, resource_id):
    tradercoupon = TraderCoupon.objects.get(id=resource_id)
    tradercoupon.used = timezone.now()
    tradercoupon.save()

    messages_module.add_message(request, messages_module.SUCCESS, '쿠폰을 적용했습니다.')
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))


@staff_member_required
def apply_user_coupon(request, resource_id):
    coupon_id, trader_id = resource_id.split('_')
    user_coupon = UserCoupon.objects.get(id=coupon_id)
    user_coupon.used = timezone.now()
    user_coupon.save()

    TraderCoupon.objects.get_or_create(trader_id=trader_id, coupon=user_coupon.coupon, defaults={
        'created': user_coupon.created, 'used': timezone.now()
    })

    messages_module.add_message(request, messages_module.SUCCESS, '쿠폰을 적용했습니다.')
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))


@staff_member_required
def update_acquisition(request, resource_id):
    trader = Trader.objects.select_related('user__acquisition').get(id=resource_id)

    if trader.acquisition:
        trader.acquisition.source = request.POST['source']
        trader.acquisition.memo = request.POST['memo']
        trader.acquisition.save()
    else:
        Acquisition.objects.create(user=trader.user,
                                   source=request.POST['source'],
                                   memo=request.POST['memo'])

    messages_module.add_message(request, messages_module.SUCCESS, '수임경로 정보가 입력되었습니다.')

    return redirect(edit, trader.id)


@staff_member_required
def send_alimtalk_counsel(request, resource_id):
    try:
        trader = Trader.objects.get(id=resource_id)
        send_alimtalk(
            sender=settings.MOBILETAX_NUMBER,
            receiver=trader.user.phone,
            template_code=settings.ALIMTALK_CODE['V15_COUNSEL'],
            replace_msg={'user_name': trader.user}
        )
        return JsonResponse({'result': 'success'})
    except Exception as e:
        logging.exception(e)
        return JsonResponse({'result': 'error', 'message': str(e)})


@client_required
@staff_member_required
def send_boilerplate(request, resource_id):
    trader = Trader.objects.get(id=resource_id)
    boilerplate = Boilerplate.objects.get(id=request.POST.get('id'))
    Message.objects.create(trader=trader,
                           sender=ensure_mobiletax_user() if boilerplate.notice else request.user,
                           type='notice' if boilerplate.notice else 'text',
                           title='',
                           content=boilerplate.content)

    while boilerplate:
        boilerplate.usage = F('usage') + 1
        boilerplate.save(update_fields=['usage'])
        boilerplate = boilerplate.parent

    return JsonResponse({})
