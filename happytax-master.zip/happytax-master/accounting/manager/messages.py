import math
import unicodedata
import uuid
from django import forms
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import F
from django.http.response import HttpResponseRedirect, HttpResponse, JsonResponse
from django.shortcuts import redirect, render, get_object_or_404
from django.template.context import RequestContext
from django.utils import timezone
from djangox.mako import render_to_response
from accounting.models import Message, Trader, User, Attachment, Boilerplate
from accounting.util import replace_url_to_link
from accounting.manager import traders


class MessageForm(forms.ModelForm):
    sender = forms.ModelChoiceField(User.objects.all(), widget=forms.HiddenInput)

    class Meta:
        model = Message
        fields = ['sender', 'type', 'title', 'content']


@staff_member_required
def index(request):
    paid_clients = Trader.objects.filter(cms_activated__isnull=False)
    message_set = request.user.message_set.order_by('-created')
    recent_message_groups = message_set.distinct('created', 'group').filter(group__isnull=False)[:10]
    group = request.GET.get('group', '')
    if group:
        message_set = message_set.filter(group=group)

    page = int(request.GET.get('page', '1'))
    page_end = math.ceil(message_set.count() / 20) or 1

    begin = (page - 1) // 10 * 10 + 1
    end = min(begin + 10 - 1, page_end)
    pages = [i for i in range(begin, end + 1)]

    sent = message_set[(page - 1) * 20:page * 20]

    message_types = [t for t in Message.TYPES if t[0] in Message.DISPLAY_TYPES]
    return render_to_response('manager/messages/index.html', locals(), RequestContext(request))


# changed to use '/manager/traders/:tid/chat'
@staff_member_required
def chatroom(request):
    if 'trader' in request.session:
        return redirect(traders.chat, request.session['trader'].id)

    return redirect('/manager')


# changed to use '/manager/traders/:tid/photos'
@staff_member_required
def images(request):
    if 'trader' in request.session:
        return redirect(traders.photos, request.session['trader'].id)

    return redirect('/manager')


@staff_member_required
def show(request, resource_id):
    message = Message.objects.get(id=resource_id)
    return render_to_response('manager/messages/show.html', locals(), RequestContext(request))


@staff_member_required
def new(request):
    message_type = request.GET.get('type', 'empty')
    boilerplate_id = request.GET.get('boilerplate')

    if boilerplate_id:
        boilerplate = get_object_or_404(Boilerplate, id=boilerplate_id)

        form = MessageForm(initial={
            'sender': request.user,
            'type': 'notice' if boilerplate.notice else 'text',
            'title': boilerplate.content.replace('\n', ''),
            'content': boilerplate.content.replace('\n', ''),
        })
    else:
        message_template = Message.templates[message_type]

        form = MessageForm(initial={
            'sender': request.user,
            'type': message_type,
            'title': message_template['title'],
            'content': message_template['content'],
        })

    return render_to_response('manager/messages/new.html', locals(), RequestContext(request))


@staff_member_required
def create(request):
    if 'trader' not in request.POST:
        messages.add_message(request, messages.ERROR, '메세지 보낼 사업자를 선택하세요.')
        return new(request)

    trader_ids = request.POST.getlist('trader')
    if len(trader_ids) > 1:
        group = uuid.uuid4()
    else:
        group = None

    title = request.POST.get('title', '').strip().replace('\n', '<br>')
    content = request.POST.get('content', '').strip().replace('\n', '<br>')

    if not request.POST.get('boilerplate'):
        title = replace_url_to_link(title)
        content = replace_url_to_link(content)

    message_data = dict(type=request.POST['type'],
                        title=title,
                        content=content)

    uploaded_attachements = Attachment.objects.filter(id__in=[i for i in request.POST.getlist('attachments') if i])
    for i, trader in enumerate(trader_ids):
        message = request.user.message_set.create(
            trader=Trader.objects.get(id=trader),
            group=group,
            **message_data
        )
        if i == 0:
            uploaded_attachements.update(message=message)
        else:
            for a in uploaded_attachements.all():
                Attachment.objects.create(message=message, file=a.file.name, manager=request.user)

    messages.add_message(request, messages.SUCCESS, '%d명의 사업자에게 메세지를 보냈습니다.' % len(trader_ids))

    if request.POST.get('boilerplate'):
        boilerplate = Boilerplate.objects.filter(id=request.POST.get('boilerplate')).first()
        if boilerplate:
            boilerplate.usage = F('usage') + 1
            boilerplate.save(update_fields=['usage'])

    return redirect(index)


@staff_member_required
def send_text(request):
    content = request.POST.get('content', '').strip().replace('\n', '<br>')
    content = replace_url_to_link(content)

    if content == '':
        return JsonResponse({'error': 'no conent'})

    trader = Trader.objects.get(id=request.POST['trader'])
    message = request.user.message_set.create(
        trader=trader,
        type='text',
        title=content,
        content=content
    )

    return JsonResponse({'id': message.id})


@staff_member_required
def attach(request):
    request.FILES['file'].name = unicodedata.normalize('NFC', request.FILES['file'].name)
    attachment = Attachment.objects.create(message=None, file=request.FILES['file'], manager=request.user)
    return HttpResponse(attachment.id)
