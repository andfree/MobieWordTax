import datetime
import os
import tempfile

import boto3
import subprocess
from django.conf import settings
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    def add_arguments(self, parser):
        parser.add_argument('--date', type=str)

    def handle(self, *args, **options):

        datestr = options['date'] or (datetime.datetime.now() - datetime.timedelta(days=2)).strftime('%Y%m%d')
        filename = 'happytax-{}.sql.gz'.format(datestr)

        s3 = boto3.resource(
            's3',
            aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
        )
        bucket = s3.Bucket('happytax-backup')
        bucket.download_file(filename, filename)
