from django.contrib.auth.models import Group
from django.core import management
from django.core.management import BaseCommand
from accounting.models import User, Trader


class Command(BaseCommand):
    def handle(self, *args, **options):
        Group.objects.get_or_create(name='고객')
        Group.objects.get_or_create(name='매니저')
        manager_group, created = Group.objects.get_or_create(name='세무전문가')

        user1, created = User.objects.get_or_create(username='test@mobiletax.kr',
                                                    email='test@mobiletax.kr',
                                                    name='홍길동',
                                                    registration_no="7010101122333")
        user1.set_password('1234')
        user1.save()

        user2, created = User.objects.get_or_create(username='dooly@mobiletax.kr',
                                                    email='dooly@mobiletax.kr',
                                                    name='둘리',
                                                    registration_no="7010101234567")
        user2.set_password('1234')
        user2.save()

        manager, created = User.objects.get_or_create(username='manager1@mobiletax.kr',
                                                      email='manager1@mobiletax.kr',
                                                      name='매니저1',
                                                      registration_no="8010101234567")
        manager.set_password('1234')
        manager.is_staff = True
        manager.save()
        manager_group.user_set.add(manager)

        trader1, created = Trader.objects.get_or_create(user=user1,
                                                        business_name='홍김밥',
                                                        registration_no="1210012345")

        trader2, created = Trader.objects.get_or_create(user=user1,
                                                        business_name='홍갈비',
                                                        registration_no="1210054321")

        trader3, created = Trader.objects.get_or_create(user=user2,
                                                        business_name='둘리분식',
                                                        registration_no="2320054321")

        manager.client_set.add(trader1)
        manager.client_set.add(trader2)
        manager.client_set.add(trader3)