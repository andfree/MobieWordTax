import os
import django

os.environ['DJANGO_SETTINGS_MODULE'] = 'happytax.settings'
django.setup()

import unittest
import accounting
from accounting.models import load_invoices_from_esero_excel


class TestLoadInvoice(unittest.TestCase):

    def test_esero(self):
        filename = '01.매입_(주)상석통운(1358106895)_2015년_1월.xls'
        path = accounting.__path__[0] + '/../scrapper/testdata/' + filename
        load_invoices_from_esero_excel(filename, path)