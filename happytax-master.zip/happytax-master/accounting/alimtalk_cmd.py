#!/usr/bin/env python
import requests
import logging


class AlimtalkCmd:
    ALIMTALK_CLIENT_ID = 'mobiletax'
    ALIMTALK_API_KEY = 'OTI3NC0xNTM2MDQ2MjkzMjU4LTRjMmJjZGU3LTBjMTktNGQxMS1hYmNkLWU3MGMxOTVkMTE4YQ=='

    API_VERSION_1 = '1'
    API_VERSION_2 = '2'
    API_URL = 'http://api.apistore.co.kr/kko/{}/{}/' + ALIMTALK_CLIENT_ID
    API_HEADERS = {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'x-waple-authorization': ALIMTALK_API_KEY,
    }

    # 알림톡 전송결과 조회
    # ex) result = AlimtalkCmd.report('2018091310365448794401');
    @classmethod
    def report(cls, cmid):
        url = cls.API_URL.format(cls.API_VERSION_1, 'report')
        params = {'cmid': cmid}

        response = requests.get(url, headers=cls.API_HEADERS, params=params)
        return response.json()

    # sendnumber list
    # ex) sendnumberList = AlimtalkCmd.sendnumber_list()
    @classmethod
    def sendnumber_list(cls):
        url = cls.API_URL.format(cls.API_VERSION_2, 'sendnumber/list')

        response = requests.get(url, headers=cls.API_HEADERS)
        return response.json()

    # 발신번호 등록을 위한 인증번호(pincode) 요청
    # ex) AlimtalkCmd.sendnumber_request_pincode({'sendnumber':'18338332', 'comment':'모바일택스대표번호', 'pintype': 'VMS'})
    @classmethod
    def sendnumber_request_pincode(cls, params):
        url = cls.API_URL.format(cls.API_VERSION_2, 'sendnumber/save')

        response = requests.post(url, headers=cls.API_HEADERS, params=params)
        return response.json()

    # 발신번호 인증요청
    # ex) AlimtalkCmd.sendnumber_save({'sendnumber':'18338332', 'comment':'모바일택스대표번호', 'pintype': 'VMS', 'pincode': '728185'})
    @classmethod
    def sendnumber_save(cls, params):
        url = cls.API_URL.format(cls.API_VERSION_2, 'sendnumber/save')

        response = requests.post(url, headers=cls.API_HEADERS, params=params)
        return response.json()

    # approved template list
    # ex) result = AlimtalkCmd.template_list()
    @classmethod
    def template_list(cls):
        url = cls.API_URL.format(cls.API_VERSION_1, 'template/list')

        response = requests.get(url, headers=cls.API_HEADERS)
        return response.json()


# test {{{
# print(AlimtalkCmd.report('2018092714502905967602'))
# print(AlimtalkCmd.sendnumber_list())
# print(AlimtalkCmd.sendnumber_request_pincode({'sendnumber':'18338332', 'comment':'모바일택스대표번호', 'pintype': 'VMS'}))
# print(AlimtalkCmd.sendnumber_save({'sendnumber':'18338332', 'comment':'모바일택스대표번호', 'pintype': 'VMS', 'pincode': '728185'}))
# print(AlimtalkCmd.template_list())

# from alimtalk import Alimtalk
# print(Alimtalk.send('18338332', '01039202520', 'API0001', {'user_name':'정민지', 'user_id':'jungminji'}))
# print(Alimtalk.send('18338332', '01039202520', 'API0002', {'user_name':'정민지', 'trader_name':'민지닭발', 'counsel_time':'10월 01일 오전시간대'}))
# print(Alimtalk.send('18338332', '01039202520', 'API0003', {'user_name':'정민지', 'trader_name':'민지닭발', 'counseler':'미원호회계사', 'counsel_time':'10월 01일 오전시간대', 'counseler_position':'회계사', 'counseler_name':'마원호'}))
# print(Alimtalk.send('18338332', '01039202520', 'API0004', {'user_name':'정민지', 'trader_name':'민지닭발'}))
# print(Alimtalk.send('18338332', '01039202520', 'API0005', {'user_name':'정민지', 'trader_name':'민지닭발'}))
# print(Alimtalk.send('18338332', '01039202520', 'API0006', {'user_name':'정민지', 'trader_name':'민지닭발', 'mng_name':'김은주', 'mng_phone':'010-1234-1234'}))
# print(Alimtalk.send('18338332', '01039202520', 'APIV101', {'user_name':'정민지'}))
# }}}
