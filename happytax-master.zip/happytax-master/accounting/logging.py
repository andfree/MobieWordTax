import logging
import re


class Filter(logging.Filter):
    def filter(self, record):
        if record.args[0].startswith('GET /channels/messages'):
            return False

        p = re.compile(r'GET /manager/traders/\d+/messages')
        if p.match(record.args[0]):
            return False

        return True
