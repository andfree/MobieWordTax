$(document).ready(function() {
  $('body').append('<div class="print-area"></div>');
  $('.editable').editable();
});

function downloadImage(url, id) {
  var link = document.createElement('a');
  link.setAttribute('download', 'img-' + id);
  link.setAttribute('href', url);
  link.setAttribute('target', '_blank');

  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function downloadSelectedImages() {
  var checkboxes = $('.gallery input:checked');

  var ids = [];
  var delay = 0;
  for (const item of checkboxes) {
    const url = item.getAttribute('data-url');
    const id = item.getAttribute('data-id');
    ids.push(id);

    setTimeout(
      function(url, id) {
        downloadImage(url);
        console.log('[' + id + '] ' + url);
      },
      500 * ++delay,
      url,
      id
    );
  }

  setDownloaded(ids);
}

function handleSelected() {
  var checkboxes = $('.gallery input:checked');

  var ids = [];
  var delay = 0;
  for (const item of checkboxes) {
    const url = item.getAttribute('data-url');
    const id = item.getAttribute('data-id');
    ids.push(id);
  }

  setHandled(ids);
}

function printSelected() {
  const selected = $('.gallery input:checked');
  const ids = selected.toArray().map(({ dataset: { id } }) => id);
  printPhotos(ids);
}

function printPhoto(id) {
  printPhotos([id]);
}

function printPhotos(ids) {
  const $printArea = $('.print-area');
  $printArea.html('');

  for (const id of ids) {
    const {
      url,
      created,
      traderBrn,
      traderName,
      filename,
      width,
      height,
    } = getAttachmentInfos(id);
    const widthN = parseInt(width);
    const heightN = parseInt(height);

    const createDate = created.substring(0, 16);
    const formattedBrn =
      traderBrn.substring(0, 3) +
      '-' +
      traderBrn.substring(3, 5) +
      '-' +
      traderBrn.substring(5, 10);
    // handle too tall photo
    const isTooTall =
      heightN > widthN && heightN > 900 ? 'gallery-image-tootall' : '';

    const html =
      '<div class="print-page">' +
      '<div class="print-image-title">' +
      traderName +
      ' (' +
      formattedBrn +
      ')' +
      '</div>' +
      '<div class="print-image-desc">' +
      '전송일시 : ' +
      createDate +
      '<br>' +
      '파일명 : ' +
      filename +
      '<br>' +
      '</div>' +
      '<div class="print-image-box">' +
      '<img class="print-image ' +
      isTooTall +
      '" src="' +
      url +
      '">' +
      '</div>' +
      '</div>';
    $printArea.append(html);
  }

  let countLoaded = 0;
  $images = $printArea.find('img');
  $images.load(() => {
    countLoaded += 1;
    if (countLoaded >= $images.length) {
      setPrinted(ids);
      print();
    }
  });
}

function getAttachmentInfos(id) {
  const selector = '.attachment-info-' + id;
  return $(selector)[0].dataset;
}

function setPhotoStatus(target, status, newStatus) {
  const ids = Array.isArray(target) ? target : [target];
  ids.forEach(id => {
    const selector = '.btx-' + status + '[data-id=' + id + ']';
    $(selector).addClass( newStatus ? newStatus : status + 'ed');
  });

  resources.attachment.post({ ids }, status);
}

function setPrinted(target) {
  setPhotoStatus(target, 'print');
}

function setDownloaded(target) {
  setPhotoStatus(target, 'download');
}

function setHandled(target) {
  setPhotoStatus(target, 'handle', 'handled');
}

function search(url, target) {
  location.href = url + '?after=' + target;
}

$.fn.editable.defaults.mode = 'inline';
$.fn.editable.defaults.ajaxOptions = {
  type: "PATCH",
  dataType: 'json',
  headers: {
    'X-CSRFToken': '${csrf_token}'
  }
};
$.fn.editable.defaults.emptytext = '없음';
$.fn.editable.defaults.error = function(res) {
  if (res.status != 200) return res.responseJSON[Object.keys(res.responseJSON)[0]][0];
};

$.fn.editable.defaults.params = function(params) {
  var newParams = {};
  newParams[params.name] = params.value;
  return newParams;
};
$.fn.editable.defaults.showbuttons = false;
