function bindThis(func, context) {
    return function() {
        return func.apply(context, arguments)
    }
}

function ResourceTable(selector, handsontableOptions, resourceHandler, beforeSave) {
    var self = this
    this.table = new Handsontable($(selector)[0], handsontableOptions)
    this.resourceHandler = resourceHandler
    this.table.updateSettings({
        afterChange: this.saveChange.bind(this, beforeSave),
        afterSelectionByProp: bindThis(this.selectRow, this),
    })
    this.resourceHandler.ajax('get').done(function(res) {
        self.table.loadData(res.results)
    })
}

ResourceTable.prototype.showError = function(res) {
    for (var key in res.responseJSON) {
        var col = this.table.propToCol(key);
        // table.getPlugin('comments').setCommentAtCell(row, col, res.responseJSON[key])
        $(this.table.getCell(this.editingRow, col)).addClass('htInvalid')
        // console.log(res.responseJSON[key])
        // table.getCellMeta(row, col).comment = res.responseJSON[key]
    }
    $('.processing-cell').removeClass('processing-cell')
}

ResourceTable.prototype.saveChange = function(beforeSave, change, source) {
    var self = this
    if (!this.table) return
    if (source != 'edit') return
    if (change[0][1] == 'checked') return

    var row = change[0][0];
    this.editingRow = row;

    if (beforeSave) {
        var stop = !beforeSave(change, source);
        if (stop) {
            return;
        }
    }

    var tr = $(this.table.getCell(row, 0)).parent('tr')
    var data = this.table.getSourceDataAtRow(row)
    var id = this.table.getDataAtRowProp(row, 'id')

    tr.addClass('processing-cell')

    if (!id) {
        this.resourceHandler.ajax('post', data).done(function(data) {
            for (var key in data) {
                self.table.setDataAtRowProp(row, key, data[key], 'loaded')
            }
            $('.processing-cell').removeClass('processing-cell')
        }).fail(bindThis(this.showError, this))

    } else {
        var patch = {}
        var prop = change[0][1]
        if (prop.key) prop = prop.key
        patch[prop] = change[0][3]
        console.log(change, patch)
        this.resourceHandler.ajax('patch', patch, data.id).done(function(res) {
            for (var key in res) {
                self.table.setDataAtRowProp(row, key, res[key], 'loaded')
            }
            $('.processing-cell').removeClass('processing-cell')
        }).fail(bindThis(this.showError, this))
    }

}

ResourceTable.prototype.selectRow = function(r, p, r2, p2) {
    if (r == r2 && p == p2 && p == 'checked') {
        this.table.setDataAtRowProp(r, p, !this.table.getDataAtRowProp(r, p))
    }
}

ResourceTable.prototype.scrollBottom = function() {
    this.table.selectCell(this.table.countRows() - 1, 2, this.table.countRows() - 1, 2, true)
    this.table.selectCell(this.table.countRows() - 1, 2, this.table.countRows() - 1, 2, true)
    this.table.deselectCell()
}

ResourceTable.prototype.deleteSelected = function() {
    var checked = []
    var deleted = 0
    var self = this
    this.table.getData().forEach(function(row, index) {
        if (!row[0]) return

        checked.unshift(index)
        var id = self.table.getDataAtRowProp(index, 'id')

        var tr = $(self.table.getCell(index, 0)).parent('tr')
        tr.addClass('processing-cell')
        self.resourceHandler.ajax('delete', {}, id).done(function() {
            deleted ++;
            if (deleted == checked.length) {
                checked.forEach(function(i) {
                    self.table.alter('remove_row', i)
                })
            }
        }).fail(function(res) {
            $('.processing-cell').removeClass('processing-cell')
        })
    })
}


function Resource(endpoint, params, options) {
    this.endpoint = endpoint
    this.params = params
    this.options = options
}

Resource.prototype.ajax = function(method, data, resourceId) {
    var endpoint = this.endpoint
    if (resourceId) endpoint += resourceId + '/'

    if (!data) data = {}

    for (var key in this.params) {
        data[key] = this.params[key]
    }

    var settings = this.options
    settings.data = data
    settings.method = method

    if (method == 'patch') {
        settings.processData = false
        settings.contentType = 'application/json'
        settings.data = JSON.stringify(settings.data)
    }

    return $.ajax(endpoint, settings)
};

ResourceTable.prototype.updateSettings = function (settings) {
    this.table.updateSettings(settings);
};

ResourceTable.prototype.reloadData = function (data) {
    this.table.loadData(data)
}

ResourceTable.prototype.clear = function (data) {
    this.table.clear()
}

ResourceTable.prototype.destroy = function (data) {
    this.table.destroy();
};
