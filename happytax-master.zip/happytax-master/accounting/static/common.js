function separateWithComma(field) {
  removeCommas(field);
  field.val(Number(field.val()).toLocaleString());
}

function getValueWithoutCommas(value) {
  if (!value) {
    return 0;
  }

  return parseInt(value.replace(/,/gi, ''));
}

function removeCommas(field) {
  field.val(getValueWithoutCommas(field.val()));
}

// for remove manager-client pair remove button in /manager/traders
$(document).ready(function() {
  $('.pair-remove').click(function() {
    var tid = $(this).data('tid');
    var tname = $(this).data('tname');
    var uid = $(this).data('uid');
    var uname = $(this).data('uname');

    var msg =
      uname + ' 매니저를 ' + tname + '의 담당매니저에서 제외하시겠습니까?';
    if (confirm(msg)) {
      $.get(
        '/manager/traders/unpair_manager_trader',
        { t: tid, u: uid },
        function(data) {
          var selector = '.pair-' + tid + '-' + uid;
          $(selector).remove();
        }
      );
    }
  });
});

function turnLeft() {
  var image = $(gallery.currItem.container.children).not('.pswp__img--placeholder')[0];
  var rotate = parseInt(image.dataset.rotate || 0);
  rotate -= 90;
  image.dataset.rotate = rotate;
  image.style.transform = 'rotate(' + rotate + 'deg)';
}

function turnRight() {
  var image = $(gallery.currItem.container.children).not('.pswp__img--placeholder')[0];
  var rotate = parseInt(image.dataset.rotate || 0);
  rotate += 90;
  image.dataset.rotate = rotate;
  image.style.transform = 'rotate(' + rotate + 'deg)';
}
