/**
 * Created by mazicky on 2017. 1. 19..
 */
var groups = ['campaign', 'source', 'medium', 'content','term', 'platform'];
var periods = [
  moment.duration(0, 'days'),
  moment.duration(1, 'weeks'),
  moment.duration(1, 'months'),
  moment.duration(6, 'months'),
  moment.duration(1, 'years'),
];

var app = new Vue({
  // initial state
  data: {
    isLoading: false,
    periods: periods,
    periodIndex: 0,
    begin: moment().subtract(periods[0]),
    end: moment(),
    groups: groups,
    selectedGroups: groups,
  },

  methods: {
    move: function (vector) {
      if (this.isLoading) {
        return;
      }

      var period = moment.duration(this.periods[this.periodIndex]).add(moment.duration(1, 'days'));
      var begin = moment(this.begin).add(vector * period);
      var end = moment(this.end).add(vector * period);

      if (moment(this.end).add(vector * period) > moment()) {
        begin = moment().subtract(this.periods[this.periodIndex]);
        end = moment();
      }

      Vue.set(this, 'begin', begin);
      Vue.set(this, 'end', end);
      this.refresh();
    },

    setPeriod: function (periodIndex) {
      if (this.isLoading) {
        return;
      }

      this.periodIndex = periodIndex;
      Vue.set(this, 'begin', moment(this.end).add(-1 * this.periods[periodIndex]));
      this.refresh();
    },

    refresh: function () {
      this.isLoading = true;
      refresh(this.begin.format('YYYY-MM-DD'), this.end.format('YYYY-MM-DD'), this.selectedGroups, () => {
        this.isLoading = false;
      });
    }
  }
});

app.$mount('#v-campaign');
