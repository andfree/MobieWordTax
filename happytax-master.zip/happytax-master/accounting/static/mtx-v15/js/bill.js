async function readPdf(file) {
  return new Promise((resolve, reject) => {
    const fileReader = new FileReader();

    fileReader.onload = async function() {
      var typedarray = new Uint8Array(this.result);
      const pdf = await pdfjsLib.getDocument(typedarray).promise;
      const page = await pdf.getPage(1);
      const { items } = await page.getTextContent();
      const text = items.reduce((c, item) => c + item.str, '');
      resolve(text);
    };
    fileReader.onerror = reject;

    fileReader.readAsArrayBuffer(file);
  });
}

function getBankInfo(text) {
  const banks = [
    /(국세계좌)([\\d-]+)/, /(우리은행)([\d-]+)/, /(우리)([\d-]+)/, /(신한은행)([\d-]+)/, /(신한)([\d-]+)/,
    /(하나은행)([\d-]+)/, /(하나)([\d-]+)/, /(KEB하나)([\d-]+)/, /(KEB하나은행)([\d-]+)/,
    /(국민은행)([\d-]+)/, /(국민)([\d-]+)/, /(기업은행)([\d-]+)/, /(기업)([\d-]+)/, /(우체국)([\d-]+)/,
    /(시티은행)([\d-]+)/, /(농협은행)([\d-]+)/, /(농협)([\d-]+)/,
    /(수협은행)([\d-]+)/, /(수협)([\d-]+)/, /(카카오뱅)([\d-]+)/, /(케이뱅크)([\d-]+)/,
    /(제주은행)([\d-]+)/, /(부산은행)([\d-]+)/, /(대구은행)([\d-]+)/,
  ];

  const bankinfo = {};
  banks.map(b => text.match(b)).filter(b => b !== null).forEach(b => {
    bankinfo[b[1]] = b[2];
  });

  return bankinfo;
}

function parseBill(text) {
  let 부가가치세 = null;
  let 종합소득세 = null;
  let 지방소득세 = null;
  try {
    부가가치세 = text.match(/부가가치세([\d-,]+)/)[1];
  } catch (err) {
  }
  try {
    종합소득세 = text.match(/종합소득세([\d-,]+)/)[1];
  } catch (err) {
  }
  try {
    지방소득세 = text.match(/납부할세액지방소득세([\d-,]+)/)[1];
  } catch (err) {
  }

  try {
    return {
      부가가치세,
      종합소득세,
      지방소득세,
      bankinfo: getBankInfo(text),
    };
  } catch (err) {
    return {};
  }
}

async function postData(file, regno, data) {
  const { 부가가치세, 종합소득세, 지방소득세, bankinfo } = data;

  let type = '부가가치세';
  if (종합소득세) {
    type = '종합소득세';
  } else if (지방소득세) {
    type = '지방소득세';
  }

  const form = new FormData();
  form.append('file', file);
  form.append('regno', regno);
  form.append('tax', 부가가치세 || 종합소득세 || 지방소득세);
  form.append('type', type);
  form.append('bankinfo', Object.entries(bankinfo).map(([key, value]) => `${key}: ${value}`).join('\n'));

  const url = '/api2/send_bill';
  const res = await fetch(url, {
    method: 'POST',
    body: form,
    credentials: 'include',
    mode: 'no-cors',
  });
  const resjson = await res.json();
  return resjson;
}
