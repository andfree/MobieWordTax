var ArrayUtil = {
    find: function(array, predicate) {
        for (var i = 0; i < array.length; i++) {
            if (predicate(array[i])) return array[i]
        }
        return null
    },
    replaceElements: function(oldArray, newArray) {
        oldArray.splice(0, oldArray.length);
        for (var i = 0; i < newArray.length; i++) {
            oldArray.push(newArray[i])
        }
    },
    removeElement: function(array, predicate) {
        for (var i = 0; i < array.length; i++) {
            if (predicate(array[i])) {
                array.splice(i, 1);
                return true
            }
        }
        return false
    },
    updateElementsByPredicate: function(array, newArray, predicate) {
        for (var i = 0; i < newArray.length; i++) {
            for (var j = 0; j < array.length; j++) {
                if (predicate(array[j], newArray[i])) {
                    $.extend(array[j], newArray[i])
                    continue
                }
            }
        }
    },
    updateElementsById: function(array, newArray) {
        ArrayUtil.updateElementsByPredicate(array, newArray, function(a, b) {return a.id == b.id})
    },
    equals: function(array, newArray) {
        if (array.length != newArray.length) return false

        for (var i = 0; i < array.length; i++) {
            if (array[i] != newArray[i]) return false
        }
        return true
    }
};

function Resource(endpoint, params, options) {
    this.endpoint = endpoint;
    this.params = params;
    this.options = options || {}
}

Resource.prototype.ajax = function(method, data, resourceId, action) {
    var path = this.buildPath(resourceId, action)

    if (!data) data = {};

    for (var key in this.params) {
        data[key] = this.params[key]
    }

    var settings = Object.create(this.options);
    settings.data = data;
    settings.method = method;
    settings.contentType = 'application/json';

    if (method != 'get') {
        settings.processData = false;
        settings.data = JSON.stringify(settings.data)
    }
    return $.ajax(path, settings)
};


var methods = ['get', 'post', 'put', 'patch', 'delete'];
methods.forEach(function(e) {
    Resource.prototype[e] = function(data, resourceId, action) {
        return this.ajax(e, data, resourceId, action)
    }
});

Resource.prototype.buildPath = function(resourceId, action) {
    var path = this.endpoint
    if (resourceId) path += String(resourceId) + '/';
    if (action) path += action + '/';
    return path
}

Resource.prototype.loadPaginator = function(params, target, propName, clazz, callback) {
    var self = this;
    this.get(params).done(function(res) {
        if (!target[propName]) {
            target[propName] = new Paginator()
        }
        target[propName].update(res, clazz);
        if (callback) {
            callback()
        }
    });
};


function Paginator(modelClass, params, resourceId, action) {
    this.modelClass = modelClass;
    this.resetParams(params, resourceId, action)
}

Paginator.prototype.resetParams = function(params, resourceId, action) {
    this.count = 0;
    this.next = this.modelClass.resource.buildPath(resourceId, action) + '?' + $.param(params);
    this.prev = null;
    this.objects = [];
    this.loading = false;
    this.loadedPages = 0;
}

Paginator.prototype.loadNext = function() {
    if (!this.next) return;
    var self = this;
    this.loading = true;
    return $.get(this.next).done(function(res) {
        self.update(res, true);
        self.loading = false;
        self.loadedPages++;

    }).fail(function() {
        self.loading = false;
    })
};

Paginator.prototype.loadAll = function(callback) {
    var self = this;
    var loadNextCallback = function(res) {
        if (res.next) {
            self.loadNext(loadNextCallback)
        } else if (callback) {
            callback(res)
        }
    }
    this.loadNext().done(loadNextCallback)
}

Paginator.prototype.update = function(res, append) {
    $.extend(this, {
        count: res.count,
        next: res.next,
        prev: res.previous
    });

    var objects;
    var self = this;
    if (this.modelClass != undefined) {
        objects = res.results.map(function(e) { return new self.modelClass(e)})
    } else {
        objects = res.results
    }

    if (append) {
        this.objects = this.objects.concat(objects)
    } else {
        this.objects = res.results
    }
};

var resources = {
    attachment: new Resource('/api/v1/attachments/'),
}

function Model() {
    $.extend(this, data);
}

Model.prototype.getPlainData = function() {
    var data = {}
    for (var key in this) {
        if (!key.startsWith('$') && typeof(this[key]) != 'function') data[key] = this[key]
    }
    return data
}

Model.prototype.update = function(data) {
    for (var key in data) {
        Vue.set(this, key, data[key])
    }
}

Model.prototype.save = function() {
    if (this.id) {
        return this.constructor.resource.patch(this, this.id)
    }
    return this.constructor.resource.post(this.getPlainData()).done(function(res) {
        $.extend(this, res)
    }.bind(this))
}

Model.prototype.delete = function() {
    return this.constructor.resource.delete(this, this.id)
}

function initModel(modelClass, resource) {
    $.extend(modelClass.prototype, Model.prototype)
    modelClass.resource = resource
    modelClass.resource.ajax('options').done(function(res) {
        modelClass.schema = res
    })
}
