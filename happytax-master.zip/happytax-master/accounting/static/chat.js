function ChatRoom(loadUrl, scrollView, messageTemplate) {
  this.loadUrl = loadUrl;
  this.scrollView = scrollView;
  this.messageTemplate = messageTemplate;
  this.messageFilter = '';
  this.noPreviousMessages = false;
  this.loading = false;

  var self = this;

  this.scrollView.scroll(function() {
    if ($(this).scrollTop() >= 10 || self.noPreviousMessages) return;

    self.loadMessages('before', false);
  });

  //this.scrollView.on('touchend', function() {
  //    $('.refresh-indicator').removeClass('scrolling')
  //    shouldRefresh = $('.refresh-indicator').is(':visible') && $(this).scrollTop() < 35
  //    if (shouldRefresh) {
  //        chatroom.loadMessages('before')
  //        shouldRefresh = false
  //    } else if ($('.refresh-indicator').is(':visible')) {
  //        var scrollTop = $(this).scrollTop()
  //        $('.refresh-indicator').hide()
  //        $(this).scrollTop(scrollTop - $('.refresh-indicator').outerHeight())
  //    }
  //})
  //this.scrollView.on('touchcancel', function() {
  //    $('.refresh-indicator').removeClass('scrolling')
  //    shouldRefresh = $('.refresh-indicator').is(':visible') && $(this).scrollTop() < 35
  //    if (shouldRefresh) {
  //        chatroom.loadMessages('before')
  //        shouldRefresh = false
  //    } else if ($('.refresh-indicator').is(':visible')) {
  //        var scrollTop = $(this).scrollTop()
  //        $('.refresh-indicator').hide()
  //        $(this).scrollTop(scrollTop - $('.refresh-indicator').outerHeight())
  //    }
  //})
  //this.scrollView.on('touchmove', function() {
  //    shouldRefresh = $('.refresh-indicator').is(':visible') && $(this).scrollTop() < 35
  //})
  //this.scrollView.on('touchstart', function() {
  //    $('.refresh-indicator').addClass('scrolling')
  //    var scrollTop = $(this).scrollTop()
  //    if (scrollTop < 20) {
  //        $('.refresh-indicator').show()
  //        $('.refresh-indicator').removeClass('loading')
  //        $('.refresh-indicator').addClass('pull-to-refresh')
  //        $(this).scrollTop(scrollTop + $('.refresh-indicator').outerHeight())
  //    }
  //})

  return this;
}

ChatRoom.prototype.loadMessages = function(
  before_or_after,
  scrollBottom,
  reverse
) {
  if (this.loading) return;

  this.loading = true;
  var self = this;
  var param = '';
  //    var upper = this.getMessageId('.chat-message:first')
  //    var lower = this.getMessageId('.chat-message:last')
  //    if (upper < lower) {
  //        var temp = lower
  //        lower = upper
  //        upper = temp
  //    }

  var firstMsgId = this.getMessageId('.chat-message:first');
  var lastMsgId = this.getMessageId('.chat-message:last');

  var insertMethod = 'append';
  if (before_or_after === 'before') {
    param = '?before=' + firstMsgId;
    insertMethod = 'prepend';
  } else if (before_or_after === 'after') {
    param = '?after=' + lastMsgId;
  } else {
    param = '?';
    $('.chat-message').remove();
  }

  if (this.messageFilter) {
    param = param + '&' + this.messageFilter;
  }

  $('.refresh-indicator')
    .addClass('loading')
    .removeClass('pull-to-refresh');

  $.getJSON(
    this.loadUrl + param,
    $.proxy(this.displayMessages, this, insertMethod, scrollBottom, reverse)
  ).always(function () {
    self.loading = false;
  });
};

ChatRoom.prototype.displayMessages = function(
  insertMethod,
  scrollBottom,
  reverse,
  messages
) {
  $('.refresh-indicator').hide();

  if (insertMethod == 'append') messages.reverse();

  if (reverse) {
    if (insertMethod === 'append') {
      insertMethod = 'prepend';
    } else {
      insertMethod = 'append';
    }
  }

  var height = $('.chat-messages').height();
  for (var i = 0; i < messages.length; i++) {
    $('.chat-messages')[insertMethod](
      self.messageTemplate({ message: messages[i] })
    );

    if (scrollBottom) {
      this.scrollView.scrollTop(this.scrollView[0].scrollHeight);
    } else {
      this.scrollView.scrollTop($('.chat-messages').height() - height);
    }
  }

  $('.chat-messages').prepend($('.refresh-indicator'));
};

ChatRoom.prototype.setMessageFilter = function(messageFilter) {
  this.messageFilter = messageFilter;
};

ChatRoom.prototype.getMessageId = function(selector) {
  if ($(selector).length) {
    return $(selector)[0].id.split('-')[1];
  }
  return 0;
};
