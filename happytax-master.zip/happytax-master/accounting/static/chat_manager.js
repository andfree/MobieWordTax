function ChatRoom() {
  this.messageFilter = '';

  return this;
}

ChatRoom.prototype.loadMessagesFrom = function(
  get_url,
  target
) {
  $('.refresh-indicator').addClass('scrolling');

  var insertMethod = 'append';
  var param = '?after=' + target;

  $.get(get_url + param, function(res) {
    $('.chat-messages').css('visibility', 'hidden');
    $('.chat-messages')[insertMethod](res);
    $('.scroll-wrapper').scrollTop(6);
    $('.chat-messages').css('visibility', 'visible');
    $('.refresh-indicator').removeClass('scrolling');
  });
};

ChatRoom.prototype.loadMessages = function(
  before_or_after,
  get_url,
  scrollBottom
) {
  var param = '';
  var insertMethod = 'append';
  if (before_or_after == 'before') {
    param = '?before=' + this.getMessageId('.chat-message:first');
    insertMethod = 'prepend';
  } else if (before_or_after == 'after') {
    param = '?after=' + this.getMessageId('.chat-message:last');
  } else {
    param = '?';
    $('.chat-message').remove();
  }

  if (this.messageFilter) {
    param = param + '&' + this.messageFilter;
  }

  $('.refresh-indicator')
    .addClass('loading')
    .removeClass('pull-to-refresh');

  $.get(get_url + param, function(res) {
    $('.refresh-indicator').hide();

    if (res.trim().length == 0) return;

    var height = $('.chat-messages').height();
    $('.chat-messages')[insertMethod](res);
    $('.chat-messages').prepend($('.refresh-indicator'));

    if (scrollBottom) {
      $('.scroll-wrapper').scrollTop($('.scroll-wrapper')[0].scrollHeight);
      $('.chat-messages img:not(.loaded)').load(function() {
        $('.scroll-wrapper').scrollTop($('.scroll-wrapper')[0].scrollHeight);
        this.className = 'loaded';
      });
    } else {
      $('.scroll-wrapper').scrollTop($('.chat-messages').height() - height);
    }
  });
};

ChatRoom.prototype.loadMessagesUntilUpper = function(get_url, upper) {
  var param =
    '?before=' + this.getMessageId('.chat-message:first') + '&after=' + upper;

  if (this.messageFilter) {
    param = param + '&' + this.messageFilter;
  }

  $('.refresh-indicator')
    .addClass('loading')
    .removeClass('pull-to-refresh');

  return $.get(get_url + param, function(res) {
    $('.refresh-indicator').hide();

    if (res.trim().length === 0) return;

    $('.chat-messages').prepend(res);
    $('.chat-messages').prepend($('.refresh-indicator'));
  });
};

ChatRoom.prototype.setMessageFilter = function(messageFilter) {
  this.messageFilter = messageFilter;
};

ChatRoom.prototype.getMessageId = function(selector) {
  if ($(selector).length) {
    return $(selector)[0].id.split('-')[1];
  }
  return 0;
};
