(function() {
    function getAndroidVersion() {
        var ua = navigator.userAgent.toLowerCase()
        var match = ua.match(/android\s([0-9\.]*)/)
        return match ? match[1] : false
    }

    $(document).ready(function () {
        // Kitkat 이상 버전의 경우 javascript interface를 통해 openFileChooser를 호출한다.
        // Dropzone의 clickable 속성을 이용하여 File Chooser가 두 번 열리지 않도록 방지한다.

        var androidVersion = parseFloat(getAndroidVersion())
        if (window.Android && androidVersion >= 4.4) {
            Dropzone.prototype.defaultOptions.clickable = false

            $('.dropzone').on('click', function () {
                window.Android.openFileChooser($(this).attr('action'), JSON.stringify($(this).serializeArray()));
            })

        }
    })
}).call(this)
