import re
import logging, traceback, json
from datetime import datetime, timedelta
import slackclient
from decimal import Decimal, ROUND_DOWN
from django.conf import settings
from urllib.parse import quote, parse_qs, urlencode
import base64
from urllib.parse import urlparse

from django.db import models
from django.db.models.aggregates import Count
from django.db.models.expressions import Case, When
from django.shortcuts import redirect
from django.utils import timezone
from django.utils.deprecation import MiddlewareMixin


def get_client_ip(request):
    from ipware import get_client_ip
    client_ip, is_routable = get_client_ip(request)
    return client_ip or ''


class SlackHandler(logging.Handler):
    res = ''

    def handle(self, record):
        if settings.COLLECT_ERROR_LOG and record.levelno >= logging.ERROR:
            try:
                msg = '```%s' % record.getMessage()
                if record.exc_info:
                    exc_type, exc_value, exc_traceback = record.exc_info
                    msg += ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
                msg += '```'
                sc = slackclient.SlackClient(settings.SLACK_BOT_TOKEN)

                if SlackHandler.res and SlackHandler.res['msg'] == msg:
                    now = datetime.now()
                    SlackHandler.res['ts_history'] += '\n' + now.strftime('%Y-%m-%d %H:%M:%S')
                    sc.api_call('chat.update', channel=SlackHandler.res['channel'], text= msg + SlackHandler.res['ts_history'], ts=SlackHandler.res['ts'])
                    if (now - datetime.fromtimestamp(float(SlackHandler.res['ts']))).seconds // 60 >= 3 :
                        SlackHandler.res = ''
                else:
                    res_data = sc.api_call('chat.postMessage', channel='#code', text=msg)
                    SlackHandler.res = {'msg': res_data['message']['text'],
                                        'channel':res_data['channel'],
                                        'ts':res_data['ts'],
                                        'ts_history': '\n *Timestamp History* \n' + datetime.fromtimestamp(float(res_data['ts'])).strftime('%Y-%m-%d %H:%M:%S')}
            except Exception as e:
                logging.warning(e, exc_info=e)


class DeviceMiddleware(MiddlewareMixin):
    def process_request(self, request):
        http_user_agent = request.META.get('HTTP_USER_AGENT', '')
        if 'MobileTaxAndroid' in http_user_agent:
            request.user_client = 'mtx-android'
            request.user_tracking_ex = 'mtx'
        elif 'MobileTaxIos' in http_user_agent:
            request.user_client = 'mtx-ios'
            request.user_tracking_ex = 'mtx'
        elif 'Android' in http_user_agent:
            request.user_client = 'mobile-android'
            request.user_tracking_ex = 'mw'
        elif 'iPhone' in http_user_agent:
            request.user_client = 'mobile-ios'
            request.user_tracking_ex = 'mw'
        else:
            request.user_client = 'desktop-web'
            request.user_tracking_ex = 'dw'

        request.user_tracking_via = 'dr' if '@' in request.user.username else 'fb'
        request.is_mtx_app = 'mtx-' in request.user_client
        request.is_mobile_web = 'mobile-' in request.user_client
        try:
            request.mtx_app_version = http_user_agent[http_user_agent.index('MobileTax'):]
        except:
            request.mtx_app_version = ''

        one_signal_user_id = request.COOKIES.get('one_signal_user_id')
        if one_signal_user_id and\
                (one_signal_user_id != request.session.get('one_signal_user_id') or
                 request.user.is_authenticated != request.session.get('login')):
            request.session['one_signal_user_id'] = one_signal_user_id
            request.session['login'] = request.user.is_authenticated

            from accounting.models import OneSignal
            user = request.user if request.user.is_authenticated else None
            try:
                OneSignal.objects.update_or_create(one_signal_user_id=one_signal_user_id, defaults={'user': user})
            except:
                pass

        if request.user.is_authenticated:

            try:
                request.user.acquisition
            except:
                record_acquisition(request, request.user)

            from accounting.models import Device
            try:
                device, created = request.user.device_set.get_or_create(user_agent=http_user_agent, defaults={
                    'login_ip_address': get_client_ip(request)
                })
            except Device.MultipleObjectsReturned:
                request.user.device_set.filter(user_agent=http_user_agent).delete()
                device, created = request.user.device_set.get_or_create(user_agent=http_user_agent, defaults={
                    'login_ip_address': get_client_ip(request)
                })

            if device.login_ip_address != get_client_ip(request):
                device.login_ip_address = get_client_ip(request)
                device.save()

    def process_response(self, request, response):
        user = getattr(request, 'user', None)
        if user and user.is_authenticated:
            if not request.COOKIES.get('login'):
                response.set_cookie('login', request.user.id, domain=settings.SESSION_COOKIE_DOMAIN)
        else:
            if request.COOKIES.get('login'):
                response.delete_cookie('login')

        # 회원가입과 직접적인 관련이 있는 리퍼러를 기록하기 위해 현재 호스트와 다른 외부 리퍼러로 갱신한다.
        referrer = request.META.get('HTTP_REFERER')
        if referrer:
            if not request.COOKIES.get('referrer'):
                response.set_cookie('referrer', referrer)
            elif urlparse(referrer).netloc != request.META.get('HTTP_HOST', ''):
                # 예외로 social 라이브러리를 통해 회원가입한 경우에는 외부 리퍼러라고 볼 수 없다. 가입 시점에만 user.is_new가 True이다.
                user = getattr(request, 'user', None)
                if user is None or not getattr(user, 'is_new', False):
                    response.set_cookie('referrer', referrer)

        utm_codes = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term']
        for utm_code in utm_codes:
            response.delete_cookie(utm_code)

        return response


def record_acquisition(request, user):
    from marketing.models import Acquisition

    utm_codes = get_utm(request)
    if 'android_referrer' in request.COOKIES:
        utm_codes.update(parse_qs(request.COOKIES['android_referrer']))
    try:
        Acquisition.objects.create(user=user,
                                   referrer=request.COOKIES.get('referrer') or '',
                                   campaign=utm_codes.get('utm_campaign'),
                                   source=utm_codes.get('utm_source'),
                                   medium=utm_codes.get('utm_medium'),
                                   content=utm_codes.get('utm_content'),
                                   term=utm_codes.get('utm_term'),
                                   memo=str(utm_codes)
                                   )
    except Exception as e:
        logging.exception(e)


def handle_entity(request):
    # 이미 복구된 경우
    if request.GET.get('link'):
        return None

    from accounting.models import Entity

    user_agent = request.META.get('HTTP_USER_AGENT', '')
    index = user_agent.find(')')
    length = index if index == -1 else index + 1
    platform = user_agent[:length].replace('; wv', '')
    ip_address = get_client_ip(request)

    # 광고를 통해 방문한 경우
    utm_codes = {'utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'}
    if set(request.GET.keys()) & utm_codes:
        utm = get_utm(request)
        Entity.objects.create(platform=platform, ip_address=ip_address, utm=utm)
        return None

    # UTM이 이미 존재할 때는 복구하지 않는다.
    if set(request.COOKIES.keys()) & utm_codes:
        try:
            utm_source = base64.b64decode(request.COOKIES.get('utm_source').encode('ascii')).decode()
        except:
            utm_source = request.COOKIES.get('utm_source', '')

        if utm_source.lower() != 'google-play':
            return None

    # 마지막에 접속한 기록을 찾아 UTM을 복구한다.
    entity = Entity.objects.filter(platform=platform,
                                   ip_address=ip_address,
                                   created__gt=timezone.now() - timedelta(days=1)).order_by('-created').first()

    if entity:
        entity.utm.update(request.GET)
        entity.utm.update({'link': 1})
        return redirect('{}?{}'.format(request.path, urlencode(entity.utm, doseq=True)))

    return None


def get_utm(request):
    def get_value(code):
        if code in request.GET:
            return request.GET[code]

        if code in request.COOKIES:
            try:
                return base64.b64decode(request.COOKIES[code]).decode() if request.COOKIES[code] else None
            except Exception as e:
                logging.warning(e, exc_info=True)

        return None

    codes = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term']
    return {code: get_value(code) for code in codes if get_value(code)}


def get_utm_string(request):
    utm = get_utm(request)
    return json.dumps(utm)[1:-1]


def detect_campaign(request):
    return get_utm(request).get('utm_content', '')


def app_download_link(request, platform):
    ios_download_url = 'https://itunes.apple.com/kr/app/apple-store/id1040046595?mt=8&pt=117812229'
    ios_campaign_url = 'https://itunes.apple.com/kr/app/apple-store/id1040046595?pt=117812229&ct={campaign}&mt=8'
    android_download_url = 'https://play.google.com/store/apps/details?id=kr.mobiletax&hl=ko'

    if request.user_client == 'desktop-web':
        return ios_download_url if platform == 'ios' else android_download_url
    else:
        query_string = request.META.get('QUERY_STRING', '')
        referer = request.META.get('HTTP_REFERER', '')
        if query_string:
            pass
        elif referer:
            query_string = process_referer_to_qs(referer)
        else:
            query_string = 'download_via=landing'

        if platform == 'ios':
            campaign = detect_campaign(request)
            if not campaign:
                return ios_download_url

            return ios_campaign_url.format(campaign=campaign)

        deep_link = quote('https://mobiletax.kr/appmain?' + query_string, safe='')
        android_params = 'apn=kr.mobiletax&amv=29'
        dynamic_link = 'https://q2849.app.goo.gl/?link={deep_link}&{android_params}'
        return dynamic_link.format(deep_link=deep_link, android_params=android_params)


def process_referer_to_qs(referer):
    url = urlparse(referer)
    netloc_path = url.netloc + url.path
    query = parse_qs(url.query)

    search_engines = {
        ('naver.com', 'query'): 'naver',
        ('daum.net/search', 'q'): 'daum',
        ('daum.net/nate', 'q'): 'nate',
        ('zum.com', 'query'): 'zum',
        ('google.com', ''): 'google',
        ('google.co.kr', ''): 'google',
        ('bing.com', ''): 'bing',
        ('yahoo.com', ''): 'yahoo',
    }

    utm = {}
    for (pattern, param) in search_engines:
        search_keyword = query.get(param, '') if param else ''
        if pattern in netloc_path and (not param or search_keyword):
            source = search_engines.get((pattern, param))
            utm.update({ 'utm_source': source, 'utm_medium': 'organic' })
            if search_keyword:
                utm.update({ 'utm_term': search_keyword })
            break

    if not utm.get('utm_source', ''):
        # TODO: parse url domain to topl
        domain = url.netloc
        utm.update({ 'utm_source': domain, 'utm_medium': 'referral' })

    qs = urlencode(utm, doseq=True)
    return qs


class VersionMiddleware(MiddlewareMixin):
    def process_request(self, request):
        if request.path.startswith('/v2'):
            request.version_prefix = 'v2/'
        else:
            request.version_prefix = ''


def floor(number, places=0):
    # number가 Truncation error로 인해 기대하는 값보다 아주 조금 작을 수 있다. 이 차이를 무시하고 버림을 하는 순간 오차가 커지기 때문이 아주 작은 수를 더해준다.
    EPSILON = Decimal(10**-7)

    number = Decimal(number) + EPSILON
    factor = Decimal(10**places)

    number *= factor
    number = number.to_integral_value(ROUND_DOWN)
    number /= factor
    return number


def floor_decorator(places=0):
    def _decorated(func):
        def _floor(*args, **kwargs):
            return floor(func(*args, **kwargs), places)

        return _floor

    return _decorated


def case_count(**kwargs):
    return Count(Case(When(then=1, **kwargs), output_field=models.IntegerField()))


def history_back(request, default_path='/'):
    referer = urlparse(request.META.get('HTTP_REFERER', ''))
    path = default_path if referer.hostname != request.META['HTTP_HOST'] else referer.path
    ignores = [
        '/traders/welcome', '/messages'
    ]
    path = default_path if path in ignores else path
    return path


def redirect_with_qs(url, request):
    query_part = ('?' + request.META['QUERY_STRING']) if request.META['QUERY_STRING'] else ''
    return redirect(url + query_part)


allowed_ips = [
    '10.0.2.2',  # local dev
    '60.196.74.227',  # mobiletax office public ip
    '172.31.23.40',  # private ip of www-v3
    '52.78.78.106'  # public ip of www-v3
]


def is_allowed_ip(request):
    remote_addr = get_client_ip(request)
    return remote_addr in allowed_ips


def replace_url_to_link(text):
    urls = re.compile(r"((https?):((//)|(\\\\))+[\w\d:#@%/;$()~_?\+-=\\\.&]*)", re.MULTILINE|re.UNICODE)
    return urls.sub(r'<a href="\1" target="_blank">\1</a>', text)
