class 일반과세자신고서:
    def __init__(self, 데이터):
        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.매출과세세금계산서발급금액 = 데이터.pop(15)
        self.매출과세세금계산서발급세액 = 데이터.pop(13)
        self.매출과세매입자발행세금계산서금액 = 데이터.pop(13)
        self.매출과세매입자발행세금계산서세액 = 데이터.pop(13)
        self.매출과세카드현금발행금액 = 데이터.pop(15)
        self.매출과세카드현금발행세액 = 데이터.pop(15)
        self.매출과세기타금액 = 데이터.pop(13)
        self.매출과세기타세액 = 데이터.pop(13)
        self.매출영세율세금계산서발급금액 = 데이터.pop(13)
        self.매출영세율기타금액 = 데이터.pop(15)
        self.매출예정누락합계금액 = 데이터.pop(13)
        self.매출예정누락합계세액 = 데이터.pop(13)
        self.예정누락매출세금계산서금액 = 데이터.pop(13)
        self.예정누락매출세금계산서세액 = 데이터.pop(13)
        self.예정누락매출과세기타금액 = 데이터.pop(13)
        self.예정누락매출과세기타세액 = 데이터.pop(13)
        self.예정누락매출영세율세금계산서금액 = 데이터.pop(13)
        self.예정누락매출영세율기타금액 = 데이터.pop(13)
        self.예정누락매출명세합계금액 = 데이터.pop(13)
        self.예정누락매출명세합계세액 = 데이터.pop(13)
        self.매출대손세액가감세액 = 데이터.pop(13)
        self.과세표준금액 = 데이터.pop(15)
        self.산출세액 = 데이터.pop(15)
        self.매입세금계산서수취일반금액 = 데이터.pop(15)
        self.매입세금계산서수취일반세액 = 데이터.pop(13)
        self.매입세금계산서수취고정자산금액 = 데이터.pop(13)
        self.매입세금계산서수취고정자산세액 = 데이터.pop(13)
        self.매입예정누락합계금액 = 데이터.pop(13)
        self.매입예정누락합계세액 = 데이터.pop(13)
        self.예정누락매입신고세금계산서금액 = 데이터.pop(13)
        self.예정누락매입신고세금계산서세액 = 데이터.pop(13)
        self.예정누락매입기타공제금액 = 데이터.pop(13)
        self.예정누락매입기타공제세액 = 데이터.pop(13)
        self.예정누락매입명세합계금액 = 데이터.pop(13)
        self.예정누락매입명세합계세액 = 데이터.pop(13)
        self.매입자발행세금계산서매입금액 = 데이터.pop(13)
        self.매입자발행세금계산서매입세액 = 데이터.pop(13)
        self.매입기타공제매입금액 = 데이터.pop(13)
        self.매입기타공제매입세액 = 데이터.pop(13)
        self.그밖의공제매입명세합계금액 = 데이터.pop(13)
        self.그밖의공제매입명세합계세액 = 데이터.pop(13)
        self.매입세액합계금액 = 데이터.pop(15)
        self.매입세액합계세액 = 데이터.pop(13)
        self.공제받지못할매입합계금액 = 데이터.pop(13)
        self.공제받지못할매입합계세액 = 데이터.pop(13)
        self.공제받지못할매입금액 = 데이터.pop(13)
        self.공제받지못할매입세액 = 데이터.pop(13)
        self.공제받지못할공통매입면세사업금액 = 데이터.pop(13)
        self.공제받지못할공통매입면세사업세액 = 데이터.pop(13)
        self.공제받지못할대손처분금액 = 데이터.pop(13)
        self.공제받지못할대손처분세액 = 데이터.pop(13)
        self.공제받지못할매입명세합계금액 = 데이터.pop(13)
        self.공제받지못할매입명세합계세액 = 데이터.pop(13)
        self.차감합계금액 = 데이터.pop(15)
        self.차감합계세액 = 데이터.pop(13)
        self.환급세액 = 데이터.pop(13)
        self.그밖의경감공제세액 = 데이터.pop(15)
        self.그밖의경감공제명세합계세액 = 데이터.pop(15)
        self.경감공제합계세액 = 데이터.pop(13)
        self.예정신고미환급세액 = 데이터.pop(13)
        self.예정고지세액 = 데이터.pop(13)
        self.사업양수자의대리납부기납부세액 = 데이터.pop(13)
        self.매입자납부특례기납부세액 = 데이터.pop(13)
        self.가산세액계 = 데이터.pop(13)
        self.차감납부할세액 = 데이터.pop(15)
        self.과세표준명세수입금액제외금액 = 데이터.pop(13)
        self.과세표준명세합계수입금액 = 데이터.pop(15)
        self.면세사업수입금액제외금액 = 데이터.pop(13)
        self.면세사업합계수입금액 = 데이터.pop(15)
        self.계산서교부금액 = 데이터.pop(15)
        self.계산서수취금액 = 데이터.pop(15)
        self.환급구분코드 = 데이터.pop(2)
        self.은행코드 = 데이터.pop(3)
        self.계좌번호 = 데이터.pop(20)
        self.총괄납부승인번호 = 데이터.pop(9)
        self.은행지점명 = 데이터.pop(30)
        self.폐업일자 = 데이터.pop(8)
        self.폐업사유 = 데이터.pop(3)
        self.기한후여부 = 데이터.pop(1)
        self.실차감납부할세액 = 데이터.pop(15)
        self.일반과세자구분 = 데이터.pop(1)
        self.조기환급취소구분 = 데이터.pop(1)
        self.수출기업수입납부유예 = 데이터.pop(15)
        self.신용카드업자의대리납부기납부세액 = 데이터.pop(13)
        self.소규모개인사업자부가가치세감면세액 = 데이터.pop(13)
        데이터.pop(2)

    def to_json(self):
        parsed = self.__dict__.copy()
        return parsed


class 간이과세자신고서:
    def __init__(self, 데이터):
        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.과표과세부가가치율코드1 = 데이터.pop(2)
        self.과표과세금액1 = 데이터.pop(13)
        self.과표과세부가가치율1 = 데이터.pop(5)
        self.과표과세세액1 = 데이터.pop(13)
        self.과표과세부가가치율코드2 = 데이터.pop(2)
        self.과표과세금액2 = 데이터.pop(13)
        self.과표과세부가가치율2 = 데이터.pop(5)
        self.과표과세세액2 = 데이터.pop(13)
        self.과표과세부가가치율코드3 = 데이터.pop(2)
        self.과표과세금액3 = 데이터.pop(13)
        self.과표과세부가가치율3 = 데이터.pop(5)
        self.과표과세세액3 = 데이터.pop(13)
        self.과표과세부가가치율코드4 = 데이터.pop(2)
        self.과표과세금액4 = 데이터.pop(13)
        self.과표과세부가가치율4 = 데이터.pop(5)
        self.과표과세세액4 = 데이터.pop(13)
        self.과표영세율코드 = 데이터.pop(2)
        self.과표영세율금액 = 데이터.pop(13)
        self.과표영세율부가가치율 = 데이터.pop(5)
        self.과표재고납부세액 = 데이터.pop(13)
        self.과세표준금액 = 데이터.pop(15)
        self.산출세액 = 데이터.pop(15)
        self.매입세금계산서공제금액 = 데이터.pop(13)
        self.매입세금계산서공제세액 = 데이터.pop(13)
        self.매입매입자발행금액 = 데이터.pop(13)
        self.매입매입자발행세액 = 데이터.pop(13)
        self.공제세액 = 데이터.pop(15)
        self.매입자납부특례기납부금액 = 데이터.pop(13)
        self.매입자납부특례기납부세액 = 데이터.pop(13)
        self.예정고지세액 = 데이터.pop(15)
        self.가산세액세액합계 = 데이터.pop(13)
        self.차감납부할세액 = 데이터.pop(15)
        self.과세수입금액합계 = 데이터.pop(13)
        self.기타수입금액합계 = 데이터.pop(13)
        self.면세수입금액합계 = 데이터.pop(13)
        self.면세기타수입금액합계 = 데이터.pop(13)
        self.폐업일자 = 데이터.pop(8)
        self.폐업사유 = 데이터.pop(3)
        self.기한후여부 = 데이터.pop(1)
        self.은행코드 = 데이터.pop(3)
        self.계좌번호 = 데이터.pop(20)
        self.은행지점명 = 데이터.pop(30)
        self.실차감납부할세액 = 데이터.pop(15)
        self.납부면제구분 = 데이터.pop(1)
        self.과세유형전환일 = 데이터.pop(8)
        데이터.pop(19)

    def to_json(self):
        parsed = self.__dict__.copy()
        return parsed


class 신고서:
    def __init__(self, 데이터):
        self.원본 = []
        self.사업자등록번호 = []

        self.원본.append(데이터.peek_line())

        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.납세자ID = 데이터.pop(13)
        self.사업자등록번호.append(self.납세자ID.strip())
        self.세목코드 = 데이터.pop(2)
        self.신고구분코드 = 데이터.pop(2)
        self.신고구분상세코드 = 데이터.pop(2)
        self.과세기간_년월 = 데이터.pop(6)
        self.신고서종류코드 = 데이터.pop(3)
        self.사용자ID = 데이터.pop(20)
        self.납세자번호 = 데이터.pop(13)
        self.세무대리인성명 = 데이터.pop(30)
        self.세무대리인전화번호1 = 데이터.pop(4)
        self.세무대리인전화번호2 = 데이터.pop(5)
        self.세무대리인전화번호3 = 데이터.pop(5)
        self.상호 = 데이터.pop(30)
        self.성명 = 데이터.pop(30)
        self.사업장소재지 = 데이터.pop(70)
        self.사업장전화번호 = 데이터.pop(14)
        self.사업자주소 = 데이터.pop(70)
        self.사업자전화번호 = 데이터.pop(14)
        self.업태명 = 데이터.pop(30)
        self.종목명 = 데이터.pop(50)
        self.업종코드 = 데이터.pop(7)
        self.과세기간시작일자 = 데이터.pop(8)
        self.과세기간종료일자 = 데이터.pop(8)
        self.작성일자 = 데이터.pop(8)
        self.보정신고구분 = 데이터.pop(1)
        self.사업자휴대전화 = 데이터.pop(14)
        self.세무프로그램코드 = 데이터.pop(4)
        self.세무대리인사업자번호 = 데이터.pop(13)
        self.전자메일주소 = 데이터.pop(50)
        데이터.pop(65)

        while 데이터:
            자료구분서식코드 = 데이터.peek(9)
            if 자료구분서식코드[:2] in ('11', '12'):
                break
            elif 자료구분서식코드 == '17I103200':
                self.일반과세자신고서 = 일반과세자신고서(데이터)
            elif 자료구분서식코드 == '17I106000':
                self.간이과세자신고서 = 간이과세자신고서(데이터)
            else:
                데이터.pop_line()

            self.원본.append(데이터.peek_line())

    @staticmethod
    def 데이터추출(데이터):
        추출된_데이터 = []
        추출된_데이터.append(데이터.pop_line())

        while 데이터:
            자료구분서식코드 = 데이터.peek(9)
            if 자료구분서식코드[:2] in ('11', '12'):
                break
            추출된_데이터.append(데이터.pop_line())

        return '\r\n'.join(추출된_데이터)

    def to_json(self):
        parsed = self.__dict__.copy()
        del parsed['원본']
        del parsed['사업자등록번호']

        if getattr(self, '일반과세자신고서', None):
            parsed['일반과세자신고서'] = parsed['일반과세자신고서'].to_json() if parsed['일반과세자신고서'] else {}

        if getattr(self, '간이과세자신고서', None):
            parsed['간이과세자신고서'] = parsed['간이과세자신고서'].to_json() if parsed['간이과세자신고서'] else {}

        return parsed
