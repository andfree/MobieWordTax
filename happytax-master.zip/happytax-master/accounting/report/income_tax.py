def 사업자등록번호_추출(번호):
    사업자등록번호 = 번호.strip()
    if not 사업자등록번호:
        return None

    # 미등록번호
    number = int(사업자등록번호)
    if number < 30:
        return None

    # 주민등록번호
    if len(사업자등록번호) > 10:
        return None

    return 사업자등록번호


class 과세표준확정신고:
    def __init__(self, 데이터):
        self.원본 = []
        self.사업자등록번호 = []
        self.사업소득명세서 = []
        self.근로연금기타소득명세서 = []
        self.기납부세액명세서 = None
        self.총수입금액조정명세서 = []
        self.세액의계산 = None
        self.대표공동사업자 = False

        self.원본.append(데이터.peek_line())

        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.납세자_주민등록번호 = 데이터.pop(13)
        self.세목구분코드 = 데이터.pop(2)
        self.신고구분 = 데이터.pop(2)
        self.신고구분상세코드 = 데이터.pop(2)
        self.신고서종류코드 = 데이터.pop(3)
        self.개인단체구분코드 = 데이터.pop(1)
        self.과세기간_년월 = 데이터.pop(6)
        self.민원종류코드 = 데이터.pop(5)
        self.사용자ID = 데이터.pop(20)
        self.제출년월 = 데이터.pop(6)
        self.성명 = 데이터.pop(30)
        self.은행코드_국세환급금 = 데이터.pop(3)
        self.계좌번호_국세환급금 = 데이터.pop(20)
        self.예금종류 = 데이터.pop(20)
        self.세무대리인주민등록번호 = 데이터.pop(13)
        self.세무대리인성명 = 데이터.pop(30)
        self.세무대리인전화번호 = 데이터.pop(14)
        self.세무대리인대리구분 = 데이터.pop(2)
        self.세무대리인관리번호 = 데이터.pop(6)
        self.세무대리인조정반번호 = 데이터.pop(5)
        self.세무대리인사업자등록번호 = 데이터.pop(10)
        self.주소 = 데이터.pop(70)
        self.당해과세기간시작 = 데이터.pop(8)
        self.당해과세기간종료 = 데이터.pop(8)
        self.직전과세기간시작 = 데이터.pop(8)
        self.직전과세기간종료 = 데이터.pop(8)
        self.세무프로그램코드 = 데이터.pop(4)
        self.작성일자 = 데이터.pop(8)
        self.서식해당유무40_4 = 데이터.pop(1)
        self.서식해당유무40_5 = 데이터.pop(1)
        self.분리과세주택임대여부 = 데이터.pop(1)
        데이터.pop(61)

        while 데이터:
            자료구분서식코드 = 데이터.peek(9)
            if 자료구분서식코드[:2] == '51':
                break

            self.원본.append(데이터.peek_line())
            if 자료구분서식코드 == '52C110703':
                self.사업소득명세서.append(사업소득명세서(데이터))
                사업자등록번호 = 사업자등록번호_추출(self.사업소득명세서[-1].사업자등록번호)
                if 사업자등록번호:
                    self.사업자등록번호.append(사업자등록번호)
                if self.사업소득명세서[-1].대표공동사업자_주민등록번호.split():
                    self.대표공동사업자 = True
            elif 자료구분서식코드 == '52C110704':
                self.근로연금기타소득명세서.append(근로연금기타소득명세서(데이터))
            elif 자료구분서식코드 == '52C110713':
                self.기납부세액명세서 = 기납부세액명세서(데이터)
            elif 자료구분서식코드 == '52C113400':
                self.총수입금액조정명세서.append(총수입금액조정명세서(데이터))
            elif 자료구분서식코드 == '53C110700':
                self.세액의계산 = 세액의계산(데이터)
            else:
                데이터.pop_line()

    @staticmethod
    def 데이터추출(데이터):
        추출된_데이터 = []
        추출된_데이터.append(데이터.pop_line())

        while 데이터:
            자료구분서식코드 = 데이터.peek(9)
            if 자료구분서식코드[:2] == '51':
                break
            추출된_데이터.append(데이터.pop_line())

        return '\r\n'.join(추출된_데이터)

    def to_json(self):
        parsed = self.__dict__.copy()
        del parsed['원본']
        del parsed['사업자등록번호']
        parsed['사업소득명세서'] = [r.to_json() for r in parsed['사업소득명세서']]
        parsed['근로연금기타소득명세서'] = [r.to_json() for r in parsed['근로연금기타소득명세서']]
        parsed['기납부세액명세서'] = parsed['기납부세액명세서'].to_json() if parsed['기납부세액명세서'] else {}
        parsed['총수입금액조정명세서'] = [r.to_json() for r in parsed['총수입금액조정명세서']]
        parsed['세액의계산'] = parsed['세액의계산'].to_json() if parsed['세액의계산'] else {}
        return parsed


class 사업소득명세서:
    def __init__(self, 데이터):
        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.수득구분코드 = 데이터.pop(2)
        self.일련번호 = 데이터.pop(6)
        self.사업장소재지 = 데이터.pop(70)
        self.사업장_국내국외 = 데이터.pop(1)
        self.사업장_소재지국코드 = 데이터.pop(2)
        self.상호 = 데이터.pop(60)
        self.사업자등록번호 = 데이터.pop(10)
        self.사업장전화번호 = 데이터.pop(14)
        self.기장의무 = 데이터.pop(2)
        self.신고유형 = 데이터.pop(2)
        self.주업종코드 = 데이터.pop(6)
        self.총수입금액 = 데이터.pop(13)
        self.필요경비 = 데이터.pop(13)
        self.소득금액 = 데이터.pop(13)
        self.대표공동사업자_주민등록번호 = 데이터.pop(13)
        self.대표공동사업자_납세자구분 = 데이터.pop(2)
        self.대표공동사업자_성명 = 데이터.pop(30)
        self.과세기간개시일 = 데이터.pop(8)
        self.과세기간종료일 = 데이터.pop(8)
        데이터.pop(66)

    def to_json(self):
        parsed = self.__dict__.copy()
        return parsed


class 근로연금기타소득명세서:
    def __init__(self, 데이터):
        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.수득구분코드 = 데이터.pop(2)
        self.일련번호 = 데이터.pop(6)
        self.소득지급자_상호 = 데이터.pop(60)
        self.소득지급자_사업자등록번호 = 데이터.pop(13)
        self.총수입금액_총급여액 = 데이터.pop(13)
        self.필요경비_근로소득공제 = 데이터.pop(13)
        self.소득금액 = 데이터.pop(13)
        self.원천징수_소득세 = 데이터.pop(13)
        self.원천징수_농특세 = 데이터.pop(13)
        self.사업자주민구분 = 데이터.pop(1)
        데이터.pop(94)

    def to_json(self):
        parsed = self.__dict__.copy()
        return parsed


class 기납부세액명세서:
    def __init__(self, 데이터):
        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.중간예납세액_소득 = 데이터.pop(13)
        self.토지등매매차익예정신고납부세액_소득 = 데이터.pop(13)
        self.토지등매매차익예정고지세액_소득 = 데이터.pop(13)
        self.수시부과세_소득 = 데이터.pop(13)
        self.원천징수_이자_소득 = 데이터.pop(13)
        self.원천징수_배당_소득 = 데이터.pop(13)
        self.원천징수_사업_소득 = 데이터.pop(13)
        self.원천징수_근로_소득 = 데이터.pop(13)
        self.원천징수_연금_소득 = 데이터.pop(13)
        self.원천징수_기타_소득 = 데이터.pop(13)
        self.기납부세액합계_소득 = 데이터.pop(13)
        self.수시부과세_농특 = 데이터.pop(13)
        self.원천징수사업_농특 = 데이터.pop(13)
        self.원천징수근로_농특 = 데이터.pop(13)
        self.기납부세액합계_농특 = 데이터.pop(13)
        데이터.pop(96)

    def to_json(self):
        parsed = self.__dict__.copy()
        return parsed


class 총수입금액조정명세서:
    def __init__(self, 데이터):
        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.소득구분코드 = 데이터.pop(2)
        self.사업자등록번호 = 데이터.pop(10)
        self.일련번호 = 데이터.pop(6)
        self.계정과목 = 데이터.pop(50)
        self.결산서상수입금액 = 데이터.pop(15)
        self.조정가산 = 데이터.pop(15)
        self.조정차감 = 데이터.pop(15)
        self.조정수입금액 = 데이터.pop(15)
        self.비고 = 데이터.pop(20)
        self.과세기간_시작일 = 데이터.pop(8)
        self.과세기간_종료일 = 데이터.pop(8)
        데이터.pop(77)

    def to_json(self):
        parsed = self.__dict__.copy()
        return parsed


class 세액의계산:
    def __init__(self, 데이터):
        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.종합소득금액 = 데이터.pop(13)
        self.소득공제 = 데이터.pop(13)
        self.종합소득세_과세표준 = 데이터.pop(15)
        self.종합소득세_세율 = 데이터.pop(5)
        self.종합소득세_산출세액 = 데이터.pop(15)
        self.종합소득세_세액감면 = 데이터.pop(15)
        self.종합소득세_세액공제 = 데이터.pop(15)
        self.종합소득세_결정세액_종합과세 = 데이터.pop(15)
        self.종합소득세_결정세액_분리과세주택임대소득 = 데이터.pop(15)
        self.종합소득세_결정세액_합계 = 데이터.pop(15)
        self.종합소득세_가산세 = 데이터.pop(15)
        self.종합소득세_추가납부세액 = 데이터.pop(13)
        self.종합소득세_합계 = 데이터.pop(13)
        self.종합소득세_기납부세액 = 데이터.pop(15)
        self.종합소득세_납부할총세액 = 데이터.pop(15)
        self.종합소득세_납부특례세액_차감 = 데이터.pop(15)
        self.종합소득세_납부특례세액_가산 = 데이터.pop(15)
        self.종합소득세_분납할세액 = 데이터.pop(15)
        self.종합소득세_신고기한내납부할세액 = 데이터.pop(15)
        self.농어촌특별세_과세표준 = 데이터.pop(15)
        self.농어촌특별세_세율 = 데이터.pop(5)
        self.농어촌특별세_산출세액 = 데이터.pop(13)
        self.농어촌특별세_결정세액_종합과세 = 데이터.pop(13)
        self.농어촌특별세_결정세액_분리과세주택임대소득 = 데이터.pop(13)
        self.농어촌특별세_결정세액_합계 = 데이터.pop(13)
        self.농어촌특별세_가산세 = 데이터.pop(13)
        self.농어촌특별세_환급세액 = 데이터.pop(13)
        self.농어촌특별세_합계 = 데이터.pop(13)
        self.농어촌특별세_기납부세액 = 데이터.pop(13)
        self.농어촌특별세_납부할총세액 = 데이터.pop(13)
        self.농어촌특별세_분납할세액 = 데이터.pop(13)
        self.농어촌특별세_신고기한내납부할세액 = 데이터.pop(13)
        self.비교과세적용구분코드 = 데이터.pop(1)
        데이터.pop(160)

    def to_json(self):
        parsed = self.__dict__.copy()
        return parsed


class 사업소득에대한원천징수세액내역서:
    def __init__(self, 데이터):
        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.사업자_주민등록번호 = 데이터.pop(13)
        self.일련번호 = 데이터.pop(6)
        self.상호_성명 = 데이터.pop(60)
        self.소득세 = 데이터.pop(13)
        self.농특세 = 데이터.pop(13)
        self.사업자주민구분 = 데이터.pop(1)
        데이터.pop(85)

    def to_json(self):
        parsed = self.__dict__.copy()
        return parsed


class 부동산임대소득:
    def __init__(self, 데이터):
        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.부동산임대소득구분코드 = 데이터.pop(2)
        self.주택수 = 데이터.pop(6)
        self.수입금액 = 데이터.pop(15)
        self.필요경비 = 데이터.pop(15)
        self.소득금액 = 데이터.pop(15)
        데이터.pop(88)

    def to_json(self):
        parsed = self.__dict__.copy()
        return parsed
