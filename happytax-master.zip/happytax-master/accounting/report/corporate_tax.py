class 법인세신고서:
    def __init__(self, 데이터):
        self.원본 = []
        self.사업자등록번호 = []
        self.법인세과세표준및세액신고서 = None
        self.표준손익계산서 = []
        self.공제감면세액및추가납부세액합계표갑 = []
        self.농어촌특별세과세표준및세액조정계산서 = None
        self.소득구분계산서 = []

        self.원본.append(데이터.peek_line())

        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.세목구분코드 = 데이터.pop(2)
        self.과세기간_년월 = 데이터.pop(6)
        self.납세자ID = 데이터.pop(13)
        self.사업자등록번호.append(self.납세자ID.strip())
        self.신고구분코드 = 데이터.pop(2)
        self.신고구분상세코드 = 데이터.pop(2)
        self.신고서종류코드 = 데이터.pop(3)
        self.민원종류코드 = 데이터.pop(5)
        self.제출년월 = 데이터.pop(6)
        self.법인등록번호 = 데이터.pop(13)
        self.법인명 = 데이터.pop(60)
        self.성명_대표자 = 데이터.pop(30)
        self.사업장소재지 = 데이터.pop(70)
        self.email주소 = 데이터.pop(30)
        self.전화번호 = 데이터.pop(14)
        self.업태명 = 데이터.pop(30)
        self.종목명 = 데이터.pop(50)
        self.주업종코드 = 데이터.pop(6)
        self.사업연도_시작일자 = 데이터.pop(8)
        self.사업연도_종료일자 = 데이터.pop(8)
        self.수시부과기간_시작일자 = 데이터.pop(8)
        self.수시부과기간_종료일자 = 데이터.pop(8)
        self.작성일자 = 데이터.pop(8)
        self.세무대리인성명 = 데이터.pop(30)
        self.세무대리인관리번호 = 데이터.pop(6)
        self.세무대리인전화번호 = 데이터.pop(14)
        self.세무프로그램코드 = 데이터.pop(4)
        self.세무대리인사업자번호 = 데이터.pop(10)
        self.사용자ID = 데이터.pop(50)
        데이터.pop(30)

        while 데이터:
            자료구분서식코드 = 데이터.peek(9)
            if 자료구분서식코드[:2] == '81':
                break

            self.원본.append(데이터.peek_line())
            if 자료구분서식코드 == '83D100100':
                self.법인세과세표준및세액신고서 = 법인세과세표준및세액신고서(데이터)
            elif 자료구분서식코드 == '83D100900':
                self.표준손익계산서.append(표준손익계산서(데이터))
            elif 자료구분서식코드 == '83D101800':
                self.공제감면세액및추가납부세액합계표갑.append(공제감면세액및추가납부세액합계표갑(데이터))
            elif 자료구분서식코드 == '83D103500':
                self.농어촌특별세과세표준및세액조정계산서 = 농어촌특별세과세표준및세액조정계산서(데이터)
            elif 자료구분서식코드 == '83D108400':
                self.소득구분계산서.append(소득구분계산서(데이터))
            else:
                데이터.pop_line()

    @staticmethod
    def 데이터추출(데이터):
        추출된_데이터 = []
        추출된_데이터.append(데이터.pop_line())

        while 데이터:
            자료구분서식코드 = 데이터.peek(9)
            if 자료구분서식코드[:2] == '81':
                break
            추출된_데이터.append(데이터.pop_line())

        return '\r\n'.join(추출된_데이터)

    def to_json(self):
        parsed = self.__dict__.copy()
        del parsed['원본']
        del parsed['사업자등록번호']
        parsed['법인세과세표준및세액신고서'] = parsed['법인세과세표준및세액신고서'].to_json() if parsed['법인세과세표준및세액신고서'] else {}
        parsed['표준손익계산서'] = [r.to_json() for r in parsed['표준손익계산서']]
        parsed['공제감면세액및추가납부세액합계표갑'] = [r.to_json() for r in parsed['공제감면세액및추가납부세액합계표갑']]
        parsed['농어촌특별세과세표준및세액조정계산서'] = parsed['농어촌특별세과세표준및세액조정계산서'].to_json() if parsed['농어촌특별세과세표준및세액조정계산서'] else {}
        parsed['소득구분계산서'] = [r.to_json() for r in parsed['소득구분계산서']]
        return parsed


class 법인세과세표준및세액신고서:
    def __init__(self, 데이터):
        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.법인구분 = 데이터.pop(2)
        self.외투법인_비율 = 데이터.pop(6)
        self.종류별구분 = 데이터.pop(2)
        self.조정구분 = 데이터.pop(2)
        self.외부감사대상 = 데이터.pop(1)
        self.결산확정일 = 데이터.pop(8)
        self.신고일 = 데이터.pop(8)
        self.중도폐업신고여부 = 데이터.pop(1)
        self.주식변동여부 = 데이터.pop(1)
        self.장부전산화여부 = 데이터.pop(1)
        self.사업연도의제여부 = 데이터.pop(1)
        self.신고기한연장승인_신청일 = 데이터.pop(8)
        self.신고기한연장승인_연장기한 = 데이터.pop(8)
        self.결손금소급공제_신청여부 = 데이터.pop(1)
        self.감가상각방법_제출여부 = 데이터.pop(1)
        self.재고자산등_제출여부 = 데이터.pop(1)
        self.수입금액 = 데이터.pop(15)
        self.과세표준_법인세 = 데이터.pop(15)
        self.과세표준_토지등_양도소득에_대한_법인세 = 데이터.pop(15)
        self.과세표준_계 = 데이터.pop(15)
        self.산출세액_법인세 = 데이터.pop(15)
        self.산출세액_토지등_양도소득에_대한_법인세 = 데이터.pop(15)
        self.산출세액_계 = 데이터.pop(15)
        self.총부담세액_법인세 = 데이터.pop(15)
        self.총부담세액_토지등_양도소득에_대한_법인세 = 데이터.pop(15)
        self.총부담세액_계 = 데이터.pop(15)
        self.기납부세액_법인세 = 데이터.pop(15)
        self.기납부세액_토지등_양도소득에_대한_법인세 = 데이터.pop(15)
        self.기납부세액_계 = 데이터.pop(15)
        self.차감납부할세액_법인세 = 데이터.pop(15)
        self.차감납부할세액_토지등_양도소득에_대한_법인세 = 데이터.pop(15)
        self.차감납부할세액_계 = 데이터.pop(15)
        self.분납할세액 = 데이터.pop(15)
        self.차감납부세액 = 데이터.pop(15)
        self.외부조정자_조정반번호 = 데이터.pop(5)
        self.외부조정자_조정자관리번호 = 데이터.pop(6)
        self.외부조정자_성명 = 데이터.pop(30)
        self.외부조정자_사업자등록번호 = 데이터.pop(10)
        self.국세환급금계좌_은행코드 = 데이터.pop(3)
        self.국세환급금계좌_예금종류 = 데이터.pop(20)
        self.국세환급금계좌_계좌번호 = 데이터.pop(20)
        self.주식변동자료매체로제출여부 = 데이터.pop(1)
        self.법인유형별구분 = 데이터.pop(3)
        self.기능통화채택여부 = 데이터.pop(1)
        self.동업기업의출자자여부 = 데이터.pop(1)
        self.과세표준환산시적용환율 = 데이터.pop(7)
        self.국제회계기준적용여부 = 데이터.pop(1)
        self.외부조정자_전화번호 = 데이터.pop(14)
        self.내용연수승인_변경승인_신청여부 = 데이터.pop(1)
        self.감가상각방법변경승인신청여부 = 데이터.pop(1)
        self.기능통화도입기업의과세표준계산방법 = 데이터.pop(1)
        self.미환류소득에_대한_법인세_신고여부 = 데이터.pop(1)
        self.과세표준_미환류소득에_대한_법인세 = 데이터.pop(15)
        self.산출세액_미환류소득에_대한_법인세 = 데이터.pop(15)
        self.총부담세액_미환류소득에_대한_법인세 = 데이터.pop(15)
        self.차감납부할세액_미환류소득에_대한_법인세 = 데이터.pop(15)
        데이터.pop(30)

    def to_json(self):
        parsed = self.__dict__.copy()
        return parsed


class 표준손익계산서:
    def __init__(self, 데이터):
        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.계정과목코드 = 데이터.pop(6)
        self.금액 = 데이터.pop(16)
        self.기타계정과목명 = 데이터.pop(50)
        데이터.pop(30)

    def to_json(self):
        parsed = self.__dict__.copy()
        return parsed


class 공제감면세액및추가납부세액합계표갑:
    def __init__(self, 데이터):
        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.구분코드 = 데이터.pop(3)
        self.대상세액 = 데이터.pop(15)
        self.감면세액 = 데이터.pop(15)
        self.전기이월액 = 데이터.pop(15)
        self.당기발생액 = 데이터.pop(15)
        self.구분명칭 = 데이터.pop(50)
        데이터.pop(30)

    def to_json(self):
        parsed = self.__dict__.copy()
        return parsed


class 농어촌특별세과세표준및세액조정계산서:
    def __init__(self, 데이터):
        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.법인세감면세액_과세표준금액 = 데이터.pop(15)
        self.세율 = 데이터.pop(5)
        self.세액 = 데이터.pop(15)
        self.소계_과세표준금액 = 데이터.pop(15)
        데이터.pop(30)

    def to_json(self):
        parsed = self.__dict__.copy()
        return parsed


class 소득구분계산서:
    def __init__(self, 데이터):
        self.자료구분 = 데이터.pop(2)
        self.서식코드 = 데이터.pop(7)
        self.페이지번호 = 데이터.pop(2)
        self.공란명1 = 데이터.pop(50)
        self.공란명2 = 데이터.pop(50)
        self.공란명3 = 데이터.pop(50)
        self.과목구분코드 = 데이터.pop(2)
        self.합계 = 데이터.pop(15)
        self.감면분_등_금액1 = 데이터.pop(15)
        self.감면분_등_비율1 = 데이터.pop(6)
        self.감면분_등_금액2 = 데이터.pop(15)
        self.감면분_등_비율2 = 데이터.pop(6)
        self.감면분_등_금액3 = 데이터.pop(15)
        self.감면분_등_비율3 = 데이터.pop(6)
        self.기타분_금액 = 데이터.pop(15)
        self.기타분_비율 = 데이터.pop(6)
        self.비고 = 데이터.pop(30)
        데이터.pop(30)

    def to_json(self):
        parsed = self.__dict__.copy()
        return parsed
