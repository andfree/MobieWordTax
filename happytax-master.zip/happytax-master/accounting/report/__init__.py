from accounting.report.corporate_tax import 법인세신고서
from accounting.report.vat import 신고서
from accounting.report.income_tax import 과세표준확정신고


class 자료:
    @staticmethod
    def split(데이터):
        while 데이터:
            if 데이터.peek(2) == '51':
                yield 과세표준확정신고.데이터추출(데이터)
            elif 데이터.peek(2) in ('11', '12'):
                yield 신고서.데이터추출(데이터)
            elif 데이터.peek(2) == '81':
                yield 법인세신고서.데이터추출(데이터)
            else:
                데이터.pop_line()

        return []

    @staticmethod
    def factory(데이터):
        if 데이터.peek(2) == '51':
            return 과세표준확정신고(데이터)
        if 데이터.peek(2) in ('11', '12'):
            return 신고서(데이터)
        if 데이터.peek(2) == '81':
            return 법인세신고서(데이터)

        return None


class 데이터:
    def __init__(self, byte=None, string=None):
        if string:
            byte = string.encode('cp949')

        self.raw = bytearray(reversed(byte)).splitlines()

    def peek(self, length):
        if not self.raw:
            return ''

        return bytearray([self.raw[-1][-i] for i in range(1, length+1)]).decode('cp949')

    def peek_line(self):
        if not self.raw:
            return ''

        return bytearray(reversed(self.raw[-1])).decode('cp949')

    def pop(self, length):
        if not self.raw:
            return ''

        string = bytearray([self.raw[-1].pop() for _ in range(length)]).decode('cp949')
        while self.raw and not self.raw[-1]:
            self.raw.pop()
        return string

    def pop_line(self):
        if not self.raw:
            return ''

        string = bytearray(reversed(self.raw.pop())).decode('cp949')
        while self.raw and not self.raw[-1]:
            self.raw.pop()
        return string

    def __str__(self):
        if not self.raw:
            return ''

        return bytearray(reversed(self.raw[-1])).decode('cp949')

    def __bool__(self):
        return bool(self.raw)
