import json
from decimal import Decimal

from datetime import datetime

import logging
from dateutil.relativedelta import relativedelta
from django.core.exceptions import ObjectDoesNotExist
from django.db.models.aggregates import Sum, Count
from django.db.models.query_utils import Q

from accounting.util import floor


class 부가가치세:
    PARTS = {
        'vat_part_7_1': '매출예정신고누락분',
        'vat_part_7_2': '매출예정신고누락분세액',
        'vat_part_8': '대손세액가감',
        'vat_part_12_1': '매입예정신고누락분',
        'vat_part_12_2': '매입예정신고누락분세액',
        'vat_part_16_1': '공제받지못할매입세액과세표준',
        'vat_part_16_2': '공제받지못할매입세액',
        'vat_part_18_1': '그밖의경감공제세액',
        'vat_part_21': '예정신고미환급세액',
        'vat_part_22': '예정고지세액',
        'vat_part_23': '사업양수자의대리납부기납부세액',
        'vat_part_24': '매입자납부특례기납부세액',
        'vat_part_25': '가산세액계',
    }

    def get_invoices(self, invoice_type, voucher_types):
        invoices = self.tax.trader.invoice_set.filter(issued__range=self.tax.range(), invoice_type=invoice_type)
        queries = Q()
        for voucher_type in voucher_types:
            queries |= Q(voucher_type=voucher_type)
        invoices = invoices.filter(queries)

        return invoices

    def get_sum_of_invoices(self, invoice_type, voucher_types, field):
        invoices = self.get_invoices(invoice_type, voucher_types)
        return invoices.aggregate(sum=Sum(field))['sum'] or Decimal(0)

    def get_sum_of_sales(self, voucher_types, field):
        return self.get_sum_of_invoices('sales', voucher_types, field)

    def get_sum_of_purchases(self, voucher_types, field):
        return self.get_sum_of_invoices('purchases', voucher_types, field)

    def get_count_of_consumers(self, voucher_types):
        invoices = self.get_invoices('sales', voucher_types)
        return invoices.aggregate(count=Count('consumer_no', distinct=True))['count'] or Decimal(0)

    def get_count_of_suppliers(self, voucher_types):
        invoices = self.get_invoices('purchases', voucher_types)
        return invoices.aggregate(count=Count('supplier_no', distinct=True))['count'] or Decimal(0)

    def get_count_of_invoices(self, invoice_type, voucher_types):
        invoices = self.get_invoices(invoice_type, voucher_types)
        return invoices.count()

    def get_count_of_sales(self, voucher_types):
        return self.get_count_of_invoices('sales', voucher_types)

    def get_count_of_purchases(self, voucher_types):
        return self.get_count_of_invoices('purchases', voucher_types)

    def get_information_of_consumers(self, voucher_types):
        invoices = self.get_invoices('sales', voucher_types)
        return invoices.values('consumer_no', 'consumer_name').annotate(count=Count('id'),
                                                                        value_of_supply=Sum('value_of_supply'),
                                                                        vat=Sum('vat'))

    def get_information_of_suppliers(self, voucher_types):
        invoices = self.get_invoices('purchases', voucher_types)
        return invoices.values('supplier_no', 'supplier_name').annotate(count=Count('id'),
                                                                        value_of_supply=Sum('value_of_supply'),
                                                                        vat=Sum('vat'))

    def get_신용카드공제율(self):
        if self.tax.trader.taxation == 'simplified' and self.tax.trader.is_restaurant:
            return Decimal('0.026')
        else:
            return Decimal('0.013')

    def get_의제매입금액(self):
        journal_entries = self.tax.trader.journalentry_set.filter(issued__range=self.tax.range(),
                                                                  description='의제매입세액 원재료차감(부가)')

        return journal_entries.aggregate(sum=Sum('amount'))['sum'] or Decimal(0)

    def __init__(self, tax):
        self.tax = tax

        self.매출전자세금계산서이외발급거래자정보 = self.get_information_of_consumers(['과세'])
        self.매출전자세금계산서이외발급거래처수 = self.get_count_of_consumers(['과세'])
        self.매출전자세금계산서이외발급거래건수 = self.get_count_of_sales(['과세'])
        self.매출전자세금계산서이외발급금액 = self.get_sum_of_sales(['과세'], 'value_of_supply')
        self.매출전자세금계산서이외발급세액 = self.get_sum_of_sales(['과세'], 'vat')

        self.매출전자세금계산서발급거래처수 = self.get_count_of_consumers(['전자세금계산서'])
        self.매출전자세금계산서발급거래건수 = self.get_count_of_sales(['전자세금계산서'])
        self.매출전자세금계산서발급금액 = self.get_sum_of_sales(['전자세금계산서'], 'value_of_supply')
        self.매출전자세금계산서발급세액 = self.get_sum_of_sales(['전자세금계산서'], 'vat')

        self.매출과세세금계산서발급거래처수 = self.매출전자세금계산서이외발급거래처수 + self.매출전자세금계산서발급거래처수
        self.매출과세세금계산서발급거래건수 = self.매출전자세금계산서이외발급거래건수 + self.매출전자세금계산서발급거래건수
        self.매출과세세금계산서발급금액 = self.매출전자세금계산서이외발급금액 + self.매출전자세금계산서발급금액  # (1)
        self.매출과세세금계산서발급세액 = self.매출전자세금계산서이외발급세액 + self.매출전자세금계산서발급세액  # (1)

        self.매출과세매입자발행세금계산서금액 = 0  # (2)
        self.매출과세매입자발행세금계산서세액 = 0  # (2)

        self.매출과세카드거래건수 = self.get_count_of_sales(['카과'])
        self.매출과세현금거래건수 = self.get_count_of_sales(['현과'])
        self.매출과세거래건수 = self.매출과세카드거래건수 + self.매출과세현금거래건수

        self.매출과세카드발행금액 = self.get_sum_of_sales(['카과'], 'value_of_supply')
        self.매출과세현금발행금액 = self.get_sum_of_sales(['현과'], 'value_of_supply')
        self.매출과세카드현금발행금액 = self.매출과세카드발행금액 + self.매출과세현금발행금액  # (3)

        self.매출과세카드발행세액 = self.get_sum_of_sales(['카과'], 'vat')
        self.매출과세현금발행세액 = self.get_sum_of_sales(['현과'], 'vat')
        self.매출과세카드현금발행세액 = self.매출과세카드발행세액 + self.매출과세현금발행세액  # (3)

        self.매출과세기타금액 = self.get_sum_of_sales(['건별'], 'value_of_supply')  # (4)
        self.매출과세기타세액 = self.get_sum_of_sales(['건별'], 'vat')  # (4)
        self.매출영세율세금계산서발급금액 = 0  # (5)
        self.매출영세율기타금액 = 0  # (6)
        self.매출예정누락합계금액 = self.tax.info.get('매출예정누락합계금액', 0)  # (7)
        self.매출예정누락합계세액 = self.tax.info.get('매출예정누락합계세액', 0)  # (7)
        self.예정누락매출세금계산서금액 = 0  # (32)
        self.예정누락매출세금계산서세액 = 0  # (32)
        self.예정누락매출과세기타금액 = 0  # (33)
        self.예정누락매출과세기타세액 = 0  # (33)
        self.예정누락매출영세율세금계산서금액 = 0  # (34)
        self.예정누락매출영세율기타금액 = 0  # (35)
        self.예정누락매출명세합계금액 = 0  # (36)
        self.예정누락매출명세합계세액 = 0  # (36)
        self.매출대손세액가감세액 = self.tax.info.get('매출대손세액가감세액', 0)  # (8)
        self.과세표준금액 = sum([  # (9)
            self.매출과세세금계산서발급금액,
            self.매출과세매입자발행세금계산서금액,
            self.매출과세카드현금발행금액,
            self.매출과세기타금액,
            self.매출영세율세금계산서발급금액,
            self.매출영세율기타금액,
            self.매출예정누락합계금액
        ])
        self.산출세액 = sum([  # (가)
            self.매출과세세금계산서발급세액,
            self.매출과세매입자발행세금계산서세액,
            self.매출과세카드현금발행세액,
            self.매출과세기타세액,
            self.매출예정누락합계세액,
            self.매출대손세액가감세액
        ])

        self.매입전자세금계산서이외수취거래자정보 = self.get_information_of_suppliers(['과세'])
        self.매입전자세금계산서이외수취거래처수 = self.get_count_of_suppliers(['과세'])
        self.매입전자세금계산서이외수취거래건수 = self.get_count_of_purchases(['과세'])
        self.매입전자세금계산서이외수취일반금액 = self.get_sum_of_purchases(['과세'], 'value_of_supply')
        self.매입전자세금계산서이외수취일반세액 = self.get_sum_of_purchases(['과세'], 'vat')

        self.매입전자세금계산서수취거래처수 = self.get_count_of_suppliers(['전자세금계산서'])
        self.매입전자세금계산서수취거래건수 = self.get_count_of_purchases(['전자세금계산서'])
        self.매입전자세금계산서수취일반금액 = self.get_sum_of_purchases(['전자세금계산서'], 'value_of_supply')
        self.매입전자세금계산서수취일반세액 = self.get_sum_of_purchases(['전자세금계산서'], 'vat')

        self.매입세금계산서수취거래처수 = self.매입전자세금계산서이외수취거래처수 + self.매입전자세금계산서수취거래처수
        self.매입세금계산서수취거래건수 = self.매입전자세금계산서이외수취거래건수 + self.매입전자세금계산서수취거래건수
        self.매입세금계산서수취일반금액 = self.매입전자세금계산서이외수취일반금액 + self.매입전자세금계산서수취일반금액  # (10)
        self.매입세금계산서수취일반세액 = self.매입전자세금계산서이외수취일반세액 + self.매입전자세금계산서수취일반세액  # (10)

        self.매입세금계산서수취고정자산금액 = 0  # (11)
        self.매입세금계산서수취고정자산세액 = 0  # (11)
        self.매입예정누락합계금액 = self.tax.info.get('매입예정누락합계금액', 0)  # (12)
        self.매입예정누락합계세액 = self.tax.info.get('매입예정누락합계세액', 0)  # (12)
        self.예정누락매입신고세금계산서금액 = 0  # (37)
        self.예정누락매입신고세금계산서세액 = 0  # (37)
        self.예정누락매입기타공제금액 = 0  # (38)
        self.예정누락매입기타공제세액 = 0  # (38)
        self.예정누락매입명세합계금액 = 0  # (39)
        self.예정누락매입명세합계세액 = 0  # (39)
        self.매입자발행세금계산서매입금액 = 0  # (13)
        self.매입자발행세금계산서매입세액 = 0  # (13)
        self.의제매입금액 = self.get_의제매입금액()
        self.의제매입세액 = self.의제매입금액 * 8 / 108  # (42)

        self.매입기타공제카드거래건수 = self.get_count_of_purchases(['카과'])
        self.매입기타공제현금거래건수 = self.get_count_of_purchases(['현과'])
        self.매입기타공제거래건수 = self.매입기타공제카드거래건수 + self.매입기타공제현금거래건수

        self.매입기타공제카드매입금액 = self.get_sum_of_purchases(['카과'], 'value_of_supply')
        self.매입기타공제현금매입금액 = self.get_sum_of_purchases(['현과'], 'value_of_supply')
        self.매입기타공제일반매입금액 = self.매입기타공제카드매입금액 + self.매입기타공제현금매입금액  # (40)
        self.매입기타공제매입금액 = self.매입기타공제일반매입금액 + self.의제매입금액  # (14)
        self.그밖의공제매입명세합계금액 = self.매입기타공제매입금액  # (48)

        self.매입기타공제카드매입세액 = self.get_sum_of_purchases(['카과'], 'vat')
        self.매입기타공제현금매입세액 = self.get_sum_of_purchases(['현과'], 'vat')
        self.매입기타공제일반매입세액 = self.매입기타공제카드매입세액 + self.매입기타공제현금매입세액  # (40)
        self.매입기타공제매입세액 = self.매입기타공제일반매입세액 + self.의제매입세액  # (14)
        self.그밖의공제매입명세합계세액 = self.매입기타공제매입세액  # (48)

        self.매입세액합계금액 = sum([  # (15)
            self.매입세금계산서수취일반금액,
            self.매입세금계산서수취고정자산금액,
            self.매입예정누락합계금액,
            self.매입자발행세금계산서매입금액,
            self.그밖의공제매입명세합계금액
        ])
        self.매입세액합계세액 = sum([  # (15)
            self.매입세금계산서수취일반세액,
            self.매입세금계산서수취고정자산세액,
            self.매입예정누락합계세액,
            self.매입자발행세금계산서매입세액,
            self.그밖의공제매입명세합계세액
        ])

        self.공제받지못할매입합계금액 = self.tax.info.get('공제받지못할매입합계금액', 0)  # (16)
        self.공제받지못할매입합계세액 = self.tax.info.get('공제받지못할매입합계세액', 0)  # (16)
        self.공제받지못할매입금액 = 0  # (49)
        self.공제받지못할매입세액 = 0  # (49)
        self.공제받지못할공통매입면세사업금액 = 0  # (50)
        self.공제받지못할공통매입면세사업세액 = 0  # (50)
        self.공제받지못할대손처분금액 = 0  # (51)
        self.공제받지못할대손처분세액 = 0  # (51)
        self.공제받지못할매입명세합계금액 = 0  # (52)
        self.공제받지못할매입명세합계세액 = 0  # (52)
        self.차감합계금액 = self.매입세액합계금액 - self.공제받지못할매입합계금액  # (17)
        self.차감합계세액 = self.매입세액합계세액 - self.공제받지못할매입합계세액  # (나)
        setattr(self, '납부(환급)세액', self.산출세액 - self.차감합계세액)  # (다)

        self.그밖의경감공제세액 = self.tax.info.get('그밖의경감공제세액', 0)  # (18)
        self.그밖의경감공제명세합계세액 = 0  # (58)

        self.신용카드등발행공제금액 = self.get_sum_of_sales(['카과'], 'total')
        self.현금영수증발행공제금액 = self.get_sum_of_sales(['현과'], 'total')
        self.신용카드매출전표등발행공제등금액 = self.신용카드등발행공제금액 + self.현금영수증발행공제금액  # (19)

        if self.tax.trader.is_corporation:
            self.신용카드매출전표등발행공제등세액 = 0
        else:
            self.신용카드매출전표등발행공제등세액 = self.신용카드매출전표등발행공제등금액 * self.get_신용카드공제율()  # (19)
            if self.신용카드매출전표등발행공제등세액 > getattr(self, '납부(환급)세액'):
                self.신용카드매출전표등발행공제등세액 = getattr(self, '납부(환급)세액')

            if self.신용카드매출전표등발행공제등세액 > 0:
                한도 = 5000000
                previous_period = self.tax.previous_period
                while previous_period[:4] == self.tax.period[:4]:
                    try:
                        tax = self.tax.trader.tax_set.get(period=previous_period, type=self.tax.type)
                        vat = 부가가치세(tax)
                        한도 -= vat.신용카드매출전표등발행공제등세액
                        previous_period = tax.previous_period
                    except ObjectDoesNotExist:
                        break

                if 한도 < self.신용카드매출전표등발행공제등세액:
                    self.신용카드매출전표등발행공제등세액 = 한도

            if self.신용카드매출전표등발행공제등세액 < 0:
                self.신용카드매출전표등발행공제등세액 = 0

        self.경감공제합계금액 = sum([self.신용카드매출전표등발행공제등금액])  # (20)
        self.경감공제합계세액 = sum([self.그밖의경감공제세액, self.신용카드매출전표등발행공제등세액])  # (라)

        self.예정신고미환급세액 = self.tax.info.get('예정신고미환급세액', 0)  # (마)
        self.예정고지세액 = self.tax.info.get('예정고지세액', 0)  # (바)
        self.사업양수자의대리납부기납부세액 = self.tax.info.get('사업양수자의대리납부기납부세액', 0)  # (사)
        self.매입자납부특례기납부세액 = self.tax.info.get('매입자납부특례기납부세액', 0)  # (아)
        self.가산세액계 = self.tax.info.get('가산세액계', 0)  # (자)
        self.차감납부할세액 = Decimal(getattr(self, '납부(환급)세액')) - self.경감공제합계세액 - self.예정신고미환급세액 - self.예정고지세액 - self.사업양수자의대리납부기납부세액 - self.매입자납부특례기납부세액 - self.가산세액계  # (26)

        self.계산서수취거래처수 = self.get_count_of_suppliers(['전자계산서'])
        self.계산서수취거래건수 = self.get_count_of_purchases(['전자계산서'])
        self.계산서수취금액 = self.get_sum_of_purchases(['전자계산서'], 'value_of_supply')

    @property
    def 과세기간시작일자(self):
        from accounting.models import VAT_PERIOD_RANGE

        year, half = self.tax.period.split('-')
        return '{}{:02}{:02}'.format(year,
                                     VAT_PERIOD_RANGE[half][0][0],
                                     VAT_PERIOD_RANGE[half][0][1])

    @property
    def 과세기간종료일자(self):
        from accounting.models import VAT_PERIOD_RANGE

        year, half = self.tax.period.split('-')
        return '{}{:02}{:02}'.format(year,
                                     VAT_PERIOD_RANGE[half][1][0],
                                     VAT_PERIOD_RANGE[half][1][1])

    @property
    def 작성일자(self):
        from accounting.models import VAT_PERIOD_RANGE

        year, half = self.tax.period.split('-')
        year = int(year)
        if half == '2H':
            year += 1

        return '{}{:02}{:02}'.format(year,
                                     VAT_PERIOD_RANGE[half][2][1],
                                     VAT_PERIOD_RANGE[half][2][2])

    @property
    def 반기구분(self):
        if self.tax.type == 'vat-simplified':
            return 1

        _, half = self.tax.period.split('-')
        return half[:1]

    @property
    def 반기내월순번(self):
        # TODO: 확정 신고만 구현되어있음
        # 반기내 귀속되는 월의 순차번호, (귀속월 - 1) % 6 + 1
        # 단, 예정신고는 3, 확정신고는 6
        return 6


class 종합소득세:
    REPORT_TYPES = {
        '11': '자기조정',
        '12': '외부조정',
        '14': '성실신고확인',
        '20': '간편장부',
        '31': '추계-기준율',
        '32': '추계-단순율',
        '40': '비사업자',
    }
    BOOKKEEPING_DUTY = {
        '01': '복식부기의무자',
        '02': '간편장부대상자',
        '03': '비사업자',
    }
    DEPUTY = {
        '01': '기장',
        '02': '조정',
        '03': '신고',
        '04': '확인',
    }
    PARTS = {
        'income_tax_part_20': '소득공제',
        'income_tax_part_24': '세액감면',
        'income_tax_part_25': '세액공제',
        'income_tax_part_27': '가산세',
        'income_tax_part_28': '추가납부세액',
        'income_tax_part_30': '기납부세액',
        'income_tax_part_32': '납부특례세액_차감',
        'income_tax_part_33': '납부특례세액_가산',
        'income_tax_part_34': '분납할세액',
        'income_tax_part_70': '분납할세액_농어촌특별세',
    }

    def __init__(self, tax):
        self.tax = tax
        self.매출 = self.tax.trader.invoice_set.filter(invoice_type='sales', issued__range=self.tax.range()) \
                          .aggregate(Sum('value_of_supply'))['value_of_supply__sum'] or 0
        self.매입 = self.tax.trader.invoice_set.filter(invoice_type='purchases', issued__range=self.tax.range()) \
                      .aggregate(Sum('value_of_supply'))['value_of_supply__sum'] or 0

        self.경비 = self.tax.trader.journalentry_set.filter(type='차변', issued__range=self.tax.range()).aggregate(Sum('amount'))['amount__sum'] or 0
        self.종합소득금액 = self.매출 - self.매입 - self.경비

        부양가족수 = 1
        인적공제 = 1500000 * 부양가족수
        self.소득공제 = self.tax.info.get('소득공제', 인적공제)
        self.과세표준 = self.종합소득금액 - self.소득공제
        self.과세표준_지방소득세 = self.과세표준
        self.과세표준_농어촌특별세 = 0

        if self.과세표준 <= 12000000:
            self.세율 = Decimal('0.06')
            self.누진공제 = 0

        elif self.과세표준 <= 46000000:
            self.세율 = Decimal('0.15')
            self.누진공제 = 1080000

        elif self.과세표준 <= 88000000:
            self.세율 = Decimal('0.24')
            self.누진공제 = 5220000

        elif self.과세표준 <= 150000000:
            self.세율 = Decimal('0.35')
            self.누진공제 = 14900000
        else:
            self.세율 = Decimal('0.38')
            self.누진공제 = 19400000

        self.세율_지방소득세 = self.세율 * Decimal('0.1')
        self.세율_농어촌특별세 = Decimal(0)

        self.산출세액 = self.과세표준 * self.세율
        self.산출세액_지방소득세 = self.과세표준_지방소득세 * self.세율_지방소득세
        self.산출세액_농어촌특별세 = self.과세표준_농어촌특별세 * self.세율_농어촌특별세

        self.세액감면 = self.tax.info.get('세액감면', 0)
        self.세액감면_지방소득세 = self.세액감면 * Decimal(0.1)

        표준세액공제 = 70000
        self.세액공제 = self.tax.info.get('세액공제', 표준세액공제)
        self.세액공제_지방소득세 = self.세액공제 * Decimal(0.1)

        self.결정세액 = self.산출세액 - self.세액감면 - self.세액공제
        self.결정세액_지방소득세 = self.산출세액_지방소득세 - self.세액감면_지방소득세 - self.세액공제_지방소득세
        self.결정세액_농어촌특별세 = self.산출세액_농어촌특별세

        self.가산세 = self.tax.info.get('가산세', 0)
        self.가산세_지방소득세 = self.tax.info.get('가산세_지방소득세', 0)
        self.가산세_농어촌특별세 = self.tax.info.get('가산세_농어촌특별세', 0)

        self.추가납부세액 = self.tax.info.get('추가납부세액', 0)
        self.추가납부세액_지방소득세 = self.tax.info.get('추가납부세액_지방소득세', 0)
        self.추가납부세액_농어촌특별세 = self.tax.info.get('추가납부세액_농어촌특별세', 0)

        self.합계 = self.결정세액 + self.가산세 + self.추가납부세액
        self.합계_지방소득세 = self.결정세액_지방소득세 + self.가산세_지방소득세 + self.추가납부세액_지방소득세
        self.합계_농어촌특별세 = self.결정세액_농어촌특별세 + self.가산세_농어촌특별세 + self.추가납부세액_농어촌특별세

        self.기납부세액 = self.tax.info.get('기납부세액', 0)
        self.기납부세액_지방소득세 = self.tax.info.get('기납부세액_지방소득세', 0)
        self.기납부세액_농어촌특별세 = self.tax.info.get('기납부세액_농어촌특별세', 0)

        self.총세액 = self.합계 - self.기납부세액
        self.총세액_지방소득세 = self.결정세액_지방소득세 + self.가산세_지방소득세 + self.추가납부세액_지방소득세
        self.총세액_농어촌특별세 = self.결정세액_농어촌특별세 + self.가산세_농어촌특별세 + self.추가납부세액_농어촌특별세

        self.납부특례세액_차감 = self.tax.info.get('납부특례세액_차감', 0)
        self.납부특례세액_가산 = self.tax.info.get('납부특례세액_가산', 0)

        self.분납할세액 = self.tax.info.get('분납할세액', 0)
        self.분납할세액_농어촌특별세 = self.tax.info.get('분납할세액_농어촌특별세', 0)

        self.신고기한내납부할세액 = self.총세액 - self.납부특례세액_차감 + self.납부특례세액_가산 - self.분납할세액
        self.신고기한내납부할세액_지방소득세 = self.총세액_지방소득세
        self.신고기한내납부할세액_농어촌특별세 = self.총세액_농어촌특별세 - self.분납할세액_농어촌특별세


class 원천세:
    PARTS = {
        'withholding_tax_part_report_detail_code': '신고구분상세코드',
        'withholding_tax_part_a04_1': '연말정산합계인원',
        'withholding_tax_part_a04_2': '연말정산합계총지급액',
        'withholding_tax_part_a04_3': '연말정산합계징수세액소득세',
        'withholding_tax_part_a04_4': '연말정산합계징수세액농특세',
        'withholding_tax_part_a05_1': '연말분납신청인원',
        'withholding_tax_part_a05_2': '연말정산분납신청징수세액소득세',
        'withholding_tax_part_a05_3': '연말정산분납신청징수세액농특세',
        'withholding_tax_part_a06_1': '연말정산납부금액징수세액소득세',
        'withholding_tax_part_a06_2': '연말정산납부금액징수세액농특세',
        'withholding_tax_part_a20': '퇴직소득',
        'withholding_tax_part_refund_1': '환급신청여부',
        'withholding_tax_part_refund_2': '환급신청액',
        'withholding_tax_part_refund_additional': '환급신청부표',
        'withholding_tax_part_refund_summary': '원천징수신고납부현황',
        'withholding_tax_part_refund_paid_tax': '지급명세서기납부세액현황',
        'withholding_tax_part_refund_reason1': '사유코드_중도퇴사자',
        'withholding_tax_part_refund_reason2': '사유코드_전입자',
        'withholding_tax_part_refund_reason3': '사유코드_전출자',
        'withholding_tax_part_refund_reason4': '사유코드_합병분할',
        'withholding_tax_part_refund_reason5': '사유코드_기타',
        'withholding_tax_part_refund_reason_content': '사유내용',
    }
    
    CODES = {
        '신고구분상세코드': {
            '정기신고': '01',
            '수정신고': '02',
            '기한후신고': '03',
        },
        '환급신청소득종류': [
            ['근로', 14],
            ['퇴직', 21],
            ['사업', 13],
            ['기타', 16],
            ['연금', 17],
            ['이자', 11],
            ['배당', 12],
            ['양도', 22],
            ['법인', 31],
            ['수정', 90],
        ],
        '세목코드': {
            14: [
                ['간이세액', 'A01'],
                ['중도퇴사', 'A02'],
                ['일용근로', 'A03'],
                ['연말정산 합계', 'A04'],
                ['저축해지 추징세액 등', 'A69'],
            ],
            21: [
                ['연금계좌', 'A21'],
                ['그 외', 'A22'],
            ],
            13: [
                ['매월징수', 'A25'],
                ['연말정산', 'A26'],
            ],
            16: [
                ['연금계좌', 'A41'],
                ['그 외', 'A42'],
            ],
            17: [
                ['연금계좌', 'A48'],
                ['공적연금(매월)', 'A45'],
                ['연말정산', 'A46'],
            ],
            11: [
                ['이자소득', 'A50'],
            ],
            12: [
                ['배당소득', 'A60'],
            ],
            22: [
                ['비거주자', 'A70'],
            ],
            31: [
                ['내외국법인', 'A80'],
            ],
            90: [
                ['수정신고', 'A90'],
            ]
        }
    }

    def to_json(self):
        return json.dumps(self, default=lambda o: float(o) if isinstance(o, Decimal) else o.__dict__)

    def __init__(self, tax):
        self.records = {}

        self.귀속연월 = tax.period
        try:
            귀속연월 = datetime.strptime(tax.period, '%Y-%m')
        except ValueError:
            귀속연월 = datetime.strptime(tax.period, '%Y%m')

        self.마감 = tax.ready_to_report is not None
        self.신고구분상세코드 = tax.info.get('신고구분상세코드', '정기신고')
        self.민원종류코드 = 'FF001'
        if self.신고구분상세코드 == '수정신고':
            self.민원종류코드 = 'FF101'

        from accounting.models import Salary
        salaries = Salary.objects.filter(employee__trader=tax.trader, month__year=귀속연월.year,
                                         month__month=귀속연월.month)

        간이세액 = 원천세.filter_salaries('A01', salaries)
        중도퇴사 = 원천세.filter_salaries('A02', salaries, 귀속연월)
        일용직 = 원천세.filter_salaries('A03', salaries)
        사업소득매월징수 = 원천세.filter_salaries('A25', salaries)

        연말정산합계필드 = ['연말정산합계인원', '연말정산합계총지급액', '연말정산합계징수세액소득세', '연말정산합계징수세액농특세']
        self.연말정산여부 = 'Y' if sum(int(tax.info.get(field, 0)) for field in 연말정산합계필드) > 0 else 'N'
        self.환급신청여부 = tax.info.get('환급신청여부', 'N')

        # 간이세액(근로소득)
        self.records['A01'] = {}
        self.records['A01']['인원'] = len(간이세액)
        self.records['A01']['총지급액'] = sum(salary.base_pay for salary in 간이세액)
        self.records['A01']['징수세액소득세'] = sum(salary.income_tax for salary in 간이세액)
        self.records['A01']['징수세액농특세'] = sum(salary.rural_special_tax for salary in 간이세액)

        # 중도퇴사
        self.records['A02'] = {}
        self.records['A02']['인원'] = len(중도퇴사)
        중도연말정산계 = 원천세.중도연말정산(중도퇴사, 귀속연월)
        self.records['A02']['총지급액'] = 중도연말정산계['총지급액']
        self.records['A02']['징수세액소득세'] = 중도연말정산계['소득세']
        self.records['A02']['징수세액농특세'] = 중도연말정산계['농특세']

        # 일용직
        self.records['A03'] = {}
        self.records['A03']['인원'] = len(일용직)
        self.records['A03']['총지급액'] = sum(salary.base_pay for salary in 일용직)
        self.records['A03']['징수세액소득세'] = sum(salary.income_tax for salary in 일용직)
        self.records['A03']['징수세액농특세'] = sum(salary.rural_special_tax for salary in 일용직)

        # 연말정산 - 합계
        self.records['A04'] = {}
        self.records['A04']['인원'] = int(tax.info.get('연말정산합계인원', 0))
        self.records['A04']['총지급액'] = int(tax.info.get('연말정산합계총지급액', 0))
        self.records['A04']['징수세액소득세'] = int(tax.info.get('연말정산합계징수세액소득세', 0))
        self.records['A04']['징수세액농특세'] = int(tax.info.get('연말정산합계징수세액농특세', 0))

        # 연말정산 - 분납신청
        self.records['A05'] = {}
        self.records['A05']['인원'] = tax.info.get('연말분납신청인원', 0)
        self.records['A05']['총지급액'] = 0
        self.records['A05']['징수세액소득세'] = tax.info.get('연말정산분납신청징수세액소득세', 0)
        self.records['A05']['징수세액농특세'] = tax.info.get('연말정산분납신청징수세액농특세', 0)

        # 연말정산 - 납부금액
        self.records['A06'] = {}
        self.records['A06']['인원'] = 0
        self.records['A06']['총지급액'] = 0
        self.records['A06']['징수세액소득세'] = tax.info.get('연말정산납부금액징수세액소득세', 0)
        self.records['A06']['징수세액농특세'] = tax.info.get('연말정산납부금액징수세액농특세', 0)

        # 가감계
        가감계코드 = ['A01', 'A02', 'A03', 'A04']
        self.records['A10'] = {}
        self.records['A10']['인원'] = sum(self.records[code]['인원'] for code in 가감계코드)
        self.records['A10']['총지급액'] = sum(self.records[code]['총지급액'] for code in 가감계코드)
        self.records['A10']['징수세액소득세'] = sum(self.records[code]['징수세액소득세'] for code in 가감계코드)
        self.records['A10']['징수세액농특세'] = sum(self.records[code]['징수세액농특세'] for code in 가감계코드)
        self.records['A10']['가산세'] = 0

        self.records['A22'] = {}
        '''
        퇴직금액은 Employee.severance_pay() 에서 자동계산되나, 매니저가 직접 입력하는 경우도 존재함
        해당금액은 tax.info['퇴직소득']에 다음과 같이 기록되어있음
        
        [{ id: '퇴직한 Employee의 id', 'severance_pay': Decimal }, ...]
        
        위의 정보를 가지고, 해당 퇴직금액에 따른 Employee가 납부해야할 퇴직소득이 원천세.퇴직소득세계산() 에서 계산된다
        '''
        self.퇴직소득 = tax.info.get('퇴직소득', [])
        self.records['A22']['인원'] = len(self.퇴직소득)
        self.records['A22']['총지급액'] = sum([int(x['severance_pay']) for x in self.퇴직소득])
        self.records['A22']['징수세액소득세'] = sum([int(원천세.퇴직소득세계산(x)) for x in self.퇴직소득])
        self.records['A22']['징수세액농특세'] = 0

        self.records['A20'] = {}
        self.records['A20']['인원'] = self.records['A22']['인원']
        self.records['A20']['총지급액'] = self.records['A22']['총지급액']
        self.records['A20']['징수세액소득세'] = self.records['A22']['징수세액소득세']
        self.records['A20']['징수세액농특세'] = self.records['A22']['징수세액농특세']
        self.records['A20']['가산세'] = 0

        # 사업소득 매월징수
        self.records['A25'] = {}
        self.records['A25']['인원'] = len(사업소득매월징수)
        self.records['A25']['총지급액'] = sum(salary.base_pay for salary in 사업소득매월징수)
        self.records['A25']['징수세액소득세'] = sum(salary.income_tax for salary in 사업소득매월징수)
        self.records['A25']['징수세액농특세'] = sum(salary.rural_special_tax for salary in 사업소득매월징수)

        # 사업소득 가감계
        self.records['A30'] = {}
        self.records['A30']['인원'] = self.records['A25']['인원']
        self.records['A30']['총지급액'] = self.records['A25']['총지급액']
        self.records['A30']['징수세액소득세'] = self.records['A25']['징수세액소득세']
        self.records['A30']['징수세액농특세'] = self.records['A25']['징수세액농특세']
        self.records['A30']['가산세'] = 0

        # 수정신고(세액)
        self.records['A90'] = {}
        self.records['A90']['인원'] = 0
        self.records['A90']['총지급액'] = 0
        change_list = tax.info.get('수정신고세액변동', [])
        self.records['A90']['징수세액소득세'] = sum([tax.trader.tax_set.get(id=tax_id).info['수정신고발생소득세'] for tax_id in change_list])
        self.records['A90']['징수세액농특세'] = sum([tax.trader.tax_set.get(id=tax_id).info['수정신고발생농특세'] for tax_id in change_list])
        self.records['A90']['가산세'] = sum([tax.trader.tax_set.get(id=tax_id).info['수정신고발생가산세'] for tax_id in change_list])

        # 총합계
        self.가감계 = ['A10', 'A20', 'A30', 'A90']
        self.records['A99'] = {}
        self.records['A99']['인원'] = sum(self.records[code]['인원'] for code in self.가감계)
        self.records['A99']['총지급액'] = sum(self.records[code]['총지급액'] for code in self.가감계)
        self.records['A99']['징수세액소득세'] = sum(tax for tax in [self.records[code]['징수세액소득세'] for code in self.가감계] if tax > 0)
        self.records['A99']['징수세액농특세'] = sum(tax for tax in [self.records[code]['징수세액농특세'] for code in self.가감계] if tax > 0)
        self.records['A99']['가산세'] = sum(self.records[code]['가산세'] for code in self.가감계)

        self.징수금액 = self.records['A99']['징수세액소득세'] + self.records['A99']['징수세액농특세'] + self.records['A99']['가산세']

        # 환급
        self.전월미환급세액 = None
        self.기환급신청세액 = None
        self.차감잔액 = None
        self.일반환급세액 = None
        self.신탁재산세액 = None
        self.그밖의환급세액금융회사 = None
        self.그밖의환급세액합병 = None
        self.조정대상환급세액 = None
        self.당월조정환급세액계 = None
        self.차월이월환급세액 = None

        self.조정환급(tax)

        self.납부금액 = self.records['A99']['납부세액소득세'] + self.records['A99']['납부세액농특세']

        self.환급신청액 = tax.info.get('환급신청액', 0) if tax.info.get('환급신청여부') == 'Y' else 0
        self.승계대상합계차월이월환급세액 = 0

        # 환급신청부표
        if tax.info.get('환급신청여부') == 'Y':
            환급신청부표 = tax.info.get('환급신청부표', [])
            self.환급신청부표 = []
            for 부표 in 환급신청부표:
                self.환급신청부표.append({
                    '소득종류': 부표.get('소득종류', 14),
                    '귀속연월': 부표.get('귀속연월', 귀속연월.strftime('%Y%m')),
                    '지급연월': 부표.get('지급연월', 귀속연월.strftime('%Y%m')),
                    '코드': 부표.get('코드', 'A01'),
                    '인원': 부표.get('인원', 0),
                    '소득지급액': 부표.get('소득지급액', 0),
                    '결정세액': 부표.get('결정세액', 0),
                    '기납부계': 부표.get('기납부계', 0),
                    '기납부주': 부표.get('기납부주', 0),
                    '기납부종': 부표.get('기납부종', 0),
                    '차감세액': 부표.get('차감세액', 0),
                    '분납금액': 부표.get('분납금액', 0),
                    '조정환급': 부표.get('조정환급', 0),
                    '환급신청액': 부표.get('환급신청액', 0),
                })

            self.환급신청부표합계 = {}
            sum_fields = ['인원', '소득지급액', '결정세액', '기납부계', '기납부주', '기납부종', '차감세액', '분납금액', '조정환급', '환급신청액']
            for field in sum_fields:
                self.환급신청부표합계[field] = sum(부표[field] for 부표 in self.환급신청부표)
                
            from django.db import connection
            truncate_date = connection.ops.date_trunc_sql('month', 'month')
            summaries = Salary.objects.filter(
                employee__trader=tax.trader,
                month__year=귀속연월.year-1,
            ).extra({'month': truncate_date}).values('month', 'employee__type').annotate(
                Count('id'), Sum('base_pay'), Sum('income_tax'), Sum('rural_special_tax')
            ).order_by('month')

            selected = tax.info.get('원천징수신고납부현황', [])
            self.원천징수신고납부현황 = []
            for summary in summaries:
                if summary['month'].strftime('%Y%m') in selected:
                    self.원천징수신고납부현황.append({
                        '귀속연월': summary['month'].strftime('%Y%m'),
                        '지급연월': summary['month'].strftime('%Y%m'),
                        '종류': 원천세.to_code(summary['employee__type']),
                        '인원': summary['id__count'],
                        '총지급액': summary['base_pay__sum'],
                        '징수세액소득세': summary['income_tax__sum'],
                        '징수세액농특세': summary['rural_special_tax__sum'],
                        '징수세액가산세': 0,
                    })

            self.신고납부현황_합계_인원 = sum(납부현황['인원'] for 납부현황 in self.원천징수신고납부현황)
            self.신고납부현황_합계_총지급액 = sum(납부현황['총지급액'] for 납부현황 in self.원천징수신고납부현황)
            self.신고납부현황_합계_징수세액소득세 = sum(납부현황['징수세액소득세'] for 납부현황 in self.원천징수신고납부현황)
            self.신고납부현황_합계_징수세액농특세 = sum(납부현황['징수세액농특세'] for 납부현황 in self.원천징수신고납부현황)
            self.신고납부현황_합계_징수세액가산세 = sum(납부현황['징수세액가산세'] for 납부현황 in self.원천징수신고납부현황)

            # 지급명세서 기납부세액 현황
            self.지급명세서 = []
            selected = tax.info.get('지급명세서기납부세액현황', [])
            salaries_per_employee = Salary.objects.filter(employee__in=selected, month__year=귀속연월.year - 1).order_by(
                '-employee').values('employee').annotate(Sum('income_tax'), Sum('rural_special_tax'))

            for salary in salaries_per_employee:
                from accounting.models import Employee
                employee = Employee.objects.get(id=salary['employee'])
                self.지급명세서.append({
                    'id': employee.id,
                    '주민번호': employee.registration_no,
                    '성명': employee.name,
                    '종(전)근무지': employee.info.get('종(전)근무지', ''),
                    '종(전)근무지_사업자등록번호': employee.info.get('종(전)근무지_사업자등록번호', ''),
                    '주소득세': salary['income_tax__sum'],
                    '주농특세': salary['rural_special_tax__sum'],
                    '종소득세': employee.info.get('종(전)_소득세', 0),
                    '종농특세': employee.info.get('종(전)_농특세', 0),
                    '소득세계': salary['income_tax__sum'] + employee.info.get('종(전)_소득세', 0),
                    '농특세계': salary['rural_special_tax__sum'] + employee.info.get('종(전)_농특세', 0),
                })

            self.기납부세액현황_합계_주소득세 = sum(지급명세['주소득세'] for 지급명세 in self.지급명세서)
            self.기납부세액현황_합계_주농특세 = sum(지급명세['주농특세'] for 지급명세 in self.지급명세서)
            self.기납부세액현황_합계_종소득세 = sum(지급명세['종소득세'] for 지급명세 in self.지급명세서)
            self.기납부세액현황_합계_종농특세 = sum(지급명세['종농특세'] for 지급명세 in self.지급명세서)
            self.기납부세액현황_합계_소득세계 = sum(지급명세['소득세계'] for 지급명세 in self.지급명세서)
            self.기납부세액현황_합계_농특세계 = sum(지급명세['농특세계'] for 지급명세 in self.지급명세서)

            self.차이조정현황_소득세합계 = sum(납부현황['징수세액소득세'] for 납부현황 in self.원천징수신고납부현황)
            self.차이조정현황_주소득세합계 = sum(지급명세['주소득세'] for 지급명세 in self.지급명세서)
            self.차이조정현황_소득세차이금액 = self.차이조정현황_주소득세합계 - self.차이조정현황_소득세합계
            self.차이조정현황_농특세합계 = sum(납부현황['징수세액농특세'] for 납부현황 in self.원천징수신고납부현황)
            self.차이조정현황_주농특세합계 = sum(지급명세['주농특세'] for 지급명세 in self.지급명세서)
            self.차이조정현황_농특세차이금액 = self.차이조정현황_주농특세합계 - self.차이조정현황_농특세합계

            self.차이조정현황_사유코드_중도퇴사자 = tax.info.get('사유코드_중도퇴사자', 'N')
            self.차이조정현황_사유코드_전입자 = tax.info.get('사유코드_전입자', 'N')
            self.차이조정현황_사유코드_전출자 = tax.info.get('사유코드_전출자', 'N')
            self.차이조정현황_사유코드_합병분할 = tax.info.get('사유코드_합병분할', 'N')
            self.차이조정현황_사유코드_기타 = tax.info.get('사유코드_기타', 'N')
            self.차이조정현황_사유내용 = tax.info.get('사유내용', '')

    def 조정환급(self, tax):
        try:
            귀속연월 = datetime.strptime(tax.period, '%Y-%m')
        except ValueError:
            귀속연월 = datetime.strptime(tax.period, '%Y%m')
        이전연월 = 귀속연월 - relativedelta(months=1)
        from accounting.models import Tax
        previous_tax = Tax.objects.filter(trader=tax.trader, period=이전연월.strftime('%Y-%m'), type='withholding-tax').first()
        self.전월미환급세액 = int(previous_tax.info.get('차월이월환급세액', 0)) if previous_tax else 0
        self.기환급신청세액 = int(previous_tax.info.get('환급신청액', 0)) if previous_tax and previous_tax.info.get('환급신청여부') == 'Y' else 0
        self.차감잔액 = self.전월미환급세액 - self.기환급신청세액
        self.일반환급세액 = abs(sum(tax for tax in [self.records[code][field] for code in self.가감계 for field in ['징수세액소득세', '징수세액농특세']] if tax < 0))
        self.신탁재산세액 = 0
        self.그밖의환급세액금융회사 = 0
        self.그밖의환급세액합병 = 0
        self.조정대상환급세액 = self.차감잔액 + self.일반환급세액 + self.신탁재산세액 + self.그밖의환급세액금융회사 + self.그밖의환급세액합병

        # 당월조정환급세액, 납부세액 계산
        조정환급세액 = self.조정대상환급세액
        if self.신고구분상세코드 == '수정신고':
            # 당월이전신고tax 당월 이전신고가 마감되지 않은 경우는 에러
            try:
                previous_reported_tax = tax.get_previous_by_created(trader=tax.trader, period=tax.period,
                                                                    type=tax.type, ready_to_report__isnull=False)
                reported = json.loads(previous_reported_tax.info['reported'])
                # 이전 신고와 조정환급세액이 달라진 경우에만 계산값을 조정한다
                if 조정환급세액 != reported['조정대상환급세액']:
                    조정환급세액 = 조정환급세액 - int(reported['차월이월환급세액'])
            except ObjectDoesNotExist as e:
                logging.exception(e)

        for code in self.가감계:
            # 납부세액에 가산세항목은 없기때문에 가산세의 경우 소득세/농특세쪽으로 합산해서 계산해야함.
            records = self.records[code].copy()
            if records.get('징수세액농특세'):
                records['징수세액농특세'] = self.records[code]['징수세액농특세'] + self.records[code]['가산세']
            else:
                records['징수세액소득세'] = self.records[code]['징수세액소득세'] + self.records[code]['가산세']

            # 징수세액란에 납부세액이 있는 경우, 순서대로 조정환급함
            # [⑥ 소득세 등] → [⑧ 가산세] → [⑦ 농어촌특별세] ( 소득세는 위에 계산 됨 )
            pre_calculated = 조정환급세액
            세액종목 = ['소득세', '농특세']
            for 종목 in 세액종목:
                징수세액 = records['징수세액' + 종목]
                if 징수세액 <= 0:
                    self.records[code]['납부세액' + 종목] = 0
                    continue

                납부세액 = 징수세액 - 조정환급세액
                if 납부세액 < 0:
                    납부세액 = 0
                    조정환급세액 = 조정환급세액 - 징수세액
                else:
                    조정환급세액 = 0

                self.records[code]['납부세액' + 종목] = 납부세액
            self.records[code]['당월조정환급세액'] =  pre_calculated - 조정환급세액

        # 조정환급적용
        self.records['A99']['당월조정환급세액'] = sum(self.records[code]['당월조정환급세액'] for code in self.가감계)
        self.records['A99']['납부세액소득세'] = sum(self.records[code]['납부세액소득세'] for code in self.가감계)
        self.records['A99']['납부세액농특세'] = sum(self.records[code]['납부세액농특세'] for code in self.가감계)

        self.당월조정환급세액계 = self.records['A99']['당월조정환급세액']
        self.차월이월환급세액 = self.조정대상환급세액 - self.당월조정환급세액계

    @staticmethod
    def filter_salaries(code, salaries, 귀속연월=None):
        commands = {
            'A01': lambda x: x.employee.type == '정직원',
            'A02': lambda x: x.employee.quitted.strftime('%Y%m') == 귀속연월.strftime(
                '%Y%m') and (x.employee.quitted - x.employee.joined).days < 365 if 귀속연월 and x.employee.quitted and x.employee.joined else [],
            'A03': lambda x: x.employee.type == '일용직' ,
            'A10': lambda x: x.employee.type in ['정직원', '일용직'],
            'A25': lambda x: x.employee.type == '프리랜서',
            'A99': lambda x: x.employee.type in ['정직원', '일용직'],
        }
        return list(filter(commands[code], salaries)) if code in commands else []

    @staticmethod
    def to_code(소득종류):
        code_map = {
            '정직원': 'A01',
            '일용직': 'A03',
            '프리랜서': 'A25',
        }
        return code_map[소득종류]

    @staticmethod
    def 중도연말정산(중도퇴사, 귀속연월):
        from accounting.models import Salary
        계 = {}
        annotated = Salary.objects.filter(
            employee__in=[x.employee for x in 중도퇴사],
            month__year=귀속연월.year).values('employee', 'employee__dependents').annotate(
            Sum('base_pay'), Sum('income_tax'), Sum('national_pension'), Sum('national_pension_adjustment')
        )
        계['총지급액'] = sum(x['base_pay__sum'] for x in annotated)

        차감세액 = []
        for 연간지급내역 in annotated:
            총급여 = int(연간지급내역['base_pay__sum'])
            근로소득공제 = 0
            if 총급여 <= 5000000:
                근로소득공제 = 총급여 * 0.7
            elif 5000000 < 총급여 <= 15000000:
                근로소득공제 = 3500000 + (총급여 - 5000000) * 0.4
            elif 15000000 < 총급여 <= 45000000:
                근로소득공제 = 7500000 + (총급여 - 15000000) * 0.15
            elif 45000000 < 총급여 <= 100000000:
                근로소득공제 = 12000000 + (총급여 - 45000000) * 0.05
            else:
                근로소득공제 = 147500000 + (총급여 - 100000000) * 0.05

            근로소득금액 = int(총급여 - 근로소득공제)
            인적공제 = 연간지급내역['employee__dependents'] * 1500000
            국민연금공제 = 연간지급내역['national_pension__sum'] + 연간지급내역['national_pension_adjustment__sum']
            특별공제 = 0
            과세표준 = int(근로소득금액 - 인적공제 - 국민연금공제 - 특별공제)
            if 과세표준 <= 0:
                과세표준 = 0
            산출세액 = 0

            if 과세표준 <= 12000000:
                산출세액 = 과세표준 * 0.06
            elif 12000000 < 과세표준 <= 46000000:
                산출세액 = 720000 + (과세표준 - 12000000) * 0.15
            elif 46000000 < 과세표준 <= 88000000:
                산출세액 = 5820000 + (과세표준 - 46000000) * 0.24
            elif 88000000 < 과세표준 <= 150000000:
                산출세액 = 15900000 + (과세표준 - 88000000) * 0.35
            else:
                산출세액 = 37600000 + (과세표준 - 150000000) * 0.38

            근로소득공제 = 0
            if 산출세액 <= 1300000:
                근로소득공제 = 산출세액 * 0.55
            else:
                근로소득공제 = 715000 + (산출세액 - 1300000) * 0.3
            특별세액공제 = 130000 if 과세표준 > 0 else 0

            결정세액 = int(산출세액 - 근로소득공제 - 특별세액공제)
            기납부소득세 = int(연간지급내역['income_tax__sum'])
            차감세액.append(결정세액 - 기납부소득세)

        계['소득세'] = sum(차감세액)
        계['농특세'] = 0
        return 계

    @staticmethod
    def 퇴직소득세계산(info):
        from accounting.models import Employee
        try:
            employee = Employee.objects.get(id=info['id'])
        except:
            return 0
        퇴직소득 = Decimal(info['severance_pay'])
        if 퇴직소득 <= 0:
            return 0
        if employee.joined is None:
            return 0
        근속연수 = int((employee.quitted - employee.joined).days / 365)
        # 근속연수가 적은경우도, 금액만 직접입력하는 경우가 있음. 이 경우 최소 1년으로 처리
        if 근속연수 < 1:
            근속연수 = 1
        # 종전산출세액 ( 60% )
        정률공제 = 퇴직소득 * Decimal(0.4)
        근속연수공제 = 0
        if 근속연수 <= 5:
            근속연수공제 = 300000 * 근속연수
        elif 5 < 근속연수 <= 10:
            근속연수공제 = 1500000 + (500000 * (근속연수 - 5))
        elif 10 < 근속연수 <= 20:
            근속연수공제 = 4000000 + (800000 * (근속연수 - 10))
        elif 20 < 근속연수:
            근속연수공제 = 12000000 + (1200000 * (근속연수 - 20))

        종전과세표준 = 퇴직소득 - (정률공제 + 근속연수공제)
        # TODO 2012년 12월 31일 이전 산술방식
        # 2012년 12월 31일 이후 산술방식
        연분과세표준 = 종전과세표준 * 5 / 근속연수
        연분산출세액 = 0
        if 연분과세표준 <= 12000000:
            연분산출세액 = round(연분과세표준 * Decimal(0.06))
        elif 12000000 < 연분과세표준 <= 46000000:
            연분산출세액 = round(연분과세표준 * Decimal(0.15))
        elif 46000000 < 연분과세표준 <= 88000000:
            연분산출세액 = round(연분과세표준 * Decimal(0.24))
        elif 88000000 < 연분과세표준 <= 150000000:
            연분산출세액 = round(연분과세표준 * Decimal(0.35))
        elif 150000000 < 연분과세표준:
            연분산출세액 = round(연분과세표준 * Decimal(0.38))

        종전산출세액 = Decimal(연분산출세액) * 근속연수 / 5

        # 개정산출세액 ( 40% )
        환산급여 = (퇴직소득 - 근속연수공제) * 12 / 근속연수
        차등공제액 = 0
        if 환산급여 <= 8000000:
            차등공제액 = 환산급여
        elif 8000000 < 환산급여 <= 70000000:
            차등공제액 = 8000000 + ((환산급여 - 8000000) * Decimal(0.6))
        elif 70000000 < 환산급여 <= 100000000:
            차등공제액 = 45200000 + ((환산급여 - 70000000) * Decimal(0.55))
        elif 100000000 < 환산급여 <= 300000000:
            차등공제액 = 61700000 + ((환산급여 - 100000000) * Decimal(0.45))
        elif 300000000 < 환산급여:
            차등공제액 = 151700000 + ((환산급여 - 300000000) * Decimal(0.35))

        연평균과세표준 = 환산급여 - 차등공제액
        환산산출세액 = 0
        if 연평균과세표준 <= 12000000:
            환산산출세액 = round(연평균과세표준 * Decimal(0.06))
        elif 12000000 < 연평균과세표준 <= 46000000:
            환산산출세액 = round(연평균과세표준 * Decimal(0.15))
        elif 46000000 < 연평균과세표준 <= 88000000:
            환산산출세액 = round(연평균과세표준 * Decimal(0.24))
        elif 88000000 < 연평균과세표준 <= 150000000:
            환산산출세액 = round(연평균과세표준 * Decimal(0.35))
        elif 150000000 < 연분과세표준:
            환산산출세액 = round(연평균과세표준 * Decimal(0.38))
        산출세액 = Decimal(환산산출세액) / 12 * 근속연수

        최종산출세액 = round(floor((종전산출세액 * Decimal(0.6)) + (산출세액 * Decimal(0.4)), -1))
        return 최종산출세액

