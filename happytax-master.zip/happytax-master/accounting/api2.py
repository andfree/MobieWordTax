import datetime
import hashlib
import json

from django.core import signing
from django.db import models
from django.db.models import Q, Sum
from django.http import Http404, HttpResponseBadRequest
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import viewsets, permissions, serializers, status
from rest_framework.decorators import action
from rest_framework.response import Response

from accounting.codef import create_account, add_account, encrypt, login_to_hometax, delete_account, login_to_card_sales
from accounting.controllers.files import file_url
from accounting.models import Message, Boilerplate, Trader, User, Attachment, Voucher, Read, Report, \
    ensure_mobiletax_user, ConnectedId, Account, Hometax, CardSales, VAT_PERIOD_RANGE, CardSalesApproval, Check, \
    CardApproval, WithholdingTax, CashSalesReceipt, CashPurchaseReceipt
from accounting.report import 데이터, 자료
from accounting.tasks import init_account, init_card_sales, init_hometax


class IsOwner(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.method in ('GET', 'POST', 'DELETE',)

    def has_object_permission(self, request, view, obj):
        if obj.sender == request.user:
            return True

        if not request.user.is_staff:
            return False

        if obj.sender == ensure_mobiletax_user():
            return True

        if obj.sender.id == 22:
            return True

        if obj.trader.accounting_manager == request.user:
            return True

        return False


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'name',)


class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

    @action(methods=['get'], detail=False)
    def me(self, request):
        return Response(UserSerializer(request.user).data)

    @action(methods=['post'], detail=True)
    def password(self, request, pk):
        if not self.request.user.is_staff:
            return Response(status=403)

        user = self.get_object()
        user.set_password(request.data['password'])
        user.save()
        return Response()


class HometaxSerializer(serializers.ModelSerializer):
    trader = serializers.PrimaryKeyRelatedField(queryset=Trader.objects, write_only=True)
    password = serializers.CharField(write_only=True)

    class Meta:
        model = Hometax
        fields = '__all__'

    def create(self, validated_data):
        validated_data['password'] = encrypt(validated_data['password'])
        return super().create(validated_data)


class HometaxViewSet(viewsets.ModelViewSet):
    queryset = Hometax.objects.all()
    serializer_class = HometaxSerializer

    def get_queryset(self):
        return super().get_queryset().filter(trader__user=self.request.user)

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        if data['trader'].user != request.user:
            return Response(status=status.HTTP_403_FORBIDDEN)

        try:
            login_to_hometax(data['login_type'], data['username'], data['password'])
        except Exception as e:
            return HttpResponseBadRequest(json.dumps(e.args[0]))

        return super().create(request, *args, **kwargs)


class AccountSerializer(serializers.ModelSerializer):
    trader = serializers.PrimaryKeyRelatedField(queryset=Trader.objects, write_only=True)
    username = serializers.CharField(write_only=True)
    password = serializers.CharField(write_only=True)

    class Meta:
        model = Account
        fields = '__all__'

    def create(self, validated_data):
        del validated_data['username']
        del validated_data['password']
        return super().create(validated_data)


class AccountViewSet(viewsets.ModelViewSet):
    queryset = Account.objects.all()
    serializer_class = AccountSerializer

    def get_queryset(self):
        return super().get_queryset().filter(trader__user=self.request.user)

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        trader = data['trader']
        if trader.user != request.user:
            return Response(status=status.HTTP_403_FORBIDDEN)

        connected_id = trader.connectedid_set.first()
        try:
            if connected_id:
                account = add_account(connected_id.connected_id, data['business_type'], data['organization'], 'P', data['login_type'], data['username'], data['password'])
            else:
                account = create_account(data['business_type'], data['organization'], 'P', data['login_type'], data['username'], data['password'])
        except Exception as e:
            return HttpResponseBadRequest(json.dumps(e.args[0]))

        if connected_id and connected_id.connected_id != account['connected_id']:
            connected_id.delete()

        connected_id = account.pop('connected_id')
        ConnectedId.objects.get_or_create(trader=trader, connected_id=connected_id)

        account['trader'] = trader
        account = Account.objects.create(**account)
        headers = self.get_success_headers(serializer.data)
        return Response(AccountSerializer(account).data, status=status.HTTP_201_CREATED, headers=headers)

    def destroy(self, request, *args, **kwargs):
        account = self.get_object()
        connected_id = account.trader.connectedid_set.first()
        if connected_id:
            try:
                delete_account(connected_id.connected_id, account.business_type, account.organization,
                               account.client_type, account.login_type)
            except Exception as e:
                return HttpResponseBadRequest(json.dumps(e.args[0]))

        super().destroy(request, *args, **kwargs)
        return Response()


class ConnectedIdSerializer(serializers.ModelSerializer):
    class Meta:
        model = ConnectedId
        exclude = ('trader',)


class ConnectedIdViewSet(viewsets.ModelViewSet):
    queryset = ConnectedId.objects.all()
    serializer_class = ConnectedIdSerializer


class CardSalesSerializer(serializers.ModelSerializer):
    trader = serializers.PrimaryKeyRelatedField(queryset=Trader.objects, write_only=True)
    username = serializers.CharField(write_only=True)
    password = serializers.CharField(write_only=True)

    class Meta:
        model = CardSales
        fields = '__all__'

    def create(self, validated_data):
        validated_data['password'] = encrypt(validated_data['password'])
        return super().create(validated_data)


class CardSalesViewSet(viewsets.ModelViewSet):
    queryset = CardSales.objects.all()
    serializer_class = CardSalesSerializer

    def get_queryset(self):
        return super().get_queryset().filter(trader__user=self.request.user)

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        if data['trader'].user != request.user:
            return Response(status=status.HTTP_403_FORBIDDEN)

        try:
            success = login_to_card_sales(data['username'], data['password'])
            if not success:
                raise
        except Exception as e:
            return HttpResponseBadRequest(json.dumps(e.args[0]))

        return super().create(request, *args, **kwargs)


class TraderSerializer(serializers.ModelSerializer):
    unread_count = serializers.SerializerMethodField()
    vat_start_date = serializers.SerializerMethodField()
    vat_end_date = serializers.SerializerMethodField()
    income_start_date = serializers.SerializerMethodField()
    income_end_date = serializers.SerializerMethodField()

    class Meta:
        model = Trader
        fields = ('id', 'user', 'business_name', 'accounting_manager', 'unread_count', 'vat_start_date', 'vat_end_date',
                  'income_start_date', 'income_end_date', 'other_vat_sales', 'other_vat_purchase', 'other_income_sales',
                  'other_income_purchase', 'other_income',)

    def get_unread_count(self, obj):
        read = Read.objects.filter(chat_room=obj, user=self.context['request'].user).first()
        if read:
            return obj.message_set.filter(id__gt=read.read_id).count()
        else:
            return obj.message_set.count()

    def get_vat_start_date(self, obj):
        year, period = obj.next_vat_report_period().split('-')
        return datetime.date(int(year), VAT_PERIOD_RANGE[period][0][0], VAT_PERIOD_RANGE[period][0][1])

    def get_vat_end_date(self, obj):
        year, period = obj.next_vat_report_period().split('-')
        return datetime.date(int(year), VAT_PERIOD_RANGE[period][1][0], VAT_PERIOD_RANGE[period][1][1])

    def get_income_start_date(self, obj):
        today = datetime.date.today()

        start_date = datetime.date(today.year, 1, 1)
        target = today.replace(month=6, day=30)
        if today <= target:
            start_date = start_date.replace(year=start_date.year - 1)

        return start_date

    def get_income_end_date(self, obj):
        today = datetime.date.today()

        end_date = datetime.date(today.year, 12, 31)
        target = today.replace(month=6, day=30)
        if today <= target:
            end_date = end_date.replace(year=end_date.year - 1)

        return end_date


class TraderViewSet(viewsets.ModelViewSet):
    queryset = Trader.objects.all()
    serializer_class = TraderSerializer
    filter_fields = {
        'manager_set': ('contains',),
    }

    def get_queryset(self):
        queryset = super().get_queryset()
        if self.request.user.is_staff:
            return queryset

        return queryset.filter(user=self.request.user)

    @action(methods=['get'], detail=False)
    def mine(self, request):
        queryset = self.get_queryset().filter(user=request.user.id)
        return Response(self.get_serializer(queryset, many=True).data)

    @action(methods=['get'], detail=True)
    def latest(self, request, pk):
        trader = self.get_object()
        latest = None
        latests = []

        latests.extend(Account.objects.filter(trader=trader).values_list('latest', flat=True))
        latests.extend(CardSales.objects.filter(trader=trader).values_list('latest', flat=True))
        latests.extend(Hometax.objects.filter(trader=trader).values_list('latest', flat=True))

        latests = [latest for latest in latests if latest]
        if latests:
            latest = max(latests)

        return Response({
            'latest': latest,
        })

    @action(methods=['get'], detail=True)
    def hometaxes(self, request, pk):
        trader = self.get_object()
        if trader.user != self.request.user:
            return Response([])

        return Response(HometaxSerializer(Hometax.objects.filter(trader=trader), many=True).data)

    @action(methods=['get'], detail=True)
    def accounts(self, request, pk):
        trader = self.get_object()
        if trader.user != self.request.user:
            return Response([])

        return Response(AccountSerializer(Account.objects.filter(trader=trader), many=True).data)

    @action(methods=['get'], detail=True)
    def card_sales(self, request, pk):
        trader = self.get_object()
        if trader.user != self.request.user:
            return Response([])

        return Response(CardSalesSerializer(CardSales.objects.filter(trader=trader), many=True).data)

    @action(methods=['post'], detail=True)
    def scrap(self, request, pk):
        trader = self.get_object()

        account_ids = Account.objects.filter(trader=trader).values_list('id', flat=True)
        for account_id in account_ids:
            init_account.apply_async(args=[account_id])

        card_sales_ids = CardSales.objects.filter(trader=trader).values_list('id', flat=True)
        for card_sales_id in card_sales_ids:
            init_card_sales.apply_async(args=[card_sales_id])

        hometax_ids = Hometax.objects.filter(trader=trader).values_list('id', flat=True)
        for hometax_id in hometax_ids:
            init_hometax.apply_async(args=[hometax_id])

        return Response()

    @action(methods=['get'], detail=True)
    def vat(self, request, pk):
        trader = self.get_object()
        year, period = trader.next_vat_report_period().split('-')
        start_date = datetime.date(int(year), VAT_PERIOD_RANGE[period][0][0], VAT_PERIOD_RANGE[period][0][1])
        end_date = datetime.date(int(year), VAT_PERIOD_RANGE[period][1][0], VAT_PERIOD_RANGE[period][1][1])

        taxation = '법인과세자' if trader.is_corporation else '일반과세자' if trader.taxation == 'normal' else '간이과세자'
        전자세금계산서매출 = Check.objects.filter(hometax__trader=trader,
                                         issue_date__gte=start_date,
                                         issue_date__lte=end_date,
                                         inquiry_type__in=['01', '02'],
                                         transe_type='01')
        전자세금계산서매입 = Check.objects.filter(hometax__trader=trader,
                                         issue_date__gte=start_date,
                                         issue_date__lte=end_date,
                                         inquiry_type__in=['01', '02'],
                                         transe_type='02')
        전자계산서매입 = Check.objects.filter(hometax__trader=trader,
                                       issue_date__gte=start_date,
                                       issue_date__lte=end_date,
                                       inquiry_type__in=['03', '04'],
                                       transe_type='02')
        카드매출 = CardSalesApproval.objects.filter(card_sales__trader=trader,
                                                used_date__gte=start_date,
                                                used_date__lte=end_date)
        카드매출액 = 카드매출.aggregate(Sum('used_amount'))['used_amount__sum'] or 0
        카드매입 = CardApproval.objects.filter(card__account__trader=trader,
                                           used_date__gte=start_date,
                                           used_date__lte=end_date)
        현금영수증매출 = CashSalesReceipt.objects.filter(hometax__trader=trader,
                                                  used_date__gte=start_date,
                                                  used_date__lte=end_date)
        현금영수증매입 = CashPurchaseReceipt.objects.filter(hometax__trader=trader,
                                                     used_date__gte=start_date,
                                                     used_date__lte=end_date)
        return Response({
            'business_name': trader.business_name,
            'taxation': taxation,
            'start_date': start_date.strftime('%Y-%m-%d'),
            'end_date': end_date.strftime('%Y-%m-%d'),
            '전자세금계산서매출': 전자세금계산서매출.aggregate(Sum('supply_value'))['supply_value__sum'] or 0,
            '전자세금계산서매출세액': 전자세금계산서매출.aggregate(Sum('tax_amt'))['tax_amt__sum'] or 0,
            '전자세금계산서매입': 전자세금계산서매입.aggregate(Sum('supply_value'))['supply_value__sum'] or 0,
            '전자세금계산서매입세액': 전자세금계산서매입.aggregate(Sum('tax_amt'))['tax_amt__sum'] or 0,
            '전자계산서매입': 전자계산서매입.aggregate(Sum('supply_value'))['supply_value__sum'] or 0,
            '전자계산서매입세액': 전자계산서매입.aggregate(Sum('tax_amt'))['tax_amt__sum'] or 0,
            '카드매출': int(카드매출액 * 10 / 11),
            '카드매출세액': int(카드매출액 * 1 / 11),
            '카드매입': 카드매입.aggregate(supply_value=Sum('used_amount') - Sum('vat', output_field=models.IntegerField()))['supply_value'] or 0,
            '카드매입세액': 카드매입.aggregate(Sum('vat'))['vat__sum'] or 0,
            '현금영수증매출': 현금영수증매출.aggregate(Sum('supply_value'))['supply_value__sum'] or 0,
            '현금영수증매출세액': 현금영수증매출.aggregate(Sum('vat'))['vat__sum'] or 0,
            '현금영수증매입': 현금영수증매입.aggregate(Sum('supply_value'))['supply_value__sum'] or 0,
            '현금영수증매입세액': 현금영수증매입.aggregate(Sum('vat'))['vat__sum'] or 0,
            '기타매출': trader.other_vat_sales,
            '기타매입': trader.other_vat_purchase,
        })

    @action(methods=['get'], detail=True)
    def income(self, request, pk):
        trader = self.get_object()
        today = datetime.date.today()

        start_date = datetime.date(today.year, 1, 1)
        end_date = datetime.date(today.year, 12, 31)

        target = today.replace(month=6, day=30)
        if today <= target:
            start_date = start_date.replace(year=start_date.year - 1)
            end_date = end_date.replace(year=end_date.year - 1)

        taxation = '법인과세자' if trader.is_corporation else '일반과세자' if trader.taxation == 'normal' else '간이과세자'
        전자세금계산서매출 = Check.objects.filter(hometax__trader=trader,
                                         issue_date__gte=start_date,
                                         issue_date__lte=end_date,
                                         inquiry_type__in=['01', '02'],
                                         transe_type='01')
        전자세금계산서매입 = Check.objects.filter(hometax__trader=trader,
                                         issue_date__gte=start_date,
                                         issue_date__lte=end_date,
                                         inquiry_type__in=['01', '02'],
                                         transe_type='02')
        전자계산서매출 = Check.objects.filter(hometax__trader=trader,
                                       issue_date__gte=start_date,
                                       issue_date__lte=end_date,
                                       inquiry_type__in=['03', '04'],
                                       transe_type='01')
        전자계산서매입 = Check.objects.filter(hometax__trader=trader,
                                       issue_date__gte=start_date,
                                       issue_date__lte=end_date,
                                       inquiry_type__in=['03', '04'],
                                       transe_type='02')
        카드매출 = CardSalesApproval.objects.filter(card_sales__trader=trader,
                                                used_date__gte=start_date,
                                                used_date__lte=end_date)
        카드매출액 = 카드매출.aggregate(Sum('used_amount'))['used_amount__sum'] or 0
        카드매입 = CardApproval.objects.filter(card__account__trader=trader,
                                           used_date__gte=start_date,
                                           used_date__lte=end_date)
        현금영수증매출 = CashSalesReceipt.objects.filter(hometax__trader=trader,
                                                  used_date__gte=start_date,
                                                  used_date__lte=end_date)
        현금영수증매입 = CashPurchaseReceipt.objects.filter(hometax__trader=trader,
                                                     used_date__gte=start_date,
                                                     used_date__lte=end_date)
        인건비 = WithholdingTax.objects.filter(hometax__trader=trader,
                                            issued__gte=start_date,
                                            issued__lte=end_date)
        return Response({
            'business_name': trader.business_name,
            'taxation': taxation,
            'start_date': start_date.strftime('%Y-%m-%d'),
            'end_date': end_date.strftime('%Y-%m-%d'),
            '전자세금계산서매출': 전자세금계산서매출.aggregate(Sum('supply_value'))['supply_value__sum'] or 0,
            '전자세금계산서매입': 전자세금계산서매입.aggregate(Sum('supply_value'))['supply_value__sum'] or 0,
            '전자계산서매출': 전자계산서매출.aggregate(Sum('supply_value'))['supply_value__sum'] or 0,
            '전자계산서매입': 전자계산서매입.aggregate(Sum('supply_value'))['supply_value__sum'] or 0,
            '카드매출': int(카드매출액 * 10 / 11),
            '카드매입': 카드매입.aggregate(supply_value=Sum('used_amount') - Sum('vat', output_field=models.IntegerField()))['supply_value'] or 0,
            '현금영수증매출': 현금영수증매출.aggregate(Sum('supply_value'))['supply_value__sum'] or 0,
            '현금영수증매입': 현금영수증매입.aggregate(Sum('supply_value'))['supply_value__sum'] or 0,
            '인건비': 인건비.aggregate(Sum('amount'))['amount__sum'] or 0,
            '기타매출': trader.other_income_sales,
            '기타매입': trader.other_income_purchase,
            '기타수익': trader.other_income,
        })


class AttachmentSerializer(serializers.ModelSerializer):
    file = serializers.SerializerMethodField()
    width = serializers.SerializerMethodField()
    height = serializers.SerializerMethodField()

    class Meta:
        model = Attachment
        fields = ('id', 'file', 'mimetype', 'filename', 'downloaded', 'printed', 'handled', 'width', 'height',)

    def get_file(self, obj):
        return file_url(obj)

    def get_width(self, obj):
        return obj.get_actual_thumbnail_size()[0]

    def get_height(self, obj):
        return obj.get_actual_thumbnail_size()[1]


class VoucherSerializer(serializers.ModelSerializer):
    class Meta:
        model = Voucher
        fields = '__all__'


class MessageSerializer(serializers.ModelSerializer):
    sender = UserSerializer(read_only=True)
    attachment_set = AttachmentSerializer(many=True, read_only=True)
    voucher = serializers.SerializerMethodField()

    class Meta:
        model = Message
        fields = ('id',
                  'trader',
                  'sender',
                  'type',
                  'title',
                  'content',
                  'created',
                  'readers',
                  'info',
                  'attachment_set',
                  'voucher',)

    def create(self, validated_data):
        validated_data['sender'] = self.context['request'].user
        return super().create(validated_data)

    def get_voucher(self, obj):
        if obj.type != 'voucher':
            return None

        return VoucherSerializer(obj.content_object).data


class MessageViewSet(viewsets.ModelViewSet):
    queryset = Message.objects.order_by('-id').prefetch_related('readers')
    serializer_class = MessageSerializer
    permission_classes = (IsOwner,)
    filter_fields = {
        'id': ('gt',),
        'trader': ('exact',),
    }

    @action(methods=['get', 'post'], detail=False)
    def read(self, request):
        response = super().list(request)

        if request.method == 'POST':
            results = response.data['results']
            trader = request.query_params.get('trader')

            if len(results) and trader and request.user.is_authenticated:
                read, _ = Read.objects.get_or_create(chat_room_id=trader, user=request.user, defaults={
                    'read_id': results[0]['id']
                })

                if read.read_id != results[0]['id']:
                    read.read_id = results[0]['id']
                    read.save()

        return response


class BoilerplateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Boilerplate
        fields = '__all__'

    author = serializers.CharField(read_only=True)
    added = serializers.SerializerMethodField()

    def create(self, validated_data):
        validated_data['author'] = self.context['request'].user
        return super().create(validated_data)

    def get_added(self, obj):
        user = self.context['request'].user

        if obj.author == user:
            return True

        return obj.boilerplate_set.filter(author=user).exists()


class BoilerplateViewSet(viewsets.ModelViewSet):
    queryset = Boilerplate.objects.order_by('-id')
    serializer_class = BoilerplateSerializer
    filter_fields = {
        'parent': ('isnull',),
        'author': ('exact',),
        'private': ('exact',),
    }

    def get_queryset(self):
        queryset = super().get_queryset()
        return queryset.prefetch_related('boilerplate_set')

    @action(methods=['post'], detail=True)
    def discard(self, request, pk):
        try:
            boilerplate = self.get_object()
        except Http404:
            return Response(status=status.HTTP_204_NO_CONTENT)

        if boilerplate.boilerplate_set.exists():
            boilerplate.author = None
            boilerplate.save()
            return Response(BoilerplateSerializer(boilerplate, context={'request': request}).data)

        parent = boilerplate.parent
        response = {
            'deleted': [boilerplate.id]
        }
        boilerplate.delete()

        if parent and not parent.boilerplate_set.exists() and not parent.author:
            response['deleted'].append(parent.id)
            parent.delete()

        return Response(response)


class ReportTraderUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'name')


class ReportTraderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Trader
        fields = ('id', 'business_name', 'accounting_manager')

    accounting_manager = ReportTraderUserSerializer()


class ReportSerializer(serializers.ModelSerializer):
    class Meta:
        model = Report
        fields = ('id', 'name', 'sender', 'registration_no', 'has_co_invester', 'traders', 'trader_count', 'due_date',
                  'period_begin', 'period_end', 'parsed', 'sent', 'confirmed')

    sender = serializers.PrimaryKeyRelatedField(read_only=True)
    traders = ReportTraderSerializer(many=True, read_only=True)
    parsed = serializers.SerializerMethodField()

    def get_parsed(self, obj):
        return obj.parsed


class ReportViewSet(viewsets.ModelViewSet):
    queryset = Report.objects.order_by('-created')
    serializer_class = ReportSerializer
    filter_fields = {
        'sender': ('exact',),
        'has_co_invester': ('exact',),
        'trader_count': ('exact',),
        'sent': ('isnull',),
        'period_end': ('exact',),
    }

    def get_permissions(self):
        if self.name in ('Signature', 'Confirm'):
            return [permissions.AllowAny()]

        return super().get_permissions()

    def get_queryset(self):
        return super().get_queryset().filter(sender=self.request.user).prefetch_related('traders')

    def create(self, request):
        file = request.FILES['file']
        for string in 자료.split(데이터(file.read())):
            md5_hash = hashlib.md5(string.encode()).hexdigest()
            r, created = Report.objects.get_or_create(md5_hash=md5_hash, defaults={
                'sender': request.user,
                'raw': string
            })
            if not created:
                continue

            보고서 = 자료.factory(데이터(string=string))
            r.name = getattr(보고서, '성명', getattr(보고서, '성명_대표자', '')).strip()
            r.registration_no = ','.join(보고서.사업자등록번호)
            r.has_co_invester = getattr(보고서, '대표공동사업자', False)
            r.due_date = datetime.datetime.strptime(보고서.작성일자, '%Y%m%d').date()
            period_begin = getattr(보고서, '당해과세기간시작', getattr(보고서, '과세기간시작일자', getattr(보고서, '사업연도_시작일자', None)))
            if period_begin:
                r.period_begin = datetime.datetime.strptime(period_begin, '%Y%m%d').date()
            period_end = getattr(보고서, '당해과세기간종료', getattr(보고서, '과세기간종료일자', getattr(보고서, '사업연도_종료일자', None)))
            if period_end:
                r.period_end = datetime.datetime.strptime(period_end, '%Y%m%d').date()
            r.parsed = 보고서.to_json()

            r.trader_count = 0
            for registration_no in 보고서.사업자등록번호:
                t = Trader.objects.filter(registration_no=registration_no).first()
                if not t:
                    continue

                r.trader_count += 1
                r.traders.add(t)
            r.save()

        return Response()

    @action(methods=['get'], detail=False)
    def signature(self, request):
        signature = request.query_params.get('s')
        pk = signing.loads(signature)
        return Response(ReportSerializer(get_object_or_404(Report, pk=pk)).data)

    @action(methods=['post'], detail=False)
    def confirm(self, request):
        signature = request.query_params.get('s')
        pk = signing.loads(signature)
        report = Report.objects.get(pk=pk)
        report.confirmed = True
        report.save()

        for trader in report.traders.all():
            Message.objects.create(trader=trader,
                                   sender=trader.user,
                                   type='text',
                                   title='검토 완료',
                                   content='신고서를 검토 완료하였습니다.<br>신고서의 내용에 따라 신고를 진행해주세요.')

        return Response(ReportSerializer(report).data)

    @action(methods=['get'], detail=False)
    def unsendable(self, request):
        queryset = self.filter_queryset(self.get_queryset())
        queryset = queryset.filter(Q(has_co_invester=True) | ~Q(trader_count=1))
        return Response(ReportSerializer(queryset, many=True).data)

    @action(methods=['post'], detail=False)
    def send(self, request):
        ids = request.data.get('ids', [])
        reports = Report.objects.filter(id__in=ids)

        ms = []
        sender = ensure_mobiletax_user()
        for r in reports:
            r.sent = timezone.now()
            signature = signing.dumps(r.pk)
            link = f'https://mobiletax.kr/app/income-tax/{signature}'

            trader = r.traders.first()
            if not trader:
                continue

            ms.append(Message(trader=trader,
                              sender=sender,
                              type='notice',
                              title='신고서 안내',
                              content=f'신고서 작성이 완료되었습니다. 아래 링크를 통해 신고서 내용 검토를 요청드립니다.<br><a href="{link}" class="btn-vat-review">신고서 내용 검토하기</a>'))
            r.save()

        Message.objects.bulk_create(ms)
        return Response()

    @action(methods=['post'], detail=False)
    def delete(self, request):
        ids = request.data.get('ids', [])
        Report.objects.filter(id__in=ids).delete()
        return Response()

    @action(methods=['get'], detail=False)
    def periods(self, request):
        qs = Report.objects.filter(period_end__isnull=False).order_by('-period_end')
        qs = qs.distinct('period_end').values_list('period_end', flat=True)
        return Response(qs)


class CardApprovalSerializer(serializers.ModelSerializer):
    class Meta:
        model = CardApproval
        fields = '__all__'

    type = serializers.SerializerMethodField()

    def get_type(self, obj):
        if not obj.member_store:
            return None

        return obj.member_store.type


class CardApprovalViewSet(viewsets.ModelViewSet):
    queryset = CardApproval.objects.order_by('-used_date')
    serializer_class = CardApprovalSerializer
    filter_fields = {
        'card__account__trader': ('exact',),
        'used_date': ('gte', 'lte'),
    }

    def get_queryset(self):
        queryset = super().get_queryset()
        queryset = queryset.select_related('member_store')
        return queryset.filter(card__account__trader__user=self.request.user)


class CardSalesApprovalSerializer(serializers.ModelSerializer):
    class Meta:
        model = CardSalesApproval
        fields = '__all__'


class CardSalesApprovalViewSet(viewsets.ModelViewSet):
    queryset = CardSalesApproval.objects.order_by('-used_date')
    serializer_class = CardSalesApprovalSerializer
    filter_fields = {
        'card_sales__trader': ('exact',),
        'used_date': ('gte', 'lte'),
    }

    def get_queryset(self):
        return super().get_queryset().filter(card_sales__trader__user=self.request.user)


class CheckSerializer(serializers.ModelSerializer):
    class Meta:
        model = Check
        fields = '__all__'


class CheckViewSet(viewsets.ModelViewSet):
    queryset = Check.objects.order_by('-issue_date')
    serializer_class = CheckSerializer
    filter_fields = {
        'hometax__trader': ('exact',),
        'inquiry_type': ('in',),
        'transe_type': ('exact',),
        'issue_date': ('gte', 'lte'),
    }

    def get_queryset(self):
        return super().get_queryset().filter(hometax__trader__user=self.request.user)


class WithholdingTaxSerializer(serializers.ModelSerializer):
    class Meta:
        model = WithholdingTax
        fields = '__all__'


class WithholdingTaxViewSet(viewsets.ModelViewSet):
    queryset = WithholdingTax.objects.order_by('-issued')
    serializer_class = WithholdingTaxSerializer
    filter_fields = {
        'hometax__trader': ('exact',),
        'issued': ('gte', 'lte'),
    }

    def get_queryset(self):
        return super().get_queryset().filter(hometax__trader__user=self.request.user)


class CashSalesReceiptSerializer(serializers.ModelSerializer):
    class Meta:
        model = CashSalesReceipt
        fields = '__all__'


class CashSalesReceiptViewSet(viewsets.ModelViewSet):
    queryset = CashSalesReceipt.objects.order_by('-used_date')
    serializer_class = CashSalesReceiptSerializer
    filter_fields = {
        'hometax__trader': ('exact',),
        'used_date': ('gte', 'lte'),
    }

    def get_queryset(self):
        return super().get_queryset().filter(hometax__trader__user=self.request.user)


class CashPurchaseReceiptSerializer(serializers.ModelSerializer):
    class Meta:
        model = CashPurchaseReceipt
        fields = '__all__'


class CashPurchaseReceiptViewSet(viewsets.ModelViewSet):
    queryset = CashPurchaseReceipt.objects.order_by('-used_date')
    serializer_class = CashPurchaseReceiptSerializer
    filter_fields = {
        'hometax__trader': ('exact',),
        'used_date': ('gte', 'lte'),
    }

    def get_queryset(self):
        return super().get_queryset().filter(hometax__trader__user=self.request.user)
