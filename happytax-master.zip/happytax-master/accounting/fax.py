from accounting.format import base64_hmac_sha1, base64_md5
from contextlib import closing
from django.conf import settings
import json
import requests
import datetime
import io
import urllib
from io import BytesIO


class FaxBaseError(Exception):
    pass


class FaxAuthorizationError(FaxBaseError):
    pass


class FaxError(FaxBaseError):
    pass


class Fax:
    API_VERSION = '1.0'
    AUTH_URL = 'https://auth.linkhub.co.kr'
    SCOPES = ['member', '160']
    SERVICE_ID = 'POPBILL_TEST' if settings.LINKHUB_IS_TEST else 'POPBILL'
    SERVICE_URL = 'https://popbill_test.linkhub.co.kr' if settings.LINKHUB_IS_TEST else 'https://popbill.linkhub.co.kr'
    TOKEN = None

    @classmethod
    def generate_token(cls):
        data = {'access_id': settings.LINKHUB_CORPORATE_NUMBER, 'scope': cls.SCOPES}
        call_date = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        uri = '/{}/Token'.format(cls.SERVICE_ID)

        hmac = None
        with closing(io.StringIO()) as hmac_target:
            hmac_target.write('POST\n')
            hmac_target.write(base64_md5(json.dumps(data)) + '\n')
            hmac_target.write(call_date + '\n')
            hmac_target.write(cls.API_VERSION + '\n')
            hmac_target.write(uri)
            hmac = base64_hmac_sha1(settings.LINKHUB_SECRET_KEY, hmac_target.getvalue())

        headers = {
            'Authorization': 'LINKHUB {} {}'.format(settings.LINKHUB_LINK_ID, hmac),
            'x-lh-date': call_date,
            'x-lh-version': cls.API_VERSION,
            'Content-Type': 'Application/json'
        }

        response = requests.post(cls.AUTH_URL + uri, headers=headers, data=json.dumps(data))
        _json = response.json()
        if response.status_code != 200:
            raise FaxAuthorizationError(_json['code'], _json['message'])
        return _json

    @classmethod
    def get_token(cls, corporate_number):
        if not cls.TOKEN or cls.TOKEN['expiration'][:-5] < datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S'):
            cls.TOKEN = cls.generate_token()

        return cls.TOKEN

    @classmethod
    def get_headers(cls):
        headers = {
            'x-pb-version': cls.API_VERSION,
            'Authorization': 'Bearer ' + cls.get_token(settings.LINKHUB_CORPORATE_NUMBER)['session_token'],
            "Content-Type": "multipart/form-data; boundary=--POPBILL_PYTHON--",
            "x-pb-userid": settings.LINKHUB_USER
        }
        return headers

    @classmethod
    def send_fax(cls, receiver_number, receiver_name, attachment_id):
        from accounting.models import Attachment

        attachment = Attachment.objects.get(id=attachment_id)
        file = attachment.file

        receiver_number = ''.join(receiver_number.split()).replace('-', '')
        if not receiver_number or not receiver_number.isnumeric():
            raise FaxError(0, '수신자 정보가 올바르지 않습니다.')
        if not file:
            raise FaxError(0, '전송할 파일이 존재하지 않습니다.')

        headers = cls.get_headers()
        data = {
                'fCnt': 1,
                'rcvs': [
                    {
                        'rcv': receiver_number,
                        'rcvnm': receiver_name
                    }
                ],
                'snd': settings.FAX_NUMBER,
                'sndDT': None
        }
        files = {'file': (urllib.parse.quote(file.name), file.read())}

        CRLF = '\r\n'
        boundary = "--POPBILL_PYTHON--"
        data = json.dumps(data)

        buff = BytesIO()
        buff.write((CRLF + '--' + boundary + CRLF).encode('utf-8'))
        buff.write(('Content-Disposition: form-data; name="form"' + CRLF).encode('utf-8'))
        buff.write(CRLF.encode('utf-8'))
        buff.write(data.encode('utf-8'))
        buff.write((CRLF + '--' + boundary + CRLF).encode('utf-8'))
        buff.write(('Content-Disposition: form-data; name="%s"; filename="%s"' % ('file', files['file'][0]) + CRLF).encode('utf-8'))
        buff.write(('Content-Type: Application/octet-stream' + CRLF).encode('utf-8'))
        buff.write(CRLF.encode('utf-8'))
        buff.write(files['file'][1])
        buff.write((CRLF + '--' + boundary + '--' + CRLF + CRLF).encode('utf-8'))

        response = requests.post(cls.SERVICE_URL + '/FAX', headers=headers, data=buff.getvalue())
        json_ = response.json()

        if response.status_code != 200:
            raise FaxError(json_['code'], json_['message'])

        fax = next(filter(lambda f: 'receiptNum' not in f and f['fax_number'] == receiver_number, attachment.info['faxes']))
        fax['receiptNum'] = json_['receiptNum']
        attachment.save(update_fields=['info'])

    @classmethod
    def update_status(cls, receipt_number, attachment_id):
        response = requests.get('{}/FAX/{}'.format(cls.SERVICE_URL, receipt_number)).json()

        from accounting.models import Attachment
        attachment = Attachment.objects.get(id=attachment_id)
        fax = next(filter(lambda f: receipt_number == f.get('receiptNum', None), attachment.info['faxes']))
        fax.update(response)
        attachment.save(update_fields=['info'])
