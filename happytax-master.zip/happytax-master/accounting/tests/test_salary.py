import datetime
import os
import unittest

os.environ['DJANGO_SETTINGS_MODULE'] = 'happytax.settings'
import django

django.setup()

from accounting.models import Salary, Employee, Trader


class TestSalary(unittest.TestCase):
    def test_regular_income_taxes(self):
        salary = Salary()
        salary.base_pay = 2500000
        self.assertAlmostEqual(salary.regular_income_tax(1), 41630)

        salary.base_pay = 4000000
        self.assertAlmostEqual(salary.regular_income_tax(6), 76060)

        salary.base_pay = 1496000
        self.assertAlmostEqual(salary.regular_income_tax(2), 4260)

        salary.base_pay = 5010000
        self.assertAlmostEqual(salary.regular_income_tax(8), 162550)

        salary.base_pay = 99999999
        self.assertAlmostEqual(salary.regular_income_tax(1), 36036830)

        salary.base_pay = 0
        self.assertAlmostEqual(salary.regular_income_tax(), 0)

        salary.base_pay = 1350000
        self.assertAlmostEqual(salary.regular_income_tax(), 5770)

        salary.base_pay = 1422000
        self.assertAlmostEqual(salary.regular_income_tax(2), 2710)

        salary.base_pay = 1445000
        self.assertAlmostEqual(salary.regular_income_tax(2), 3230)

        salary.base_pay = 1440000
        self.assertAlmostEqual(salary.regular_income_tax(), 7630)

        salary.base_pay = 1481000
        self.assertAlmostEqual(salary.regular_income_tax(), 8450)

        salary.base_pay = 1722000
        self.assertAlmostEqual(salary.regular_income_tax(3), 1040)

        salary.base_pay = 1883000
        self.assertAlmostEqual(salary.regular_income_tax(), 16770)

        salary.base_pay = 2080000
        self.assertAlmostEqual(salary.regular_income_tax(1), 22090)

        salary.base_pay = 2080000
        self.assertAlmostEqual(salary.regular_income_tax(4), 4810)

        salary.base_pay = 2080000
        self.assertAlmostEqual(salary.regular_income_tax(5), 1430)

        salary.base_pay = 2980000
        self.assertAlmostEqual(salary.regular_income_tax(11), 0)

        salary.base_pay = 3040000
        self.assertAlmostEqual(salary.regular_income_tax(11), 1080)

        salary.base_pay = 8800000
        self.assertAlmostEqual(salary.regular_income_tax(1), 1194880)

        salary.base_pay = 10000000
        self.assertAlmostEqual(salary.regular_income_tax(), 1560440)

        salary.base_pay = 10000000
        self.assertAlmostEqual(salary.regular_income_tax(11), 1011340)

        salary.base_pay = 10000001
        self.assertAlmostEqual(salary.regular_income_tax(), 1560440)

        salary.base_pay = 11000000
        self.assertAlmostEqual(salary.regular_income_tax(), 1903440)

        salary.base_pay = 98765432
        self.assertAlmostEqual(salary.regular_income_tax(), 35552880)

    def test_save(self):
        test_trader = Trader.objects.first()
        employee = Employee.objects.create(trader=test_trader, base_pay=1000000, type='정직원')
        salary = Salary.objects.create(month=datetime.date(2017, 6, 1), employee=employee, base_pay=1000000)
        salary.base_pay = 1200000
        salary.save()
        salary.delete()
        employee.delete()
