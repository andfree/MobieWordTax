import os
import unittest

os.environ['DJANGO_SETTINGS_MODULE'] = 'happytax.settings'
import django

django.setup()

from django.core.files.base import File
from accounting.models import User, Trader


class ActivationTest(unittest.TestCase):
    def setUp(self):
        User.objects.filter(username='unitest@mobiletax.kr').delete()

        self.user = User.objects.create(username='unitest@mobiletax.kr',
                                        email='unitest@mobiletax.kr',
                                        name='홍길동',
                                        registration_no="7010101122334")

        self.trader = Trader.objects.create(user=self.user,
                                            business_name='홍김밥',
                                            registration_no="1210012346")
        self.file = File(open(os.path.dirname(__file__) + '/test_image.png', 'rb'))

    def tearDown(self):
        User.objects.filter(username='unitest@mobiletax.kr').delete()

    def test_update_activation_when_document_modified(self):
        self.assertEqual('require_information', self.trader.activation)

        self.trader.document_set.update_or_create(
            type='사업자등록증',
            defaults={'file': self.file, 'state': 'uploaded'}
        )
        self.trader.refresh_from_db()
        self.assertEqual('trying', self.trader.activation)

        self.trader.info['cms_agreement'] = True
        self.trader.save()
        self.trader.document_set.update_or_create(
            type='임대차계약서',
            defaults={'file': self.file, 'state': 'uploaded'}
        )
        self.trader.document_set.update_or_create(
            type='통장사본',
            defaults={'file': self.file, 'state': 'uploaded'}
        )
        self.trader.refresh_from_db()
        self.assertEqual('in_review', self.trader.activation)

        self.trader.document_set.update(state='approved')
        for document in self.trader.document_set.all():
            document.state = 'approved'
            document.save()

        self.trader.refresh_from_db()
        self.assertEqual('activated', self.trader.activation)

        del self.trader.info['cms_agreement']
        self.trader.save()
        self.trader.update_activation()

        self.assertEqual('trying', self.trader.activation)
