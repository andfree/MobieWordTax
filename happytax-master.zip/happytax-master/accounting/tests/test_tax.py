import os
import unittest

import datetime

os.environ['DJANGO_SETTINGS_MODULE'] = 'happytax.settings'
import django

django.setup()

from django.core.files.base import File
from accounting.models import User, Trader

class TaxTest(unittest.TestCase):

    def setUp(self):
        User.objects.filter(username='unitest@mobiletax.kr').delete()

        self.user = User.objects.create(username='unitest@mobiletax.kr',
                                        email='unitest@mobiletax.kr',
                                        name='홍길동',
                                        registration_no="7010101122334")

        self.trader = Trader.objects.create(user=self.user,
                                            business_name='홍김밥',
                                            registration_no="1210012346")
        self.file = File(open(os.path.dirname(__file__) + '/test_image.png', 'rb'))

    def test_next_vat(self):
        self.assertEqual('2016-2H', self.trader.next_vat_report_period(datetime.date(2017, 1, 20)))
        self.assertEqual('2017-1H', self.trader.next_vat_report_period(datetime.date(2017, 6, 20)))
        self.assertEqual('2017-2H', self.trader.next_vat_report_period(datetime.date(2017, 9, 20)))
        self.assertEqual('2017-2H', self.trader.next_vat_report_period(datetime.date(2017, 12, 31)))
        self.assertEqual('2017-2H', self.trader.next_vat_report_period(datetime.date(2018, 1, 1)))

        self.trader.is_corporation = True

        self.assertEqual('2016-4Q', self.trader.next_vat_report_period(datetime.date(2017, 1, 20)))
        self.assertEqual('2017-1Q', self.trader.next_vat_report_period(datetime.date(2017, 1, 26)))
        self.assertEqual('2017-2Q', self.trader.next_vat_report_period(datetime.date(2017, 5, 1)))
        self.assertEqual('2017-3Q', self.trader.next_vat_report_period(datetime.date(2017, 9, 1)))
        self.assertEqual('2017-4Q', self.trader.next_vat_report_period(datetime.date(2017, 10, 26)))
