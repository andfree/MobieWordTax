import json
from collections import OrderedDict

from django.test.utils import override_settings
from django.urls import reverse
from django.utils.timezone import now
from rest_framework import status
from rest_framework.test import APITestCase, APIClient

from accounting.models import Tax, Trader, User


@override_settings(DEBUG=True)
class TaxUpdateMemoAPITests(APITestCase):
    @classmethod
    def setUpClass(cls):
        super(TaxUpdateMemoAPITests, cls).setUpClass()
        User.objects.filter(username='unitest@mobiletax.kr').delete()
        cls.user = User.objects.create(username='unitest@mobiletax.kr',
                                       email='unitest@mobiletax.kr',
                                       name='홍길동')

        cls.trader = Trader.objects.create(user=cls.user, business_name='테스트')

    @classmethod
    def tearDownClass(cls):
        super(TaxUpdateMemoAPITests, cls).tearDownClass()
        cls.user.delete()
        cls.trader.delete()

    def setUp(self):
        self.tax = Tax.objects.create(trader=self.trader)

    def tearDown(self):
        self.tax.delete()

    def test_update_memos_undefined_key(self):
        response = self.client.post(reverse('taxes-update-memos', kwargs={'pk': self.tax.id}),
                                    {'testkey': 'testval'})
        info = json.loads(response.data['info'])
        self.assertEqual(info['testkey'], 'testval')

    def test_update_memos_multiple_pair(self):
        response = self.client.post(reverse('taxes-update-memos', kwargs={'pk': self.tax.id}),
                                    {'testkey1': 'testval1', 'testkey2': 'testval2'})
        info = json.loads(response.data['info'])
        self.assertEqual(info, {'testkey1': 'testval1', 'testkey2': 'testval2'})

    def test_update_memos_receive_array(self):
        response = self.client.post(reverse('taxes-update-memos', kwargs={'pk': self.tax.id}),
                                    {'testkey[]': ['testval1', 'testval2']})
        info = json.loads(response.data['info'])
        self.assertEqual(info['testkey'], ['testval1', 'testval2'])

    def test_update_memos_predefined_key(self):
        response = self.client.post(reverse('taxes-update-memos', kwargs={'pk': self.tax.id}),
                                    {'withholding_tax_part_report_detail_code': '수정신고'})
        info = json.loads(response.data['info'])
        self.assertEqual(info['신고구분상세코드'], '수정신고')

    def test_update_memos_predefined_array(self):
        response = self.client.post(reverse('taxes-update-memos', kwargs={'pk': self.tax.id}),
                                    {
                                        'withholding_tax_part_report_detail_code': '수정신고',
                                        'vat_part_7_1': 'vat_part_7_1_value',
                                        'income_tax_part_20': 'income_tax_part_20_value',
                                    })
        info = json.loads(response.data['info'])
        self.assertEqual(info['신고구분상세코드'], '수정신고')
        self.assertEqual(info['매출예정신고누락분'], 'vat_part_7_1_value')
        self.assertEqual(info['소득공제'], 'income_tax_part_20_value')


class LoginAPITests(APITestCase):
    def setUp(self):
        self.client = APIClient()
        self.client.force_login(user=User.objects.first(), backend='django.contrib.auth.backends.ModelBackend')


@override_settings(DEBUG=True)
class WithholdingTaxAPITests(LoginAPITests):
    @classmethod
    def setUpClass(cls):
        super(WithholdingTaxAPITests, cls).setUpClass()
        User.objects.filter(username='unitest@mobiletax.kr').delete()
        cls.user = User.objects.create(username='unitest@mobiletax.kr',
                                       email='unitest@mobiletax.kr',
                                       name='홍길동',
                                       is_staff=True)

        cls.trader = Trader.objects.create(user=cls.user, business_name='테스트')

        cls.귀속연월 = '2017-07'
        cls.tax = Tax.objects.create(trader=cls.trader, period=cls.귀속연월, type='withholding-tax')


    @classmethod
    def tearDownClass(cls):
        super(WithholdingTaxAPITests, cls).tearDownClass()
        cls.user.delete()
        cls.trader.delete()

    def test_withholding_api(self):
        response = self.client.get(
            reverse('traders-taxes', kwargs={'pk': self.trader.id}),
            {'type': 'withholding-tax', 'period': '2017-07'}
        )
        self.assertTrue(status.is_success(response.status_code))

    def test_withholding_api_shape(self):
        response = self.client.get(
            reverse('traders-taxes', kwargs={'pk': self.trader.id}),
            {'type': 'withholding-tax', 'period': '2017-07'}
        )
        self.assertNotEqual(response.data.get('output'), None)

        self.assertEqual(response.data.get('reported'), None)

        # 마감 후에는 reported 로 데이터가 존재
        self.tax.ready_to_report = now()
        self.tax.save()
        response = self.client.get(
            reverse('traders-taxes', kwargs={'pk': self.trader.id}),
            {'type': 'withholding-tax', 'period': '2017-07'}
        )
        self.assertEqual(response.data.get('id'), self.tax.id)
        self.assertNotEqual(response.data.get('reported'), None)
        self.assertNotEqual(response.data.get('parsed'), None)
        self.assertNotEqual(response.data.get('siblings_id'), None)

    def test_create_withholding_tax(self):
        response = self.client.post(
            reverse('traders-taxes', kwargs={'pk': self.trader.id}),
            {'type': 'withholding-tax', 'period': '2017-07'}
        )
        # newly created tax
        self.assertNotEqual(response.data.get('id'), self.tax.id)
        self.assertTrue(status.is_success(response.status_code))

    def test_get_specifix_tax(self):
        Tax.objects.create(trader=self.trader, period=self.귀속연월, type='withholding-tax')
        response = self.client.get(
            reverse('traders-taxes', kwargs={'pk': self.trader.id}),
            {'type': 'withholding-tax', 'period': '2017-07', 'id': self.tax.id}
        )
        self.assertEqual(response.data.get('id'), self.tax.id)


@override_settings(DEBUG=True)
class TraderListAPITests(LoginAPITests):
    @classmethod
    def setUpClass(cls):
        super(TraderListAPITests, cls).setUpClass()
        User.objects.filter(username='unitest@mobiletax.kr').delete()
        cls.user = User.objects.create(username='unitest@mobiletax.kr',
                                       email='unitest@mobiletax.kr',
                                       name='홍길동',
                                       is_staff=True)
        cls.trader = Trader.objects.create(user=cls.user, business_name='테스트')
        Trader.objects.create(user=cls.user, registration_no='test', business_name='테스트2')

    @classmethod
    def tearDownClass(cls):
        super(TraderListAPITests, cls).tearDownClass()
        cls.user.delete()
        Trader.objects.all().delete()

    def test_trader_list(self):
        response = self.client.get(reverse('traders-list'), {'user_detail': True})

        self.assertNotEqual(response.data, None)
        self.assertTrue(status.is_success(response.status_code))
        self.assertEqual(type(response.data), OrderedDict)
        self.assertEqual(response.data['results'][0]['id'], self.trader.id)
        self.assertEqual(type(response.data['results'][0]['user']), OrderedDict)
        self.assertEqual(response.data['results'][0]['user']['id'], self.user.id)

        self.assertEqual(type(response.data['results'][0]['manager_set']), list)

    def test_trader_statistics(self):
        self.trader.manager_set.add(self.user)
        self.trader.save()

        response = self.client.get(reverse('traders-statistics'), {'manager': self.user.id})

        self.assertNotEqual(response.data, None)
        self.assertTrue(status.is_success(response.status_code))
        self.assertEqual(response.data, {
            'all': 2, 'new': 2, 'activating': 0, 'activated': 0, 'paid': 0, 'mine': 1,
        })

    def test_trader_client_set(self):
        response = self.client.post(reverse('users-client-set', kwargs={'pk': self.user.id}),
                                    {'trader': self.trader.id}
                                    )

        self.assertEqual(self.trader in self.user.client_set.all(), True)

        response = self.client.delete(reverse('users-client-set', kwargs={'pk': self.user.id}),
                                    {'trader': self.trader.id}
                                    )

        self.assertEqual(self.trader not in self.user.client_set.all(), True)