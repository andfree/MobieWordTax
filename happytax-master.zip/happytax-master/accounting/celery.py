from celery.app.base import Celery as Celery_


class Celery(Celery_):
    def now(self):
        """Return the current time and date as a datetime."""
        from datetime import datetime
        return datetime.now(self.timezone)
