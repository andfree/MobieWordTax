from django.contrib import admin
from marketing.models import Campaign, CrawledPage, Email, MallOrderBusinessman, Region, SentEmail, Template, \
    YellowPage, \
    Coupon, TraderCoupon, Acquisition, UserCoupon


class CampaignAdmin(admin.ModelAdmin):
    list_display = ('name', 'source', 'medium', 'content', 'cost', 'active')
    list_display_links = list_display
    list_filter = ['name']


admin.site.register(Campaign, CampaignAdmin)
admin.site.register(CrawledPage)
admin.site.register(Email)
admin.site.register(MallOrderBusinessman)
admin.site.register(Region)
admin.site.register(SentEmail)
admin.site.register(Template)
admin.site.register(YellowPage)


class CouponAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'created', 'begin', 'end')
    list_display_links = ('code',)


class UserCouponAdmin(admin.ModelAdmin):
    raw_id_fields = ['user']
    list_display = ('user', 'coupon', 'created', 'used')
    list_display_links = ('user', 'coupon', 'created', 'used')


class TraderCouponAdmin(admin.ModelAdmin):
    raw_id_fields = ['trader']
    list_display = ('trader', 'coupon', 'created', 'used')
    list_display_links = ('trader', 'coupon', 'created', 'used')
    search_fields = ('trader__business_name', 'trader__registration_no', 'coupon__code')


admin.site.register(Coupon, CouponAdmin)
admin.site.register(UserCoupon, UserCouponAdmin)
admin.site.register(TraderCoupon, TraderCouponAdmin)


class AcquisitionAdmin(admin.ModelAdmin):
    list_display = ('user', 'campaign', 'source', 'medium', 'content', 'term', 'created')


admin.site.register(Acquisition, AcquisitionAdmin)
