from django.conf import settings
from googleapiclient.discovery import build
from oauth2client.service_account import ServiceAccountCredentials
import copy
import httplib2

CLIENT_SECRETS_PATH = 'client_secrets.json'
SCOPES = ['https://www.googleapis.com/auth/analytics.readonly']
DISCOVERY_URI = 'https://analyticsreporting.googleapis.com/$discovery/rest'


def initialize_analytics_reporting():
    credentials = ServiceAccountCredentials.from_json_keyfile_name(CLIENT_SECRETS_PATH, scopes=SCOPES)
    http = credentials.authorize(http=httplib2.Http())
    return build('analytics', 'v4', http=http, discoveryServiceUrl=DISCOVERY_URI)


def get_report(analytics, body):
    try:
        return analytics.reports().batchGet(body=body).execute()
    except:
        raise


class AnalyticsObject(dict):
    def __init__(self):
        return super().__init__()

    def copy(self):
        obj = self.__class__()
        obj.update(copy.deepcopy(self))
        return obj


class ReportRequest(AnalyticsObject):
    @classmethod
    def create(cls):
        obj = cls()
        obj.update({
            'viewId': settings.GOOGLE_ANALYTICS_VIEW_ID,
            'dateRanges': [],
            'dimensions': [],
            'dimensionFilterClauses': [],
            'metrics': []
        })
        return obj

    def add_date_range(self, date_range):
        self['dateRanges'].append(date_range)
        return self

    def add_dimension(self, dimension):
        self['dimensions'].append(dimension)
        return self

    def add_dimension_filter_clause(self, dimension_filter_clause):
        self['dimensionFilterClauses'].append(dimension_filter_clause)
        return self

    def add_metric(self, metric):
        self['metrics'].append(metric)
        return self

    def add_metrics(self, metrics):
        for metric in metrics:
            self.add_metric(metric)
        return self


class DateRange(AnalyticsObject):
    @classmethod
    def create(cls, start_date, end_date):
        obj = cls()
        obj.update({
            'startDate': start_date,
            'endDate': end_date
        })
        return obj


class Dimension(AnalyticsObject):
    @classmethod
    def create(cls, name):
        obj = cls()
        obj.update({
            'name': name
        })
        return obj


class DimensionFilterClause(AnalyticsObject):
    @classmethod
    def create(cls, operator='OR'):
        obj = cls()
        obj.update({
            'operator': operator,
            'filters': []
        })
        return obj

    def add_filter(self, filter_):
        self['filters'].append(filter_)
        return self


class DimensionFilter(AnalyticsObject):
    @classmethod
    def create(cls, dimension_name, operator='EXACT'):
        obj = cls()
        obj.update({
            'dimensionName': dimension_name,
            'operator': operator,
            'expressions': []
        })
        return obj

    def add_expression(self, expression):
        self['expressions'].append(expression)
        return self


class Metric(AnalyticsObject):
    @classmethod
    def create(cls, expression):
        obj = cls()
        obj.update({
            'expression': expression
        })
        return obj
