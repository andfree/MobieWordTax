from django.db import models
from django.core.files.storage import FileSystemStorage
from django.utils import timezone
from django.utils.deconstruct import deconstructible
from django_extensions.db.fields.json import JSONField
import os

from accounting.models import Trader, User


class CrawledPage(models.Model):
    TYPES = [
        ('KT114', 'KT114')
    ]

    type = models.CharField(max_length=10, choices=TYPES)
    hash = models.IntegerField()
    info = JSONField(default={})


class Region(models.Model):
    name = models.CharField(max_length=30)
    x = models.FloatField()
    y = models.FloatField()

    def __str__(self):
        return self.name


class YellowPage(models.Model):
    region = models.ForeignKey(Region, editable=False, on_delete=models.CASCADE)
    search_word = models.CharField(max_length=30)
    tel = models.CharField(max_length=20)
    name = models.CharField(max_length=100)
    road_name = models.CharField(max_length=255)
    info = JSONField(default={})

    def __str__(self):
        return self.name


@deconstructible
class TemplateUploadPath:
    def __call__(self, instance, filename):
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mails', filename)


class Template(models.Model):
    subject = models.CharField(max_length=50)
    message = models.FileField(upload_to=TemplateUploadPath(), storage=FileSystemStorage())

    def __str__(self):
        return self.subject


class Campaign(models.Model):
    name = models.CharField(max_length=100)
    source = models.CharField(max_length=100, default='email')
    medium = models.CharField(max_length=50, default='email')
    content = models.CharField(max_length=500)
    template = models.ForeignKey(Template, null=True, blank=True, on_delete=models.CASCADE)
    cost = models.IntegerField(default=0)
    active = models.BooleanField(default=True)
    begin = models.DateTimeField(null=True, blank=True)
    end = models.DateTimeField(null=True, blank=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return '{} {} {}'.format(self.name, self.medium, self.content)


class Email(models.Model):
    email = models.EmailField()

    def __str__(self):
        return self.email


class MallOrderBusinessman(models.Model):
    registration_number = models.BigIntegerField(primary_key=True)
    name = models.CharField(max_length=100)
    email = models.ForeignKey(Email, null=True, editable=False, on_delete=models.CASCADE)
    is_individual = models.BooleanField(default=False)
    condition = models.CharField(max_length=20, blank=True)
    registration_date = models.DateField()
    info = JSONField(default={})

    class Meta:
        verbose_name_plural = 'Mall order businessmen'

    def __str__(self):
        return self.name


class SentEmail(models.Model):
    campaign = models.ForeignKey(Campaign, on_delete=models.CASCADE)
    recipient = models.ForeignKey(Email, editable=False, on_delete=models.CASCADE)
    is_successful = models.BooleanField(default=True)
    is_opened = models.BooleanField(default=False)
    sent = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return timezone.localtime(self.sent).strftime('%Y-%m-%d %H:%M:%S')


class Coupon(models.Model):
    campaign = models.ForeignKey(Campaign, null=True, blank=True, on_delete=models.SET_NULL)
    code = models.CharField(max_length=100)
    name = models.CharField(max_length=200)
    created = models.DateTimeField(auto_now_add=True)
    begin = models.DateTimeField(null=True, blank=True)
    end = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return '{0} {1}'.format(self.code, self.name)


class UserCoupon(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    coupon = models.ForeignKey(Coupon, on_delete=models.CASCADE)
    created = models.DateTimeField(auto_now_add=True)
    used = models.DateTimeField(null=True, blank=True)


class TraderCoupon(models.Model):
    trader = models.ForeignKey(Trader, on_delete=models.CASCADE)
    coupon = models.ForeignKey(Coupon, on_delete=models.CASCADE)
    created = models.DateTimeField(auto_now_add=True)
    used = models.DateTimeField(null=True, blank=True)


class Acquisition(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    campaign = models.CharField(max_length=100, null=True, blank=True)
    source = models.CharField(max_length=100, null=True, blank=True)
    medium = models.CharField(max_length=50, null=True, blank=True)
    content = models.CharField(max_length=500, null=True, blank=True)
    term = models.CharField(max_length=500, null=True, blank=True)
    referrer = models.TextField(blank=True)
    memo = models.TextField(blank=True)
    created = models.DateTimeField(auto_now_add=True)
