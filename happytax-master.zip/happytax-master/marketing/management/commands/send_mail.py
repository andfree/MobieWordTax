from django.conf import settings
from django.core import mail
from django.core.mail import EmailMessage
from django.core.management import BaseCommand
from mako.template import Template
from marketing.models import Campaign, MallOrderBusinessman, SentEmail
from smtplib import SMTPException
from time import time
import base64
import json


class Command(BaseCommand):
    GOOGLE_MEASUREMENT_PROTOCOL = '<img src="http://www.google-analytics.com/collect?' + \
                                  'v={version}&' + \
                                  'tid={tid}&' + \
                                  'cid={client_id}&' + \
                                  't={hit_type}&' + \
                                  'ec={event_category}&' + \
                                  'ea={event_action}&' + \
                                  'cn={campaign_name}&' + \
                                  'cs={campaign_source}&' + \
                                  'cm={campaign_medium}&' + \
                                  'cc={campaign_content}&' + \
                                  'cd1={custom_dimension1}&' + \
                                  'cm1={custom_metric1}" />'
    MIXPANEL_PIXEL_BASED_EVENT_TRACKING = '<img src="http://api.mixpanel.com/track/?data={}&ip=1&img=1" />'

    def add_arguments(self, parser):
        parser.add_argument('campaign', nargs='?', type=int)
        parser.add_argument('is_individual', nargs='?', type=int)
        parser.add_argument('how_many', nargs='?', type=int)

    def handle(self, *args, **options):
        campaign = Campaign.objects.get(pk=options['campaign'])
        if not campaign:
            return

        template = Template(campaign.template.message.read().decode('utf-8'))
        mall_order_businessmen = MallOrderBusinessman.objects.filter(
            email__isnull=False,
            is_individual=options['is_individual'],
        ).exclude(email__in=SentEmail.objects.values_list('recipient', flat=True))[:options['how_many']]

        with mail.get_connection() as connection:
            for mall_order_businessman in mall_order_businessmen:
                is_successful = True
                try:
                    email = EmailMessage(
                        campaign.template.subject,
                        template.render(
                            campaign_name=campaign.name,
                            campaign_source=campaign.source,
                            campaign_medium=campaign.medium,
                            campaign_content=campaign.content,
                            campaign_token=self.get_campaign_token(campaign),
                            tracking_tag=self.get_tracking_tag(campaign, mall_order_businessman.email)
                        ),
                        '모바일택스 <contact@mobiletax.kr>',
                        [mall_order_businessman.email.email],
                        connection=connection
                    )
                    email.content_subtype = 'html'
                    email.send()
                except SMTPException:
                    is_successful = False
                finally:
                    SentEmail.objects.create(campaign=campaign, recipient=mall_order_businessman.email, is_successful=is_successful)

    @staticmethod
    def get_campaign_token(campaign):
        return campaign.source

    @classmethod
    def get_tracking_tag(cls, campaign, recipient):
        return cls.get_google_measurement_protocol(campaign, recipient.email) + \
               cls.get_mixpanel_pixel_based_event_tracking(campaign, recipient.email)

    @staticmethod
    def get_google_measurement_protocol(campaign, recipient):
        return Command.GOOGLE_MEASUREMENT_PROTOCOL.format(
            version=1,
            tid=settings.GOOGLE_ANALYTICS_TRACKING_ID,
            client_id=recipient,
            hit_type='event',
            event_category='email',
            event_action='open',
            campaign_name=campaign.name,
            campaign_source=campaign.source,
            campaign_medium=campaign.medium,
            campaign_content=campaign.content,
            custom_dimension1=recipient,
            custom_metric1=1
        )

    @staticmethod
    def get_mixpanel_pixel_based_event_tracking(campaign, recipient):
        data = {
            'event': 'e-mail opened',
            'properties': {
                'distinct_id': recipient,
                'token': settings.MIXPANEL_TOKEN,
                'time': int(time()),
                'utm_campaign': campaign.name,
                'utm_source': campaign.source,
                'utm_medium': campaign.medium,
                'utm_content': campaign.content
            }
        }

        return Command.MIXPANEL_PIXEL_BASED_EVENT_TRACKING.format(
            base64.b64encode(bytes(json.dumps(data), 'utf-8')).decode(encoding='utf-8')
        )
