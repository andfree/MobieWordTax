from datetime import date, datetime
from django.core.exceptions import ValidationError
from django.core.management import BaseCommand
from django.core.validators import validate_email
from marketing.models import Email, MallOrderBusinessman
import os


class Command(BaseCommand):
    def add_arguments(self, parser):
        parser.add_argument('path', nargs='?', type=str)

    def handle(self, *args, **options):
        for path in os.listdir(options['path']):
            extension = os.path.splitext(path)[-1]
            if extension != '.csv':
                continue

            path = os.path.join(options['path'], path)
            with open(path, encoding='euc-kr', errors='ignore') as file:
                while True:
                    header = next(file, None).split(',')
                    if header[0].startswith('통신판매사업자 정보') or header[0].startswith('자료생성일'):
                        continue

                    break

                columns = []
                for row in file:
                    split = row.split(',')
                    if columns:
                        split[0] = columns[-1] + split[0]
                        columns = columns[:-1] + split
                    else:
                        columns = split

                    if len(header) != len(columns):
                        continue

                    info = dict(zip(header, [column.strip() for column in columns]))
                    columns = []

                    try:
                        registration_number = int(info['사업자등록번호'].replace('-', ''))
                        if registration_number == 9999999999:
                            continue
                    except ValueError:
                        continue

                    registration_date = None
                    try:
                        registration_date = datetime.strptime(info['신고일자'], '%Y-%m-%d').date()
                    except ValueError:
                        pass

                    this_year = date.today().year
                    if not registration_date:
                        try:
                            year = int(info['통신판매번호'][:4])
                            if year < 1000 or year > this_year:
                                continue

                            registration_date = datetime(int(year), 1, 1).date()
                        except ValueError:
                            continue

                    email = None
                    try:
                        validate_email(info['전자우편'])
                        email = Email.objects.get_or_create(email=info['전자우편'])[0]
                    except ValidationError:
                        pass

                    MallOrderBusinessman.objects.get_or_create(registration_number=registration_number, defaults={
                        'name': info['상호'],
                        'email': email,
                        'is_individual': int(registration_number % 10000000 / 100000) not in [81, 82, 83, 84, 85, 86, 87, 88],
                        'registration_date': registration_date,
                        'condition': info['업소상태'],
                        'info': info
                    })
