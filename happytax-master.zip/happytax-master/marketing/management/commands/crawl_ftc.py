from bs4 import BeautifulSoup
from datetime import datetime
from django.core.exceptions import ValidationError
from django.core.management import BaseCommand
from django.core.validators import validate_email
from marketing.models import Email, MallOrderBusinessman
from urllib.parse import parse_qs, urlencode, urlparse
import aiohttp
import asyncio


class Command(BaseCommand):
    BASE_URL = 'http://www.ftc.go.kr'
    OPEN_LIST_URL = 'http://www.ftc.go.kr/info/dataopen/openCommList.jsp'
    LIST_URL = 'http://www.ftc.go.kr/info/bizinfo/communicationList.jsp'

    def add_arguments(self, parser):
        parser.add_argument('start_date', nargs='?', type=str)
        parser.add_argument('end_date', nargs='?', type=str)

    def handle(self, *args, **options):
        loop = asyncio.get_event_loop()
        with aiohttp.ClientSession(loop=loop) as session:
            areas = loop.run_until_complete(asyncio.async(self.crawl_entry(session)))
            connections = [asyncio.async(self.get_area(session, area)) for area in areas]
            areas = loop.run_until_complete(asyncio.wait(connections))[0]

            semaphore = asyncio.Semaphore(20)
            connections = []
            for area in areas:
                area = area.result()
                area, sub_areas = area['area'], area['sub_areas']
                for sub_area in sub_areas:
                    connections.append(self.tour(semaphore, session, area, sub_area, options['start_date'], options['end_date']))
            loop.run_until_complete(asyncio.wait(connections))
            loop.close()

    @asyncio.coroutine
    def crawl_entry(self, session):
        response = yield from session.get(self.OPEN_LIST_URL)
        data = yield from response.read()
        soup = BeautifulSoup(data)
        regions = soup.find(id='area1')
        return [region['value'] for region in regions.find_all('option') if region['value']]

    @asyncio.coroutine
    def get_area(self, session, area1):
        payload = {
            'area1': area1
        }
        response = yield from session.post(self.OPEN_LIST_URL, data=payload)
        data = yield from response.read()
        soup = BeautifulSoup(data)
        areas = soup.find(id='area2')
        return {
            'area': area1,
            'sub_areas': [area['value'] for area in areas.find_all('option') if area['value']]
        }

    @asyncio.coroutine
    def tour(self, semaphore, session, area1, area2, start_date, end_date):
        yield from semaphore.acquire()
        try:
            max_page = None
            page = 1
            while True:
                max_page = yield from self.tour_with_page(session, area1, area2, start_date, end_date, page, max_page)
                if page == max_page:
                    break

                page += 1
        finally:
            semaphore.release()

    @asyncio.coroutine
    def tour_with_page(self, session, area1, area2, start_date, end_date, page, max_page):
        payload = {
            'schCheck': 'search',
            'area1': area1,
            'area2': area2,
            'searchMngStateCode': '01',
            'currpage': page
        }
        if start_date: payload['stdate'] = start_date
        if end_date: payload['enddate'] = end_date

        response = yield from session.get('{}?{}'.format(self.OPEN_LIST_URL, urlencode(payload)))
        data = yield from response.read()
        soup = BeautifulSoup(data)
        mall_order_businessmen = yield from self.extract_mall_order_businessman_list(soup)
        for mall_order_businessman in mall_order_businessmen:
            yield from self.found_mall_order_businessman(
                session,
                mall_order_businessman['name'],
                mall_order_businessman['registration_date']
            )

        if not max_page:
            max_page = yield from self.extract_max_page(soup)
            max_page = int(max_page)

        return max_page

    @asyncio.coroutine
    def found_mall_order_businessman(self, session, name, registration_date):
        try:
            MallOrderBusinessman.objects.get(
                name=name,
                registration_date=datetime.strptime(registration_date, '%Y-%m-%d').date()
            )
            return
        except MallOrderBusinessman.DoesNotExist:
            pass

        start_date = registration_date.replace('-', '')
        payload = {
            'searchKey': '01',
            'searchVal': name,
            'stdate': start_date,
            'enddate': start_date
        }
        response = yield from session.get('{}?{}'.format(self.LIST_URL, urlencode(payload, encoding='euc-kr')))
        data = yield from response.read()
        soup = BeautifulSoup(data)
        mall_order_businessmen = yield from self.extract_mall_order_businessman_list(soup)
        for mall_order_businessman in mall_order_businessmen:
            if name == mall_order_businessman['name'] and registration_date == mall_order_businessman['registration_date']:
                yield from self.save_mall_order_businessman(
                    session,
                    '{}/info/bizinfo/{}'.format(self.BASE_URL, mall_order_businessman['link'])
                )
                return

    @asyncio.coroutine
    def save_mall_order_businessman(self, session, url):
        response = yield from session.get(url)
        data = yield from response.read()
        text = data.decode('euc-kr', errors='ignore')
        info = yield from self.extract_mall_order_businessman_detail(text)

        try:
            registration_number = int(info['사업자등록번호'].replace('-', ''))
        except ValueError:
            return

        email = None
        try:
            validate_email(info['전자우편(E-mail)'])
            email = Email.objects.get_or_create(email=info['전자우편(E-mail)'])[0]
        except ValidationError:
            pass

        MallOrderBusinessman.objects.get_or_create(registration_number=registration_number, defaults={
            'name': info['상호'],
            'email': email,
            'is_individual': int(registration_number % 10000000 / 100000) not in [81, 82, 83, 84, 85, 86, 87, 88],
            'registration_date': datetime.strptime(info['신고일자'], '%Y%m%d').date(),
            'info': info
        })

    @asyncio.coroutine
    def extract_mall_order_businessman_list(self, soup):
        table = soup.find('table')
        tbody = table.find('tbody')
        trs = [tr.find_all('td') for tr in tbody.find_all('tr')]

        if len(trs[0]) == 1: return []
        return [{
                    'number': tr[0].text.strip(),
                    'area': tr[1].text.strip(),
                    'name': tr[2].text.strip(),
                    'president': tr[3].text.strip(),
                    'domain': tr[4].text.strip(),
                    'status': tr[5].text.strip(),
                    'registration_date': tr[6].text.strip(),
                    'link': (tr[2].find('a') or {}).get('href', None)
                } for tr in trs]

    @asyncio.coroutine
    def extract_max_page(self, soup):
        next_end = soup.find('a', class_='next_end')
        href = next_end.get('href')
        parse_result = urlparse(href)
        return parse_qs(parse_result.query)['currpage'][0]

    @asyncio.coroutine
    def extract_mall_order_businessman_detail(self, data):
        soup = BeautifulSoup(data)
        table = soup.find('table')
        tbody = table.find('tbody')
        ths = [th.text for th in tbody.find_all('th')]
        tds = [td.text.strip() for td in tbody.find_all('td')]
        return dict(zip(ths, tds))
