from django.core.management import BaseCommand
from marketing.models import CrawledPage, Region, YellowPage
from aiohttp import ClientOSError, ClientRequestError, ClientResponseError
import aiohttp
import asyncio
import hashlib


class Command(BaseCommand):
    URL = 'https://114.co.kr/searchData.do'

    def __init__(self):
        super().__init__()
        self.is_success = True

    def add_arguments(self, parser):
        parser.add_argument('search_word', nargs='?', type=str)

    def handle(self, *args, **options):
        regions = Region.objects.all()

        loop = asyncio.get_event_loop()
        semaphore = asyncio.Semaphore(100)
        with aiohttp.ClientSession(loop=loop) as session:
            connections = [self.look_up_number(semaphore, session, region, options['search_word'], page)
                           for page in range(1, 21) for region in regions]
            loop.run_until_complete(asyncio.wait(connections))
            loop.close()

    @asyncio.coroutine
    def look_up_number(self, semaphore, session, region, search_word, page):
        yield from semaphore.acquire()
        try:
            if not self.is_success:
                return

            is_success = yield from self.look_up_number_in_yellow_pages(session, region, search_word, page)
            if not is_success:
                self.is_success = False
        finally:
            semaphore.release()

    @asyncio.coroutine
    def look_up_number_in_yellow_pages(self, session, region, search_word, page):
        payload = {
            'x': region.x,
            'y': region.y,
            'searchWord': search_word,
            'currentPage': page,
            'rowsPerPage': 20
        }

        sorted_payload = sorted(payload.items())
        hash_ = int(hashlib.sha1(str(sorted_payload).encode('utf-8')).hexdigest(), 16) % (10 ** 8)
        crawled_pages = CrawledPage.objects.filter(hash=hash_)
        for crawled_page in crawled_pages:
            found = True
            for i, j in zip(sorted_payload, sorted(crawled_page.info.items())):
                if i != j:
                    found = False
                    break

            if found:
                return True

        try:
            response = yield from session.post(self.URL, data=payload, allow_redirects=False)
        except (ClientOSError, ClientRequestError, ClientResponseError):
            return False

        try:
            if response.status != 200:
                return False

            json = yield from response.json()

            for address in json['poiList']:
                try:
                    tel = address['tel']
                    name = address['name']
                    road_name = address['road_name']
                    if not tel or not name or not road_name:
                        continue

                    YellowPage.objects.get_or_create(region=region, search_word=search_word, tel=tel, defaults={
                        'name': name,
                        'road_name': road_name,
                        'info': address
                    })
                except IndexError:
                    continue

            CrawledPage.objects.create(type='KT114', hash=hash_, info=payload)
            return True
        finally:
            response.close()
